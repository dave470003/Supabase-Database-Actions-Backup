SET session_replication_role = replica;

--
-- PostgreSQL database dump
--

-- \restrict tpTEXijV9OL91D6ydDLruTl23BGUEZuvQrUNzInXBKVroxQc9jJTDbjjM8g7soB

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."audit_log_entries" ("instance_id", "id", "payload", "created_at", "ip_address") FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."custom_oauth_providers" ("id", "provider_type", "identifier", "name", "client_id", "client_secret", "acceptable_client_ids", "scopes", "pkce_enabled", "attribute_mapping", "authorization_params", "enabled", "email_optional", "issuer", "discovery_url", "skip_nonce_check", "cached_discovery", "discovery_cached_at", "authorization_url", "token_url", "userinfo_url", "jwks_uri", "created_at", "updated_at", "custom_claims_allowlist") FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."flow_state" ("id", "user_id", "auth_code", "code_challenge_method", "code_challenge", "provider_type", "provider_access_token", "provider_refresh_token", "created_at", "updated_at", "authentication_method", "auth_code_issued_at", "invite_token", "referrer", "oauth_client_state_id", "linking_target_id", "email_optional") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."users" ("instance_id", "id", "aud", "role", "email", "encrypted_password", "email_confirmed_at", "invited_at", "confirmation_token", "confirmation_sent_at", "recovery_token", "recovery_sent_at", "email_change_token_new", "email_change", "email_change_sent_at", "last_sign_in_at", "raw_app_meta_data", "raw_user_meta_data", "is_super_admin", "created_at", "updated_at", "phone", "phone_confirmed_at", "phone_change", "phone_change_token", "phone_change_sent_at", "email_change_token_current", "email_change_confirm_status", "banned_until", "reauthentication_token", "reauthentication_sent_at", "is_sso_user", "deleted_at", "is_anonymous") FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."identities" ("provider_id", "user_id", "identity_data", "provider", "last_sign_in_at", "created_at", "updated_at", "id") FROM stdin;
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."instances" ("id", "uuid", "raw_base_config", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_clients" ("id", "client_secret_hash", "registration_type", "redirect_uris", "grant_types", "client_name", "client_uri", "logo_uri", "created_at", "updated_at", "deleted_at", "client_type", "token_endpoint_auth_method") FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sessions" ("id", "user_id", "created_at", "updated_at", "factor_id", "aal", "not_after", "refreshed_at", "user_agent", "ip", "tag", "oauth_client_id", "refresh_token_hmac_key", "refresh_token_counter", "scopes") FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_amr_claims" ("session_id", "created_at", "updated_at", "authentication_method", "id") FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_factors" ("id", "user_id", "friendly_name", "factor_type", "status", "created_at", "updated_at", "secret", "phone", "last_challenged_at", "web_authn_credential", "web_authn_aaguid", "last_webauthn_challenge_data") FROM stdin;
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_challenges" ("id", "factor_id", "created_at", "verified_at", "ip_address", "otp_code", "web_authn_session_data") FROM stdin;
\.


--
-- Data for Name: mfa_recovery_code_sets; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_recovery_code_sets" ("id", "user_id", "mfa_factor_id", "failed_verification_count", "verification_locked_until", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: mfa_recovery_codes; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_recovery_codes" ("id", "mfa_recovery_code_set_id", "code_hash", "consumed_at", "created_at") FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_authorizations" ("id", "authorization_id", "client_id", "user_id", "redirect_uri", "scope", "state", "resource", "code_challenge", "code_challenge_method", "response_type", "status", "authorization_code", "created_at", "expires_at", "approved_at", "nonce") FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_client_states" ("id", "provider_type", "code_verifier", "created_at") FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_consents" ("id", "user_id", "client_id", "scopes", "granted_at", "revoked_at") FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."one_time_tokens" ("id", "user_id", "token_type", "token_hash", "relates_to", "created_at", "updated_at", "expires_at") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."refresh_tokens" ("instance_id", "id", "token", "user_id", "revoked", "created_at", "updated_at", "parent", "session_id") FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_providers" ("id", "resource_id", "created_at", "updated_at", "disabled") FROM stdin;
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_providers" ("id", "sso_provider_id", "entity_id", "metadata_xml", "metadata_url", "attribute_mapping", "created_at", "updated_at", "name_id_format") FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_relay_states" ("id", "sso_provider_id", "request_id", "for_email", "redirect_to", "created_at", "updated_at", "flow_state_id") FROM stdin;
\.


--
-- Data for Name: scim_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."scim_tokens" ("id", "sso_provider_id", "token_hash", "prefix", "created_at", "expires_at", "revoked_at", "last_used_at") FROM stdin;
\.


--
-- Data for Name: scim_users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."scim_users" ("id", "sso_provider_id", "user_id", "resource", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_domains" ("id", "sso_provider_id", "domain", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_challenges" ("id", "user_id", "challenge_type", "session_data", "created_at", "expires_at") FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_credentials" ("id", "user_id", "credential_id", "public_key", "attestation_type", "aaguid", "sign_count", "transports", "backup_eligible", "backed_up", "friendly_name", "created_at", "updated_at", "last_used_at") FROM stdin;
\.


--
-- Data for Name: accommodation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."accommodation" ("id", "is_at_venue", "is_treehouse", "name", "slug", "is_paid_for", "price", "suggested_donation", "description", "link", "check_in", "check_out", "model") FROM stdin;
1	t	f	The Map Room	the-map-room	\N	\N	100.00	The Map Room celebrates James Augustus Grant, Anselm’s great-great-grandfather and famed explorer of the Nile. With a nod to adventure and discovery, the room is filled with character and provides an inspiring retreat for guests seeking both comfort and storytelling.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=35&sr=-2.98,-1.08
2	t	f	The Master Suite	the-master-suite	\N	\N	100.00	For centuries, the Master Suite has been the main bedroom of Elmore Court. With elegant wooden panelled walls, sweeping views over the estate and a generously sized bed, it exudes historic charm and contemporary comfort.	https://www.elmorecourt.com/house/	2026-09-05 12:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=220&sr=-.49,.83
3	t	f	The Dressing Room	the-dressing-room	\N	\N	100.00	Located next to the Master Suite, the Dressing Room is a beautiful room in it's own right, and comes complete with elegant wooden panelled walls, sweeping views over the estate and a generously sized bed.	https://www.elmorecourt.com/house/	2026-09-05 12:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=213&sr=-2.67,.62
22	t	t	Kite	kite	\N	\N	100.00	Swaddled by evergreen Laurels, the L-shaped pod is perched on the eastern edge of the woodlands. High on style, comfort and coziness, it has a properly awesome sheltered outdoor kitchen and copper bath on the deck alongside an outside fire pit. 	https://www.rewildthings.com/treehouses/kite/	2026-09-04 15:00:00	2026-09-06 11:00:00	\N
24	t	t	Adder	adder	\N	\N	100.00	Slithered among the foliage around the western edge of the woodlands, the L-shaped cabin has floor-to-ceiling windows washing natural light over the mellow timbers. 	https://www.rewildthings.com/treehouses/adder/	2026-09-05 15:00:00	2026-09-06 11:00:00	\N
4	t	f	The Smoking Room	the-smoking-room	\N	\N	100.00	Originally a place to relax after lively days, the Smoking Room carries its historic name while offering contemporary luxury. It boasts an Emperor-sized bed, elegant painted panelling and a deep, indulgent bath, perfect for unwinding in style after a busy day at the house or wedding festivities.	https://www.elmorecourt.com/house/	2026-09-05 12:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=194&sr=-2.98,.45
21	t	t	Sky	sky	\N	\N	0.00	Positioned high up in the canopy of Laurels to the east, Sky has cracking views over our rewilding wetlands and is of course built using sustainable materials in a way that caused minimal damage to the woodlands. The design is contemporary, energy efficient, comfortable and super cool.	https://www.rewildthings.com/treehouses/sky/	2026-09-04 15:00:00	2026-09-06 11:00:00	\N
18	t	f	The Coach House	the-coach-house	\N	\N	0.00	Though close to the main property feels very contained. It’s comfy, private and includes 2 double bedrooms and a sitting room with a sofa bed.	https://www.elmorecourt.com/stay/#coach	2026-09-04 16:00:00	2026-09-05 12:00:00	\N
6	t	f	The Porch Room	the-porch-room	\N	\N	100.00	The Porch Room is a flexible, dormitory-style space designed for families or groups. With four single beds that can be linked in multiple configurations and a charming Armoire reminiscent of a storybook wardrobe, it’s a playful and practical choice for guests seeking comfort with a hint of whimsy.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=49&sr=-.34,-.59
5	t	f	The Oak Room	the-oak-room	\N	\N	100.00	The Oak Room is a bold and characterful retreat, featuring a 1636 four-poster bed, captivating artwork of serpents and unicorns and a decadent deep wooden bath. A striking blend of drama and comfort makes it one of the most memorable rooms in the house.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=29&sr=-2.77,-1.53
19	t	t	Wildcat	wildcat	\N	\N	100.00	A fabulous (sheltered) outdoor kitchen lives on the deck, along with a copper bath, fire pit and snooze chairs. While indoors there’s a wood burner, handmade super king bed with an organic mattress, soft linen and a bunch of cushions. Wildcat also has indoor cooking, tea and coffee facilities and a bathroom with a walk-in shower, sumptuous robes and top-notch bath products created from natural oils and healing plant extracts. 	https://www.rewildthings.com/treehouses/wildcat/	2026-09-05 15:00:00	2026-09-06 11:00:00	\N
20	t	t	Wren	wren	\N	\N	100.00	Wren is, like her namesake, small and perfectly formed. She rests lightly among the branches and leaves of the evergreen laurels, slap-bang in the middle of the woodlands with belting views. 	https://www.rewildthings.com/treehouses/wren/	2026-09-05 15:00:00	2026-09-06 11:00:00	\N
12	t	f	The Hole In The Wall	the-hole-in-the-wall	\N	\N	100.00	Accessible via its own private staircase, the Hole in the Wall feels almost like a suite. This charming and secluded double bedroom includes a well-designed bathroom, offering privacy, comfort and a whimsical twist on traditional accommodation.	https://www.elmorecourt.com/house/	2026-09-05 12:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=243&sr=-.31,.05
23	t	t	Earth	earth	\N	\N	100.00	Rooted in a particularly fine spot in the canopy, L-shaped Earth enjoys almost safari views from her deck and panoramic windows, along with cool contemporary, energy efficient design. 	https://www.rewildthings.com/treehouses/earth/	2026-09-05 15:00:00	2026-09-06 11:00:00	\N
7	t	f	The Nursery	the-nursery	\N	\N	100.00	Traditionally the nursery, this spacious room features a double bed, an optional single bed and a marble-tiled bathroom. Its generous proportions make it ideal for families, combining practicality with timeless elegance and comfort.	https://www.elmorecourt.com/house/	2026-09-05 12:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=182&sr=-2.77,1.04
11	t	f	The Butler's Room	the-butlers-room	\N	\N	100.00	On the second floor, the Butler’s Room offers a double bed, sweeping views over the Gillyflower and Cedar Lawn and a beautifully appointed bathroom. A calm and refined space for restful nights.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=76&sr=-.4,-.42
10	t	f	The North Room	the-north-room	\N	\N	100.00	Step back in time in the North Room, a classic wood-panelled bedroom with timeless elegance. Guests enjoy tranquil views of a majestic cedar tree and the Gillyflower, creating a serene and restorative stay.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=17&sr=-2.92,-.09
9	t	f	The General's Room	the-generals-room	\N	\N	100.00	The General’s Room once housed a high-ranking military officer and is perfect for families. It includes a twin bed (or double bed, depending on how close you want to get) and a bunk bed, offering a fun and comfortable space for guests of all ages.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=102&sr=-2.87,-.3
8	t	f	The Time Room	the-time-room	\N	\N	100.00	Light, airy, and full of character, the Time Room is named for “Old Father Time,” a reminder to savour life’s moments. The room features quirky 1920s graffiti and is celebrated for its brightness and charm, making it one of the most popular guest rooms in the house.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=1&sr=-2.31,-1.15
16	t	f	The Governesses Room	the-governesses-room	\N	\N	0.00	On the second floor, the Governess’ Room shares a bathroom with the adjacent Footman’s Room. This cosy, inviting space balances traditional charm with modern comfort, making it perfect for guests seeking a warm, communal feel.	https://www.elmorecourt.com/house/	2026-09-05 12:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=66&sr=-.88,-1
15	t	f	The Bachelor's Room	the-bachelors-room	\N	\N	100.00	Once home to the young masters after leaving the nursery, the Bachelor’s Room is a simple and comfortable double bedroom with a private shower room, offering a restful and historically resonant stay.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=42&sr=-2.58,-1.02
14	t	f	The Cook's Room	the-cooks-room	\N	\N	100.00	Tucked away on the upper floor, the Cook’s Room features bold, vibrant colours and a sleek shower room. With views over the walled garden, it is a cheerful, lively space that combines practicality with flair.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=84&sr=-2.77,.35
13	t	f	The Private's Room	the-privates-room	\N	\N	100.00	Located beside the General’s Room, Privates is a cosy double bedroom with a grand bathroom just steps away. Its charm is amplified by a set of standout curtains, providing both elegance and a touch of humour.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=98&sr=-2.32,-1.1
17	t	f	The Footman's Room	the-footmans-room	\N	\N	100.00	On the second floor, the Footman’s Room shares a bathroom with the Governess’ Room. Light, comfortable and full of character, it’s an ideal choice for guests who appreciate historic charm with contemporary amenities.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=78&sr=-2.29,-.9
\.


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."cache" ("key", "value", "expiration") FROM stdin;
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."cache_locks" ("key", "owner", "expiration") FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."failed_jobs" ("id", "uuid", "connection", "queue", "payload", "exception", "failed_at") FROM stdin;
\.


--
-- Data for Name: food_choices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."food_choices" ("id", "name", "description", "allergens", "course_number", "is_child_food", "options", "cost") FROM stdin;
0	No Meal	No Meal	0	0	f	0	0.00
1	Tart	Spring vegetable & goats cheese tart, dressed leaves	0	1	f	0	0.00
2	Salmon	Hot smoked salmon fillet, curried fried rice, sesame yoghurt, aubergine jam	0	1	f	0	0.00
5	Cheesecake	Baked vanilla cheesecake, poached strawberries	0	3	f	0	0.00
7	Beef Roast	Roast Hereford beef rump	0	2	f	0	0.00
8	Veggie Roast	Root vegetable and lentil loaf	0	2	f	0	0.00
14	Pizza	Mini pitta pizza	0	1	t	0	0.00
15	Spaghetti	Spaghetti, tomato sauce	0	2	t	0	0.00
3	Bread Roll	A selection of rustic farmhouse bread	0	1	f	0	\N
16	Brownie	Triple chocolate brownie & vanilla ice cream	0	3	f	0	0.00
\.


--
-- Data for Name: guests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."guests" ("id", "reference_name", "name", "email", "rsvp", "household", "role", "requires_childcare_data", "requires_childrens_menu", "requires_childcare", "dietary_requirements", "comments", "favourite_board_game", "invited_day_after", "invited_evening_before", "evening_only", "partner_invited", "is_child", "day_before_rsvp", "day_after_rsvp", "course_1_id", "course_2_id", "course_3_id", "seat") FROM stdin;
41	Jon Wooldridge	Jon Wooldridge	jonlou16@gmail.com	t	20	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	1	7	5	34
172	Madeline MacLean	Madeline MacLean	madelinemaclean9@gmail.com	t	91	Day Guest	f	f	f	\N	I am incredibly excited and audibly hungry for this!! Can’t wait xx	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	53
170	Reuben Goldmark	Reuben Goldmark	reubengoldmark@gmail.com	t	89	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	52
56	Jonathan Vooght	Jon Vooght	jon@jonvooght.co.uk	t	27	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	115
21	Christopher Price-Dahlgren	Christopher Price-Dahlgren	Chriskillik@gmail.com	t	12	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	81
34	Margot McTel	Margot McTel	\N	t	17	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	14	15	16	72
13	Katie Hannaford	Katie Hannaford	kjhannaford92@gmail.com	t	9	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	138
66	Shreya Garge	Shreya Garge	shreyagarge@gmail.com	t	8	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	yes	2	8	5	134
1	Freddy Pitel	Freddy Pitel	fwbpitel@gmail.com	t	1	Groom	f	f	f	Gluten and dairy intollerance	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	16	21
14	Alexei Barnes	Alexei Barnes	alexei.barnes@live.co.uk	t	9	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	137
12	Helena Chan	Helena Chan	helena002@gmail.com	t	4	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5	105
5	Jon Masson	Jon Masson	jmasson91@googlemail.com	t	4	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5	104
15	Ian Barwick	Ian Barwick	Ianbarwick1@gmail.com	t	10	Day Guest	f	f	f	\N	Looking forward to it.	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	103
17	Enzo Barwick	Enzo Barwick	\N	t	10	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	14	15	16	102
16	Ellie Barwick	Ellie Barwick	ejbarwick250@gmail.com	t	10	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	100
46	Harriet Blair	Harriet Blair	\N	t	22	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	18
20	Reem Khurshid	Reem Khurshid	reem.khurshid@gmail.com	t	11	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	16
72	Matthew Nutt	Matthew Nutt	matthew.charles.nutt@googlemail.com	t	35	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	111
73	Matthew Wyles	Matthew Wyles	matthewwyles@gmail.com	t	36	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	110
53	Alix Lyons	Alix Lyons	chidz1612@gmail.com	t	25	Day Guest	f	f	f	\N	Your invitation is fantastic! So much love for this!	\N	f	\N	\N	\N	\N	\N	\N	2	8	0	113
55	Colin Paxton	Colin Paxton	FandD@colinpaxton.com	t	26	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	116
80	Erika Sojkova	Erika Sojkova	\N	t	40	Day Guest	f	f	f	\N	Cheesecake yeah!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	119
19	Todd Francis	Todd Francis	toddish.f@gmail.com	t	11	Day Guest	f	f	f	\N	I can't wait!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	15
32	Laura Pitel	Laura Pitel	laura.pitel@gmail.com	t	17	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	no	1	8	5	61
28	Marcus Fox	Marcus Fox	marcusfox137@hotmail.com	t	14	Day Guest	f	f	f	no pork/shellfish	\N	\N	t	\N	\N	\N	\N	\N	\N	2	7	5	23
58	Tanya Burnett	Tanya Burnett	tanyamarieknox@gmail.com	t	28	Day Guest	f	f	f	Vegetarian	\N	\N	f	\N	\N	\N	\N	\N	\N	1	8	5	93
45	Pandora Blair	Pandora Blair	pandora.donegan@gmail.com	t	22	Day Guest	f	f	f	\N	So excited!!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	17
27	Astraea Capocci-Hunt	Astraea Capocci-Hunt	\N	t	13	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	14	15	16	91
25	Kieron Capocci-Hunt	Kieron Capocci-Hunt	khunt500@gmail.com	t	13	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5	92
65	Georgia Dunnicliffe	Georgia Dunnicliffe	\N	t	31	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	14	15	16	87
64	Joel Dunnicliffe	Joel Dunnicliffe	\N	t	31	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	14	15	16	86
50	Theodore Paul	Theo Paul	\N	t	23	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	14	7	16	40
49	Amy Paul	Amy Paul	martinjpaul@me.com	t	23	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	41
52	Sam Sargent	Sam Sargent	samuelsargent89@icloud.com	t	24	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	45
47	Stacey Chodera	Stacey Chodera	\N	t	7	Day Guest	f	f	f	Vegetarian, no mushrooms	\N	\N	t	\N	\N	\N	\N	\N	no	1	8	5	38
8	Adam Chodera	Adam Chodera	chodera.adam@gmail.com	t	7	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	no	1	8	5	37
51	Craig Sargent	Craig Sargent	craigsargent@hotmail.co.uk	t	24	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	46
76	Elliot Byford	Elliot Byford	\N	t	37	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	14	15	16	123
62	Adam Dunnicliffe	Adam Dunnicliffe	adam.ajd@gmail.com	t	31	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	88
75	Emily Byford	Emily Byford	emily@ek-smith.com	t	37	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	122
42	Libby Dunn	Libby Dunn	Libbyrosestephen@gmail.com	t	5	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5	127
68	David Holtum	David Holttum	David@Holttum.co.uk	t	33	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	130
3	Alyssa Burling	Alyssa Burling	alyssa.burlton@gmail.com	t	2	Wedding Party	f	f	f	\N	I tried to follow your spaceship directions and flew into the sun :(	\N	t	\N	\N	\N	\N	\N	yes	1	8	16	135
77	Sian Ebsworth	Sian Ebsworth	\N	\N	38	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
198	Sarah Clay	Sarah Clay	\N	t	112	\N	f	f	f	\N	\N	\N	f	f	f	f	f	f	\N	1	7	5	42
90	Timothy Finlay	Timothy Finlay	\N	\N	46	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
93	Ameila Pritchard	Amelia Pritchard	amelia.pritchard10@gmail.com	t	47	Day Guest	f	f	f	Vegetarian	I’m so happy for you two. Thank you for inviting me.	\N	t	\N	\N	\N	\N	\N	\N	0	8	5	25
189	Rachel Dowse	Rachel Dowse	r.e.dowse@hotmail.co.uk	t	105	Day Guest	f	f	f	None	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	60
168	Anthony Whelan	Anthony Whelan	Anthony.tux@gmail.com	t	87	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	56
119	Sinead	Sinead Geraghty	tomdanderson27@gmail.com	t	60	Day Guest	f	f	f	None	\N	\N	t	\N	\N	\N	\N	\N	unsure	1	7	5	69
114	Katie Styles	Katie Styles	katiestylesmail@gmail.com	t	59	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	no	1	8	5	65
112	Charlie Fisher	Charles Fisher	cfisher1993267@gmail.com	t	58	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	no	1	7	5	64
102	Adrian Gralak	Adrian Gralak	adrian.gralak95@gmail.com	t	51	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5	1
97	Julia Marych	Julia Marych	julia.kub.mar@gmail.com	t	49	Day Guest	f	f	f	N/A	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5	7
22	Cilla Price-Dahlgren	Cilla Price-Dahlgren	Cillasilvia@hotmail.com	t	12	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	73
192	Jamie Jones	Jamie Jones	jones.j15@gmail.com	t	108	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	75
188	Ian Ang	Ian Ang	ianang1993@gmail.com	t	104	Day Guest	f	f	f	\N	Yummy yummy yummy I got yummy in my tummy	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	76
191	Lawrence Bishop	Lawrence Bishop	banjoses@gmail.com	t	107	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	77
86	Richard Nicholson	Richard Nicholson	richienicholson@googlemail.com	t	44	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	141
195	Corrine O'Connor	Corinne O'Connor	Corinne.oconnor@hotmail.com	t	110	Day Guest	f	f	f	None :-)	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	9
18	Luca Barwick	Luca Barwick	\N	t	10	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	8	16	101
82	Tom Jordan	Tom Jordan	Tma.jordan@outlook.com	t	42	Day Guest	f	f	f	None	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	98
4	Mark Fisher	Mark Fisher	thefishers5725@gmail.com	t	3	Wedding Party	f	f	f	\N	Wahoo! It's working!	\N	t	\N	\N	\N	\N	\N	yes	1	7	5	97
96	Roman Marych	Roman Marych	marych.roman@gmail.com	t	49	Day Guest	f	f	f	N/A	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5	6
87	Helen Nicholson	Helen Nicholson	\N	t	44	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	139
10	Leah Burling	Leah Burling	leah.ann.king93@gmail.com	t	2	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	0	8	0	136
11	Sara Fisher	Sara Fisher	thefishers5725@gmail.com	t	3	Day Guest	f	f	f	\N	Happy wedding planning! Nth time is the charm!	\N	t	\N	\N	\N	\N	\N	yes	1	7	5	106
85	Chris Bradley	Chris Bradley	chris4794@hotmail.co.uk	t	43	Day Guest	f	f	f	None	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	13
105	Beth Little	Beth Little	Jolly_rodgers7@hotmail.com	t	54	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	8	5	20
106	Martin Little	Martin Little	martinlittle90@gmail.com	t	54	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	19
57	Matthew Burnett	Matthew Burnett	Foxtel@mattburnett.co.uk	t	28	Day Guest	f	f	f	\N	I love the invite and website design	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	94
24	Hannah Capocci-Hunt	Hannah Capocci-Hunt	khunt500@gmail.com	t	13	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	1	7	5	89
63	Michel Dunnicliffe	Michel Dunnicliffe-Ward	shelward999@googlemail.com	t	31	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	85
187	Mia Violentano	Mia Violentano	maria.violentano@gmail.com	t	103	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	42
175	Kirsty Blythe	Kirsty Blythe	kirsty.blythe@hotmail.co.uk	t	94	Day Guest	f	f	f	\N	Your story on the website was amazing, I’m getting misty eyed already! X	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	43
167	Sam Kenny	Sam Kenny	samuel_j_kenny@hotmail.co.uk	t	86	Day Guest	f	f	f	N/A	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	44
84	Lawrance Bailes	Lawrance Bailes	lawrance.bailes21@googlemail.com	t	43	Day Guest	f	f	f	No gravy, salad dressings or condiments please	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	14
88	Cherie Fox	Cherie Fox	\N	f	45	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
89	John Fox	John Fox	\N	f	45	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
81	Will Saunders	Will Saunders	wrs@wrsaunders.co.uk	t	41	Day Guest	f	f	f	N/a	Thanks for the invite and accommodation!	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	121
98	Julian Marych	Julian Marych	\N	f	49	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
69	Heather Holtum	Heather Holttum	heather@holttum.co.uk	t	33	Day Guest	f	f	f	\N	Can't wait to celebrate	\N	f	\N	\N	\N	\N	\N	\N	0	7	5	128
71	Ezra Attwood	Ezra Attwood	cub7391@gmail.com	t	34	Day Guest	f	f	f	\N	Super joyfully yes. Thanks guys 🤗🥳🏳️‍🌈	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	79
116	George Styles	George Styles	\N	f	59	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
100	Angela Calinski	Angela Calinski	\N	f	50	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
101	Ana Lu Calinksi	Ana Lu Calinksi	\N	f	50	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
115	James Styles	James Styles	\N	f	59	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
117	Wilf Styles	Wilf Styles	\N	f	59	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
91	Eileen Finlay	Eileen Finlay	\N	\N	46	Day Guest	f	f	f	Pescatarian	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
107	Harriet Little	Harriet Little	\N	f	54	Day Guest	t	t	t	\N	I’d really like to come but mummy and daddy won’t let me. Something about wanting to have a good time!	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
186	Dan Pope	Dan Pope	djpope2365@gmail.com	t	102	Day Guest	f	f	f	\N	I'm so excited!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	49
166	Gerry Lovelace	Gerry Lovelace	gerrelou@gmail.com	t	85	Day Guest	f	f	f	Lactose intolerance	Not sure they will have BBQ sauce there, but if they do, will be appreciated :)	\N	f	\N	\N	\N	\N	\N	\N	2	7	16	78
29	Helen Pitel	Helen Pitel	helenpitel1@gmail.com	t	15	Day Guest	f	f	f	\N	Delicious menu, thank you	\N	t	\N	\N	\N	\N	\N	yes	1	7	5	29
44	Edward Sanders	Edward Sanders	\N	f	21	Day Guest	f	f	f	\N	Apologies. Unless a global lack of jet fuel intervenes, I'm planning to be in the South Pacific. Can I take you out for a celebratory dinner when you're back from the honeymoon?	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
173	Marianne Baker	Marianne Baker	marianne.baker@outlook.com	t	92	Day Guest	f	f	f	Veggie (with some fish allowed)!	Many thanks for the invite, looking forward to it!!	\N	f	\N	\N	\N	\N	\N	\N	2	8	0	59
194	Lucy Williams	Lucy Williams	lucy@thehenhouse.co.uk	t	106	Day Guest	f	f	f	Vegetarian (yes to eggs and cheese etc, no thanks to meat/fish)	\N	\N	f	\N	\N	\N	\N	\N	\N	1	8	5	58
190	Nathan Williams	Nathan Williams	nathan@thehenhouse.co.uk	t	106	Day Guest	f	f	f	vegetarian (cheese and eggs OK)	Congratulations!!! Can't wait.	\N	f	\N	\N	\N	\N	\N	\N	1	8	5	57
171	Jordan Murray	Jordan Murray	\N	t	90	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	8	5	54
23	Saphi Price-Dahlgren	Saphi Price-Dahlgren	\N	t	12	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	0	15	0	84
67	Daniel Hanvey	Daniel Hanvey	danhanvey@googlemail.com	t	32	Day Guest	f	f	f	\N	Going to be the best wedding with an underground themed wedding invitation I've ever been to 💙	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	80
118	Tom Anderson	Tom Anderson	tomdanderson27@gmail.com	t	60	Day Guest	f	f	f	None	\N	\N	t	\N	\N	\N	\N	\N	unsure	1	7	5	68
169	Elisabeth Swedlund	Elisabeth Swedlund	elisabeth.swedlund@gmail.com	t	88	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	74
79	SB	SB	stephen.baldwin.personal@gmail.com	t	40	Day Guest	f	f	f	Gluten Free	Sounds yummy 😋	\N	f	\N	\N	\N	\N	\N	\N	2	7	16	120
54	James Lyons	James Lyons	lyons.james.r@gmail.com	t	25	Day Guest	f	f	f	\N	I also think your invite is excellent, we're both very much looking forward to your big day!	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	112
37	Dermot Colton	Dermot Colton	Dermotcolton@gmail.com	t	18	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5	67
103	Michal Leczycki	Michal Leczycki	leczyckim24@interia.pl	t	52	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5	10
197	Kashish Jaiswal	Kashish Jaiswal	kashishjaiswal999@gmail.com	t	51	Wedding Guest	f	f	f	Vegetarian	Looking forward to it! :)	\N	t	f	f	t	f	\N	yes	1	8	5	2
83	Giada Jordan	Giada Jordan	Giada.piero@gmail.com	t	42	Day Guest	f	f	f	None	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	99
2	David Fox	David Fox	djwfox@gmail.com	t	1	Groom	f	f	f	no pork/shellfish	More testing - I love you!	\N	t	\N	\N	\N	\N	\N	yes	1	7	5	22
99	Daniel Calinski	Daniel Calinski	\N	f	50	Day Guest	f	f	f	\N	Hi Fred,\r\nApologies for the late reply here.  We were really hoping to make it to Blighty to finally meet you and David in person but a few conflicts with planning the trip arose.	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
196	Matt O'Connor	Matt O'Connor	\N	t	110	Day Guest	f	f	f	Matt O’Connor has a rather severe intolerance to onion (including leeks, shallots, chives etc). Garlic is fine, and he’s fine for his meal to be cooked in an environment where there are onions- just no onions on the plate please!	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	8
92	Oliver Nicholson	Oliver Nicholson	\N	t	44	Day Guest	t	t	t	\N	If possible please can we have a highchair - no worries if not possible!	\N	f	\N	\N	\N	\N	\N	\N	14	15	0	140
61	Shaun Zedlewski	Shaun Zedlewski	sir.shaih+freddyanddavid@gmail.com	t	30	Day Guest	f	f	f	Food should be edible	/* Insert witty comment here. */	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	109
78	Stephen Briscoe	Stephen Briscoe	freddydavid@stephenbriscoe.co..uk	t	39	Day Guest	f	f	f	\N	Love the website and invite design!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	114
60	Jana Bartly	Jana Bartley	jana@nickandjana.co.uk	t	29	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	118
193	Nanditha Garge	Nanditha Garge	nanditagarge1123@gmail.com	t	109	Day Guest	f	f	f	No specific requirements	Congratulationssss!!	\N	f	\N	\N	\N	\N	\N	\N	2	8	5	142
26	Artemis Capocci-Hunt	Artemis Capocci-Hunt	\N	t	13	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	14	15	16	90
48	Martin Paul	Martin Paul	martinjpaul@me.com	t	23	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	39
6	Ian Dunn	Ian Dunn	Dunny118@gmail.com	t	5	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	1	7	5	125
74	Oliver Byford	Oliver Byford	o@byford.org	t	37	Day Guest	f	f	f	\N	Gah, we still haven’t worked out what we’re doing Accommodation wise, sorry! we’ll Make sure to let you know asap. Elliot’s looking forward to it!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	124
70	Henry Holtum	Henry Holttum	\N	t	33	Day Guest	t	t	t	\N	High five (he's learnt it and will insist on it)	\N	f	\N	\N	\N	\N	\N	\N	14	7	16	129
43	Millie Dunn	Millie Dunn	\N	t	5	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	14	8	5	126
7	Alex Prichard	Alex Pritchard	alexdpritchard@hotmail.com	t	6	Wedding Party	f	f	f	Dairy free, specifically A1 beta-casein, Goats milk therefore is fine:)	Dessert, I'll have what Freddy's having :)  Missing a box for "I'm special"	\N	t	\N	\N	\N	\N	\N	yes	1	7	16	36
33	John McManus	John McManus	johnmcman@gmail.com	t	17	Day Guest	f	f	f	\N	If it's possible to just have strawberries for dessert, that would be my choice. But if too faffy, then just nothing.	\N	t	\N	\N	\N	\N	\N	no	2	7	0	70
185	Louise O'Young	Louise O'Young	ms.louise.oyoung@gmail.com	t	101	Day Guest	f	f	f	I would like to know how the leaves are dressed so I can coordinate my outfit accordingly.	I'm so excited!!!! It's going to be a wonderful day. xoxo	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	55
35	Rowan McTel	Rowan McTel	\N	t	17	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	no	14	15	16	71
36	Beatrix Pitel	Beatrix Pitel	Bea.pitel@googlemail.com	t	18	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	1	7	5	66
31	Sally Pitel	Sally Pitel	sallypitel@gmail.com	t	16	Day Guest	f	f	f	\N	It all looks simply delicious	\N	t	\N	\N	\N	\N	\N	no	1	7	5	63
110	Evie Fisher	Evie Fisher	evie.fisher96@gmail.com	t	57	Day Guest	f	f	f	\N	Amazing invitation, amazing website! Can't wait to celebrate the big day with you both 💑	\N	t	\N	\N	\N	\N	\N	no	1	7	5	62
9	Stephen Quinn	Stephen Quinn	sckrikor@gmail.com	t	8	Wedding Party	f	f	f	Lactose intolerance, allergy to aubergines (eggplants)	Please leave off the aubergine jam. Is there a less cheesy alternative to cheesecake for dessert?	\N	t	\N	\N	\N	\N	\N	yes	2	7	16	133
199	Randall Munroe	Randall Munroe	\N	f	111	\N	\N	\N	\N	\N	I have left an Orange Letter for you to be put out at the wedding. I think you'll find it's contents very interesting! I'm sure it will be placed somewhere appropriate.	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
59	Nick Bartly	Nick Bartley	freddyanddavidwedding@nb221.com	t	29	Day Guest	f	f	f	\N	This wedding website design is amazing! We love it. And we are both already looking forward to joining you.	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	117
39	Janet Dunn	Janet Dunn	Janet.dunn62@gmail.com	t	19	Day Guest	f	f	f	Well done beef if possible.	\N	\N	t	\N	\N	\N	\N	\N	\N	1	7	5	32
30	Nigel Pitel	Nigel Pitel	nigelpitel@gmail.com	t	15	Day Guest	f	f	f	Very Stroud, like my clothing	Lots of love from us both XX	\N	t	\N	\N	\N	\N	\N	yes	1	7	5	30
109	Debbie Fisher	Debby Fisher	debbyfisher6873@gmail.com	t	56	Day Guest	f	f	f	\N	All looks lovely, looking forward to coming! I have a hat!!!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	28
38	Paul Dunn	Paul Dunn	Paul.dunn59@gmail.com	t	19	Day Guest	f	f	f	If my beef can be well done that would be very helpful.	Looking forward to enjoying the day with you both!	\N	t	\N	\N	\N	\N	\N	\N	1	7	5	31
40	Louise Wooldridge	Louise Wooldridge	louisedunn94@gmail.com	t	20	Day Guest	f	f	f	Mushroom Intolerance (although doesn’t look like that will be an issue)	\N	\N	t	\N	\N	\N	\N	\N	\N	3	7	5	33
200	Simon Jones	Simon Jones	\N	f	113	\N	\N	\N	\N	\N	Sad to miss it.\n\nI'm glad you liked my portrait idea, I hope it goes well. Remember, each pair of portraits is only different by one letter.\n\nI hope the TCG (trading card game) idea works out!\n\nGlad you didn't put me in a treehouse - they're all ridiculously named!	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: guests_duplicate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."guests_duplicate" ("id", "reference_name", "name", "email", "rsvp", "household", "role", "requires_childcare_data", "requires_childrens_menu", "requires_childcare", "dietary_requirements", "comments", "favourite_board_game", "invited_day_after", "invited_evening_before", "evening_only", "partner_invited", "is_child", "day_before_rsvp", "day_after_rsvp", "course_1_id", "course_2_id", "course_3_id") FROM stdin;
5	Jon Masson	Jon Masson	\N	\N	4	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
6	Ian Dunn	Ian Dunn	\N	\N	5	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
7	Alex Prichard	Alex Prichard	\N	\N	6	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
8	Adam Chodera	Adam Chodera	\N	\N	7	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
9	Stephen Quinn	Stephen Quinn	\N	\N	8	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
12	Helena Chan	Helena Chan	\N	\N	4	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
13	Katie Hannaford	Katie Hannaford	\N	\N	9	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
14	Alexei Barnes	Alexei Barnes	\N	\N	9	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
15	Ian Barwick	Ian Barwick	\N	\N	10	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
16	Ellie Barwick	Ellie Barwick	\N	\N	10	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
17	Enzo Barwick	Enzo Barwick	\N	\N	10	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
18	Luca Barwick	Luca Barwick	\N	\N	10	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
19	Todd Francis	Todd Francis	\N	\N	11	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
20	Reem Khurshid	Reem Khurshid	\N	\N	11	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
21	Christopher Price-Dahlgren	Christopher Price-Dahlgren	\N	\N	12	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
22	Cilla Price-Dahlgren	Cilla Price-Dahlgren	\N	\N	12	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
23	Saphi Price-Dahlgren	Saphi Price-Dahlgren	\N	\N	12	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
24	Hannah Capocci-Hunt	Hannah Capocci-Hunt	\N	\N	13	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
26	Artemis Capocci-Hunt	Artemis Capocci-Hunt	\N	\N	13	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
27	Astraea Capocci-Hunt	Astraea Capocci-Hunt	\N	\N	13	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
28	Marcus Fox	Marcus Fox	\N	\N	14	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
29	Helen Pitel	Helen Pitel	\N	\N	15	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
31	Sally Pitel	Sally Pitel	\N	\N	16	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
32	Laura Pitel	Laura Pitel	\N	\N	17	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
33	John McManus	John McManus	\N	\N	17	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
34	Margot McTel	Margot McTel	\N	\N	17	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
35	Rowan McTel	Rowan McTel	\N	\N	17	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
36	Beatrix Pitel	Beatrix Pitel	\N	\N	18	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
37	Dermot Colton	Dermot Colton	\N	\N	18	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
38	Paul Dunn	Paul Dunn	\N	\N	19	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
39	Janet Dunn	Janet Dunn	\N	\N	19	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
40	Louise Wooldridge	Louise Wooldridge	\N	\N	20	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
41	Jon Wooldridge	Jon Wooldridge	\N	\N	20	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
42	Libby Dunn	Libby Dunn	\N	\N	5	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
43	Millie Dunn	Millie Dunn	\N	\N	5	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
44	Edward Sanders	Edward Sanders	\N	\N	21	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
45	Pandora Blair	Pandora Blair	\N	\N	22	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
46	Harriet Blair	Harriet Blair	\N	\N	22	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
47	Stacey Chodera	Stacey Chodera	\N	\N	7	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
48	Martin Paul	Martin Paul	\N	\N	23	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
49	Amy Paul	Amy Paul	\N	\N	23	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
50	Theodore Paul	Theodore Paul	\N	\N	23	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
51	Craig Sargent	Craig Sargent	\N	\N	24	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
52	Sam Sargent	Sam Sargent	\N	\N	24	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
53	Alix Lyons	Alix Lyons	\N	\N	25	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
54	James Lyons	James Lyons	\N	\N	25	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
55	Colin Paxton	Colin Paxton	\N	\N	26	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
56	Jonathan Vooght	Jonathan Vooght	\N	\N	27	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
57	Matthew Burnett	Matthew Burnett	\N	\N	28	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
58	Tanya Burnett	Tanya Burnett	\N	\N	28	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
59	Nick Bartly	Nick Bartly	\N	\N	29	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
60	Jana Bartly	Jana Bartly	\N	\N	29	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
61	Shaun Zedlewski	Shaun Zedlewski	\N	\N	30	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
62	Adam Dunnicliffe	Adam Dunnicliffe	\N	\N	31	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
63	Michel Dunnicliffe	Michel Dunnicliffe	\N	\N	31	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
64	Joel Dunnicliffe	Joel Dunnicliffe	\N	\N	31	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
65	Georgia Dunnicliffe	Georgia Dunnicliffe	\N	\N	31	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
66	Shreya Garge	Shreya Garge	\N	\N	8	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
67	Daniel Hanvey	Daniel Hanvey	\N	\N	32	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
68	David Holtum	David Holtum	\N	\N	33	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
69	Heather Holtum	Heather Holtum	\N	\N	33	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
70	Henry Holtum	Henry Holtum	\N	\N	33	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
71	Ezra Attwood	Ezra Attwood	\N	\N	34	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
72	Matthew Nutt	Matthew Nutt	\N	\N	35	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
73	Matthew Wyles	Matthew Wyles	\N	\N	36	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
74	Oliver Byford	Oliver Byford	\N	\N	37	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
75	Emily Byford	Emily Byford	\N	\N	37	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
76	Elliot Byford	Elliot Byford	\N	\N	37	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
77	Sian Ebsworth	Sian Ebsworth	\N	\N	38	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
78	Stephen Briscoe	Stephen Briscoe	\N	\N	39	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
79	SB	SB	\N	\N	40	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
80	Erika Sojkova	Erika Sojkova	\N	\N	40	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
81	Will Saunders	Will Saunders	\N	\N	41	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
82	Tom Jordan	Tom Jordan	\N	\N	42	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
3	Alyssa Burling	Alyssa Burling	alyssa.burlton@gmail.com	t	2	Wedding Party	f	f	f	\N	I tried to follow your spaceship directions and flew into the sun :(	\N	t	\N	\N	\N	\N	\N	yes	1	8	0
25	Kieron Capocci-Hunt	Kieron Capocci-Hunt	\N	\N	13	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
1	Freddy Pitel	Freddy Pitel	fwbpitel@gmail.com	t	1	Groom	f	f	f	Gluten and dairy intollerance	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5
30	Nigel Pitel	Nigel Pitel	\N	\N	15	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
83	Giada Jordan	Giada Jordan	\N	\N	42	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
84	Lawrance Bailes	Lawrance Bailes	\N	\N	43	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
85	Chris Bradley	Chris Bradley	\N	\N	43	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
86	Richard Nicholson	Richard Nicholson	\N	\N	44	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
87	Helen Nicholson	Helen Nicholson	\N	\N	44	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
88	Cherie Fox	Cherie Fox	\N	\N	45	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
89	John Fox	John Fox	\N	\N	45	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
90	Timothy Finlay	Timothy Finlay	\N	\N	46	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
91	Eileen Finlay	Eileen Finlay	\N	\N	46	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
92	Oliver Nicholson	Oliver Nicholson	\N	\N	44	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
93	Ameila Pritchard	Ameila Pritchard	\N	\N	47	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
96	Roman Marych	Roman Marych	\N	\N	49	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
97	Julia Marych	Julia Marych	\N	\N	49	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
98	Julian Marych	Julian Marych	\N	\N	49	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
99	Daniel Calinski	Daniel Calinski	\N	\N	50	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
100	Angela Calinski	Angela Calinski	\N	\N	50	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
101	Ana Lu Calinksi	Ana Lu Calinksi	\N	\N	50	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
102	Adrian Gralak	Adrian Gralak	\N	\N	51	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
103	Michal Leczycki	Michal Leczycki	\N	\N	52	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
105	Beth Little	Beth Little	\N	\N	54	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
106	Martin Little	Martin Little	\N	\N	54	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
107	Harriet Little	Harriet Little	\N	\N	54	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
109	Debbie Fisher	Debbie Fisher	\N	\N	56	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
110	Evie Fisher	Evie Fisher	\N	\N	57	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
112	Charlie Fisher	Charlie Fisher	\N	\N	58	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
114	Katie Styles	Katie Styles	\N	\N	59	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
115	Tom Anderson	Tom Anderson	\N	\N	59	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
116	George Styles	George Styles	\N	\N	59	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
117	Wilf Styles	Wilf Styles	\N	\N	59	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
118	Tom Anderson	Tom Anderson	\N	\N	60	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
119	Sinead	Sinead	\N	\N	60	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
166	Gerry Lovelace	Gerry Lovelace	\N	\N	85	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
167	Sam Kenny	Sam Kenny	\N	\N	86	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
168	Anthony Whelan	Anthony Whelan	\N	\N	87	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
169	Elisabeth Swedlund	Elisabeth Swedlund	\N	\N	88	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
171	Jordan Murray	Jordan Murray	\N	\N	90	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
173	Marianne Baker	Marianne Baker	\N	\N	92	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
175	Kirsty Blythe	Kirsty Blythe	\N	\N	94	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
185	Louise O'Young	Louise O'Young	\N	\N	101	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
186	Dan Pope	Dan Pope	\N	\N	102	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
187	Mia Violentano	Mia Violentano	\N	\N	103	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
189	Rachel Dowse	Rachel Dowse	\N	\N	105	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
190	Nathan Williams	Nathan Williams	\N	\N	106	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
191	Lawrence Bishop	Lawrence Bishop	\N	\N	107	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
192	Jamie Jones	Jamie Jones	\N	\N	108	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
193	Nanditha Garge	Nanditha Garge	\N	\N	109	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
194	Lucy Williams	Lucy Williams	\N	\N	106	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
195	Corrine O'Connor	Corrine O'Connor	\N	\N	110	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
196	Matt O'Connor	Matt O'Connor	\N	\N	110	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
11	Sara Fisher	Sara Fisher	thefishers5725@gmail.com	t	3	Day Guest	f	f	f	\N	Happy wedding planning! Nth time is the charm!	\N	t	\N	\N	\N	\N	\N	yes	1	7	5
4	Mark Fisher	Mark Fisher	thefishers5725@gmail.com	t	3	Wedding Party	f	f	f	\N	Wahoo! It's working!	\N	t	\N	\N	\N	\N	\N	yes	1	7	5
170	Reuben Goldmark	Reuben Goldmark	reubengoldmark@gmail.com	t	89	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
172	Madeline MacLean	Madeline MacLean	madelinemaclean9@gmail.com	t	91	Day Guest	f	f	f	\N	I am incredibly excited and audibly hungry for this!! Can’t wait xx	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
10	Leah Burling	Leah Burling	leah.ann.king93@gmail.com	t	2	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	0	8	0
188	Ian Ang	Ian Ang	ianang1993@gmail.com	t	104	Day Guest	f	f	f	\N	Yummy yummy yummy I got yummy in my tummy	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
2	David Fox	David Fox	djwfox@gmail.com	t	1	Groom	f	f	f	no pork/shellfish	I love you!	\N	t	\N	\N	\N	\N	\N	yes	1	7	5
\.


--
-- Data for Name: households; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."households" ("id", "name", "code", "rsvp_sent", "accommodation_id", "invited_day_after", "invited_evening_before", "day_before_response", "day_after_response", "in_coach_house") FROM stdin;
107	Bishop	ALEL	t	\N	f	f	\N	\N	f
105	Dowse	ARKB	t	\N	f	f	\N	\N	f
91	MacLean	BBZM	t	\N	f	f	\N	\N	f
40	SB	BHUP	t	1	f	f	\N	\N	f
85	Lovelace	BLOX	t	\N	f	f	\N	\N	f
94	Blythe	BOLW	t	\N	f	f	\N	\N	f
30	Zedlewski	CCCM	t	6	f	f	\N	\N	f
25	Lyons	EKQE	t	23	f	f	\N	\N	f
37	Byford	DALP	t	8	f	f	\N	\N	f
104	Ang	DEND	t	\N	f	f	\N	\N	f
24	Sargent	FIVD	t	\N	f	f	\N	\N	f
103	Violentano	EICM	t	\N	f	f	\N	\N	f
101	O'Young	CSHH	t	\N	f	f	\N	\N	f
22	Blair	GWII	t	\N	f	f	\N	\N	f
7	Chodera	GXZU	t	\N	t	f	\N	\N	f
16	Pitel	HDDI	t	\N	t	f	\N	\N	f
33	Holtum	JATR	t	15	f	f	\N	\N	f
89	Goldmark	JRCU	t	\N	f	f	\N	\N	f
32	Hanvey	KCHT	t	9	f	f	\N	\N	f
35	Nutt	IRYU	t	6	f	f	\N	\N	f
38	Ebsworth	KPNH	t	9	f	f	\N	\N	f
56	Fisher	LNZX	t	\N	f	f	\N	\N	f
23	Paul	MNYS	t	\N	f	f	\N	\N	f
26	Paxton	NXDQ	t	6	f	f	\N	\N	f
29	Bartly	NCWV	t	24	f	f	\N	\N	f
59	Styles	ODFE	t	\N	t	f	\N	\N	f
39	Briscoe	OECP	t	\N	f	f	\N	\N	f
90	Murray	OJPB	t	\N	f	f	\N	\N	f
9	Hannaford	OYAW	t	19	f	f	\N	\N	f
11	Francis	OJBO	t	5	f	f	\N	\N	f
27	Vooght	PAJW	t	\N	f	f	\N	\N	f
87	Whelan	PCUN	t	\N	f	f	\N	\N	f
88	Swedlund	PQSM	t	\N	f	f	\N	\N	f
102	Pope	QGIU	t	\N	f	f	\N	\N	f
8	Quinn	PPLN	t	22	t	f	\N	\N	f
31	Dunnicliff	REZT	t	13	f	f	\N	\N	f
2	Burling	STCX	t	3	t	f	\N	\N	t
10	Barwick	QTNN	t	7	f	f	\N	\N	f
28	Burnett	RXEM	t	20	f	f	\N	\N	f
108	Jones	TMEH	t	\N	f	f	\N	\N	f
92	Baker	UMGQ	t	\N	f	f	\N	\N	f
18	Pitel	TCVD	t	\N	t	f	\N	\N	f
43	Bailes	UZYQ	t	\N	f	f	\N	\N	f
21	Sanders	VNNR	t	\N	f	f	\N	\N	f
106	Williams	WIWN	t	\N	f	f	\N	\N	f
6	Prichard	XOVG	t	17	t	f	\N	\N	f
3	Fisher	XLVR	t	2	t	f	\N	\N	f
109	Garge	XWMW	t	22	f	f	\N	\N	f
60	Anderson	XSKW	t	\N	t	f	\N	\N	f
86	Kenny	ZHXK	t	\N	f	f	\N	\N	f
15	Pitel	YSRN	t	\N	t	f	\N	\N	f
1	Pitel	MBWG	t	4	t	f	\N	\N	t
58	Fisher	CFJH	t	\N	t	f	\N	\N	f
57	Fisher	RTOE	t	\N	t	f	\N	\N	f
50	Calinski	XNNX	t	\N	t	f	\N	\N	f
49	Marych	XFKG	t	\N	t	f	\N	\N	f
17	Pitel	JVFF	t	\N	t	f	\N	\N	f
47	Pritchard	FGOZ	t	17	f	f	\N	\N	f
36	Wyles	BCQD	t	6	f	f	\N	\N	f
41	Saunders	YQVC	t	9	f	f	\N	\N	f
110	O'Connor	SOFF	t	\N	f	f	\N	\N	f
51	Gralak	FZBU	t	\N	t	f	\N	\N	f
34	Attwood	NISB	t	9	f	f	\N	\N	f
54	Little	ABKA	t	\N	f	f	\N	\N	f
52	Leczycki	IGBH	t	\N	t	f	\N	\N	f
13	Capocci-Hunt	FRGO	t	21	t	f	\N	\N	f
4	Masson	BMTD	t	14	t	f	\N	\N	f
12	Price-Dahlgren	HPLQ	t	11	f	f	\N	\N	f
14	Fox	BTLL	t	16	t	f	\N	\N	f
45	Fox	XQTY	t	\N	t	f	\N	\N	f
46	Finlay	MJRY	t	\N	t	f	\N	\N	f
44	Nicholson	CNJE	t	\N	f	f	\N	\N	f
42	Jordan	AKGN	t	10	f	f	\N	\N	f
5	Dunn	GNRA	t	12	t	f	\N	\N	f
20	Woolridge	CHNE	t	\N	f	f	\N	\N	f
19	Dunn	ULEM	t	\N	f	f	\N	\N	f
111	Munroe	XKCD	t	\N	f	f	\N	\N	\N
112	Clay	WOVN	f	\N	f	f	\N	\N	\N
113	Jones	RSQP	f	\N	f	f	\N	\N	\N
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."job_batches" ("id", "name", "total_jobs", "pending_jobs", "failed_jobs", "failed_job_ids", "options", "cancelled_at", "created_at", "finished_at") FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."jobs" ("id", "queue", "payload", "attempts", "reserved_at", "available_at", "created_at") FROM stdin;
1	default	{"uuid":"7b26b83f-e324-4fbb-943a-074570c5a085","displayName":"Closure (ContactController.php:18)","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"Illuminate\\\\Queue\\\\CallQueuedClosure","command":"O:34:\\"Illuminate\\\\Queue\\\\CallQueuedClosure\\":1:{s:7:\\"closure\\";O:47:\\"Laravel\\\\SerializableClosure\\\\SerializableClosure\\":1:{s:12:\\"serializable\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Signed\\":2:{s:12:\\"serializable\\";s:6840:\\"O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:5:\\"brevo\\";O:38:\\"App\\\\Services\\\\BrevoTransactionalService\\":1:{s:6:\\"\\u0000*\\u0000api\\";O:44:\\"SendinBlue\\\\Client\\\\Api\\\\TransactionalEmailsApi\\":3:{s:9:\\"\\u0000*\\u0000client\\";O:17:\\"GuzzleHttp\\\\Client\\":1:{s:25:\\"\\u0000GuzzleHttp\\\\Client\\u0000config\\";a:8:{s:7:\\"handler\\";O:23:\\"GuzzleHttp\\\\HandlerStack\\":3:{s:32:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000handler\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:35:\\"GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\":7:{s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:50;}s:50:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000selectTimeout\\";i:1;s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000active\\";i:0;s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000handles\\";a:0:{}s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000delays\\";a:0:{}s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000options\\";a:0:{}s:40:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000_mh\\";N;}s:4:\\"sync\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlHandler\\":1:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:3;}}}s:8:\\"function\\";s:285:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $sync): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options[\\\\GuzzleHttp\\\\RequestOptions::SYNCHRONOUS]) ? $default($request, $options) : $sync($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001ff0000000000000000\\";}s:9:\\"streaming\\";O:32:\\"GuzzleHttp\\\\Handler\\\\StreamHandler\\":1:{s:45:\\"\\u0000GuzzleHttp\\\\Handler\\\\StreamHandler\\u0000lastHeaders\\";a:0:{}}}s:8:\\"function\\";s:264:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $streaming): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options['stream']) ? $default($request, $options) : $streaming($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002010000000000000000\\";}s:30:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000stack\\";a:4:{i:0;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:1:{s:14:\\"bodySummarizer\\";N;}s:8:\\"function\\";s:839:\\"static function (callable $handler) use ($bodySummarizer): callable {\\n            return static function ($request, array $options) use ($handler, $bodySummarizer) {\\n                if (empty($options['http_errors'])) {\\n                    return $handler($request, $options);\\n                }\\n\\n                return $handler($request, $options)->then(\\n                    static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($request, $bodySummarizer) {\\n                        $code = $response->getStatusCode();\\n                        if ($code < 400) {\\n                            return $response;\\n                        }\\n                        throw \\\\GuzzleHttp\\\\Exception\\\\RequestException::create($request, $response, null, [], $bodySummarizer);\\n                    }\\n                );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002020000000000000000\\";}i:1;s:11:\\"http_errors\\";}i:1;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:144:\\"static function (callable $handler): \\\\GuzzleHttp\\\\RedirectMiddleware {\\n            return new \\\\GuzzleHttp\\\\RedirectMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002030000000000000000\\";}i:1;s:15:\\"allow_redirects\\";}i:2;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:1030:\\"static function (callable $handler): callable {\\n            return static function ($request, array $options) use ($handler) {\\n                if (empty($options['cookies'])) {\\n                    return $handler($request, $options);\\n                } elseif (!($options['cookies'] instanceof \\\\GuzzleHttp\\\\Cookie\\\\CookieJarInterface)) {\\n                    throw new \\\\InvalidArgumentException('cookies must be an instance of GuzzleHttp\\\\Cookie\\\\CookieJarInterface');\\n                }\\n                $cookieJar = $options['cookies'];\\n                $request = $cookieJar->withCookieHeader($request);\\n\\n                return $handler($request, $options)\\n                    ->then(\\n                        static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($cookieJar, $request): \\\\Psr\\\\Http\\\\Message\\\\ResponseInterface {\\n                            $cookieJar->extractCookies($request, $response);\\n\\n                            return $response;\\n                        }\\n                    );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002040000000000000000\\";}i:1;s:7:\\"cookies\\";}i:3;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:150:\\"static function (callable $handler): \\\\GuzzleHttp\\\\PrepareBodyMiddleware {\\n            return new \\\\GuzzleHttp\\\\PrepareBodyMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002050000000000000000\\";}i:1;s:12:\\"prepare_body\\";}}s:31:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000cached\\";N;}s:15:\\"allow_redirects\\";a:5:{s:3:\\"max\\";i:5;s:9:\\"protocols\\";a:2:{i:0;s:4:\\"http\\";i:1;s:5:\\"https\\";}s:6:\\"strict\\";b:0;s:7:\\"referer\\";b:0;s:15:\\"track_redirects\\";b:0;}s:11:\\"http_errors\\";b:1;s:14:\\"decode_content\\";b:1;s:6:\\"verify\\";b:1;s:7:\\"cookies\\";b:0;s:14:\\"idn_conversion\\";b:0;s:7:\\"headers\\";a:1:{s:10:\\"User-Agent\\";s:12:\\"GuzzleHttp\\/7\\";}}}s:9:\\"\\u0000*\\u0000config\\";O:31:\\"SendinBlue\\\\Client\\\\Configuration\\":10:{s:10:\\"\\u0000*\\u0000apiKeys\\";a:1:{s:7:\\"api-key\\";s:89:\\"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\\";}s:17:\\"\\u0000*\\u0000apiKeyPrefixes\\";a:0:{}s:14:\\"\\u0000*\\u0000accessToken\\";s:0:\\"\\";s:11:\\"\\u0000*\\u0000username\\";s:0:\\"\\";s:11:\\"\\u0000*\\u0000password\\";s:0:\\"\\";s:7:\\"\\u0000*\\u0000host\\";s:29:\\"https:\\/\\/api.sendinblue.com\\/v3\\";s:12:\\"\\u0000*\\u0000userAgent\\";s:31:\\"sendinblue_clientAPI\\/v8.4.2\\/php\\";s:8:\\"\\u0000*\\u0000debug\\";b:0;s:12:\\"\\u0000*\\u0000debugFile\\";s:12:\\"php:\\/\\/output\\";s:17:\\"\\u0000*\\u0000tempFolderPath\\";s:4:\\"\\/tmp\\";}s:17:\\"\\u0000*\\u0000headerSelector\\";O:32:\\"SendinBlue\\\\Client\\\\HeaderSelector\\":0:{}}}s:4:\\"data\\";a:3:{s:4:\\"name\\";s:24:\\"Freddy Pitel & David Fox\\";s:5:\\"email\\";s:13:\\"test@test.com\\";s:7:\\"message\\";s:26:\\"Main website comment test!\\";}}s:8:\\"function\\";s:90:\\"function () use ($brevo, $data) {\\n            $brevo->sendContactMessage($data);\\n        }\\";s:5:\\"scope\\";s:38:\\"App\\\\Http\\\\Controllers\\\\ContactController\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001f30000000000000000\\";}\\";s:4:\\"hash\\";s:44:\\"L0GSJZBx+ZPYobKzik3DcTBFcYKXzVgCE0JakSMeGik=\\";}}}","batchId":null},"createdAt":1774791002,"delay":null}	0	\N	1774791002	1774791002
2	default	{"uuid":"b8bd3c3b-475b-406e-aae5-d2890fa2a76d","displayName":"Closure (ContactController.php:18)","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"Illuminate\\\\Queue\\\\CallQueuedClosure","command":"O:34:\\"Illuminate\\\\Queue\\\\CallQueuedClosure\\":1:{s:7:\\"closure\\";O:47:\\"Laravel\\\\SerializableClosure\\\\SerializableClosure\\":1:{s:12:\\"serializable\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Signed\\":2:{s:12:\\"serializable\\";s:22468:\\"O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:5:\\"brevo\\";O:38:\\"App\\\\Services\\\\BrevoTransactionalService\\":1:{s:9:\\"\\u0000*\\u0000client\\";O:11:\\"Brevo\\\\Brevo\\":34:{s:7:\\"account\\";O:27:\\"Brevo\\\\Account\\\\AccountClient\\":2:{s:36:\\"\\u0000Brevo\\\\Account\\\\AccountClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Account\\\\AccountClient\\u0000client\\";O:27:\\"Brevo\\\\Core\\\\Client\\\\RawClient\\":6:{s:35:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000client\\";O:39:\\"Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\":4:{s:47:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000client\\";O:17:\\"GuzzleHttp\\\\Client\\":1:{s:25:\\"\\u0000GuzzleHttp\\\\Client\\u0000config\\";a:8:{s:7:\\"handler\\";O:23:\\"GuzzleHttp\\\\HandlerStack\\":3:{s:32:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000handler\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:35:\\"GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\":7:{s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:50;}s:50:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000selectTimeout\\";i:1;s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000active\\";i:0;s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000handles\\";a:0:{}s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000delays\\";a:0:{}s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000options\\";a:0:{}s:40:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000_mh\\";N;}s:4:\\"sync\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlHandler\\":1:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:3;}}}s:8:\\"function\\";s:285:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $sync): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options[\\\\GuzzleHttp\\\\RequestOptions::SYNCHRONOUS]) ? $default($request, $options) : $sync($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001ff0000000000000000\\";}s:9:\\"streaming\\";O:32:\\"GuzzleHttp\\\\Handler\\\\StreamHandler\\":1:{s:45:\\"\\u0000GuzzleHttp\\\\Handler\\\\StreamHandler\\u0000lastHeaders\\";a:0:{}}}s:8:\\"function\\";s:264:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $streaming): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options['stream']) ? $default($request, $options) : $streaming($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002010000000000000000\\";}s:30:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000stack\\";a:4:{i:0;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:1:{s:14:\\"bodySummarizer\\";N;}s:8:\\"function\\";s:839:\\"static function (callable $handler) use ($bodySummarizer): callable {\\n            return static function ($request, array $options) use ($handler, $bodySummarizer) {\\n                if (empty($options['http_errors'])) {\\n                    return $handler($request, $options);\\n                }\\n\\n                return $handler($request, $options)->then(\\n                    static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($request, $bodySummarizer) {\\n                        $code = $response->getStatusCode();\\n                        if ($code < 400) {\\n                            return $response;\\n                        }\\n                        throw \\\\GuzzleHttp\\\\Exception\\\\RequestException::create($request, $response, null, [], $bodySummarizer);\\n                    }\\n                );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002020000000000000000\\";}i:1;s:11:\\"http_errors\\";}i:1;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:144:\\"static function (callable $handler): \\\\GuzzleHttp\\\\RedirectMiddleware {\\n            return new \\\\GuzzleHttp\\\\RedirectMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002030000000000000000\\";}i:1;s:15:\\"allow_redirects\\";}i:2;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:1030:\\"static function (callable $handler): callable {\\n            return static function ($request, array $options) use ($handler) {\\n                if (empty($options['cookies'])) {\\n                    return $handler($request, $options);\\n                } elseif (!($options['cookies'] instanceof \\\\GuzzleHttp\\\\Cookie\\\\CookieJarInterface)) {\\n                    throw new \\\\InvalidArgumentException('cookies must be an instance of GuzzleHttp\\\\Cookie\\\\CookieJarInterface');\\n                }\\n                $cookieJar = $options['cookies'];\\n                $request = $cookieJar->withCookieHeader($request);\\n\\n                return $handler($request, $options)\\n                    ->then(\\n                        static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($cookieJar, $request): \\\\Psr\\\\Http\\\\Message\\\\ResponseInterface {\\n                            $cookieJar->extractCookies($request, $response);\\n\\n                            return $response;\\n                        }\\n                    );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002040000000000000000\\";}i:1;s:7:\\"cookies\\";}i:3;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:150:\\"static function (callable $handler): \\\\GuzzleHttp\\\\PrepareBodyMiddleware {\\n            return new \\\\GuzzleHttp\\\\PrepareBodyMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002050000000000000000\\";}i:1;s:12:\\"prepare_body\\";}}s:31:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000cached\\";N;}s:15:\\"allow_redirects\\";a:5:{s:3:\\"max\\";i:5;s:9:\\"protocols\\";a:2:{i:0;s:4:\\"http\\";i:1;s:5:\\"https\\";}s:6:\\"strict\\";b:0;s:7:\\"referer\\";b:0;s:15:\\"track_redirects\\";b:0;}s:11:\\"http_errors\\";b:1;s:14:\\"decode_content\\";b:1;s:6:\\"verify\\";b:1;s:7:\\"cookies\\";b:0;s:14:\\"idn_conversion\\";b:0;s:7:\\"headers\\";a:1:{s:10:\\"User-Agent\\";s:12:\\"GuzzleHttp\\/7\\";}}}s:51:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000maxRetries\\";i:2;s:50:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000baseDelay\\";i:1000;s:54:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000sleepFunction\\";s:6:\\"usleep\\";}s:43:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000requestFactory\\";O:27:\\"GuzzleHttp\\\\Psr7\\\\HttpFactory\\":0:{}s:42:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000streamFactory\\";O:27:\\"GuzzleHttp\\\\Psr7\\\\HttpFactory\\":0:{}s:36:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}s:43:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000getAuthHeaders\\";N;s:7:\\"options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}}}s:13:\\"masterAccount\\";O:39:\\"Brevo\\\\MasterAccount\\\\MasterAccountClient\\":2:{s:48:\\"\\u0000Brevo\\\\MasterAccount\\\\MasterAccountClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\MasterAccount\\\\MasterAccountClient\\u0000client\\";r:13;}s:4:\\"user\\";O:21:\\"Brevo\\\\User\\\\UserClient\\":2:{s:30:\\"\\u0000Brevo\\\\User\\\\UserClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:29:\\"\\u0000Brevo\\\\User\\\\UserClient\\u0000client\\";r:13;}s:7:\\"process\\";O:27:\\"Brevo\\\\Process\\\\ProcessClient\\":2:{s:36:\\"\\u0000Brevo\\\\Process\\\\ProcessClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Process\\\\ProcessClient\\u0000client\\";r:13;}s:7:\\"senders\\";O:27:\\"Brevo\\\\Senders\\\\SendersClient\\":2:{s:36:\\"\\u0000Brevo\\\\Senders\\\\SendersClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Senders\\\\SendersClient\\u0000client\\";r:13;}s:7:\\"domains\\";O:27:\\"Brevo\\\\Domains\\\\DomainsClient\\":2:{s:36:\\"\\u0000Brevo\\\\Domains\\\\DomainsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Domains\\\\DomainsClient\\u0000client\\";r:13;}s:8:\\"webhooks\\";O:29:\\"Brevo\\\\Webhooks\\\\WebhooksClient\\":2:{s:38:\\"\\u0000Brevo\\\\Webhooks\\\\WebhooksClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Webhooks\\\\WebhooksClient\\u0000client\\";r:13;}s:13:\\"externalFeeds\\";O:39:\\"Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\":2:{s:48:\\"\\u0000Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\u0000client\\";r:13;}s:13:\\"customObjects\\";O:39:\\"Brevo\\\\CustomObjects\\\\CustomObjectsClient\\":2:{s:48:\\"\\u0000Brevo\\\\CustomObjects\\\\CustomObjectsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\CustomObjects\\\\CustomObjectsClient\\u0000client\\";r:13;}s:8:\\"contacts\\";O:29:\\"Brevo\\\\Contacts\\\\ContactsClient\\":2:{s:38:\\"\\u0000Brevo\\\\Contacts\\\\ContactsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Contacts\\\\ContactsClient\\u0000client\\";r:13;}s:13:\\"conversations\\";O:39:\\"Brevo\\\\Conversations\\\\ConversationsClient\\":2:{s:48:\\"\\u0000Brevo\\\\Conversations\\\\ConversationsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\Conversations\\\\ConversationsClient\\u0000client\\";r:13;}s:9:\\"ecommerce\\";O:31:\\"Brevo\\\\Ecommerce\\\\EcommerceClient\\":2:{s:40:\\"\\u0000Brevo\\\\Ecommerce\\\\EcommerceClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:39:\\"\\u0000Brevo\\\\Ecommerce\\\\EcommerceClient\\u0000client\\";r:13;}s:7:\\"coupons\\";O:27:\\"Brevo\\\\Coupons\\\\CouponsClient\\":2:{s:36:\\"\\u0000Brevo\\\\Coupons\\\\CouponsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Coupons\\\\CouponsClient\\u0000client\\";r:13;}s:8:\\"payments\\";O:29:\\"Brevo\\\\Payments\\\\PaymentsClient\\":2:{s:38:\\"\\u0000Brevo\\\\Payments\\\\PaymentsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Payments\\\\PaymentsClient\\u0000client\\";r:13;}s:5:\\"event\\";O:23:\\"Brevo\\\\Event\\\\EventClient\\":2:{s:32:\\"\\u0000Brevo\\\\Event\\\\EventClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Event\\\\EventClient\\u0000client\\";r:13;}s:14:\\"inboundParsing\\";O:41:\\"Brevo\\\\InboundParsing\\\\InboundParsingClient\\":2:{s:50:\\"\\u0000Brevo\\\\InboundParsing\\\\InboundParsingClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:49:\\"\\u0000Brevo\\\\InboundParsing\\\\InboundParsingClient\\u0000client\\";r:13;}s:7:\\"balance\\";O:27:\\"Brevo\\\\Balance\\\\BalanceClient\\":2:{s:36:\\"\\u0000Brevo\\\\Balance\\\\BalanceClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Balance\\\\BalanceClient\\u0000client\\";r:13;}s:7:\\"program\\";O:27:\\"Brevo\\\\Program\\\\ProgramClient\\":2:{s:36:\\"\\u0000Brevo\\\\Program\\\\ProgramClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Program\\\\ProgramClient\\u0000client\\";r:13;}s:6:\\"reward\\";O:25:\\"Brevo\\\\Reward\\\\RewardClient\\":2:{s:34:\\"\\u0000Brevo\\\\Reward\\\\RewardClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:33:\\"\\u0000Brevo\\\\Reward\\\\RewardClient\\u0000client\\";r:13;}s:4:\\"tier\\";O:21:\\"Brevo\\\\Tier\\\\TierClient\\":2:{s:30:\\"\\u0000Brevo\\\\Tier\\\\TierClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:29:\\"\\u0000Brevo\\\\Tier\\\\TierClient\\u0000client\\";r:13;}s:14:\\"emailCampaigns\\";O:41:\\"Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\":2:{s:50:\\"\\u0000Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:49:\\"\\u0000Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\u0000client\\";r:13;}s:12:\\"smsCampaigns\\";O:37:\\"Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\":2:{s:46:\\"\\u0000Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:45:\\"\\u0000Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\u0000client\\";r:13;}s:17:\\"whatsAppCampaigns\\";O:47:\\"Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\":2:{s:56:\\"\\u0000Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:55:\\"\\u0000Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\u0000client\\";r:13;}s:9:\\"companies\\";O:31:\\"Brevo\\\\Companies\\\\CompaniesClient\\":2:{s:40:\\"\\u0000Brevo\\\\Companies\\\\CompaniesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:39:\\"\\u0000Brevo\\\\Companies\\\\CompaniesClient\\u0000client\\";r:13;}s:5:\\"deals\\";O:23:\\"Brevo\\\\Deals\\\\DealsClient\\":2:{s:32:\\"\\u0000Brevo\\\\Deals\\\\DealsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Deals\\\\DealsClient\\u0000client\\";r:13;}s:5:\\"files\\";O:23:\\"Brevo\\\\Files\\\\FilesClient\\":2:{s:32:\\"\\u0000Brevo\\\\Files\\\\FilesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Files\\\\FilesClient\\u0000client\\";r:13;}s:5:\\"notes\\";O:23:\\"Brevo\\\\Notes\\\\NotesClient\\":2:{s:32:\\"\\u0000Brevo\\\\Notes\\\\NotesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Notes\\\\NotesClient\\u0000client\\";r:13;}s:5:\\"tasks\\";O:23:\\"Brevo\\\\Tasks\\\\TasksClient\\":2:{s:32:\\"\\u0000Brevo\\\\Tasks\\\\TasksClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Tasks\\\\TasksClient\\u0000client\\";r:13;}s:21:\\"transactionalWhatsApp\\";O:55:\\"Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\":2:{s:64:\\"\\u0000Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:63:\\"\\u0000Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\u0000client\\";r:13;}s:19:\\"transactionalEmails\\";O:51:\\"Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\":2:{s:60:\\"\\u0000Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:59:\\"\\u0000Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\u0000client\\";r:13;}s:16:\\"transactionalSms\\";O:45:\\"Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\":2:{s:54:\\"\\u0000Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:53:\\"\\u0000Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\u0000client\\";r:13;}s:12:\\"smsTemplates\\";O:37:\\"Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\":2:{s:46:\\"\\u0000Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:45:\\"\\u0000Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\u0000client\\";r:13;}s:20:\\"\\u0000Brevo\\\\Brevo\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:19:\\"\\u0000Brevo\\\\Brevo\\u0000client\\";r:13;}}s:4:\\"data\\";a:3:{s:4:\\"name\\";s:24:\\"Freddy Pitel & David Fox\\";s:5:\\"email\\";s:16:\\"djwfox@gmail.com\\";s:7:\\"message\\";s:4:\\"Test\\";}}s:8:\\"function\\";s:90:\\"function () use ($brevo, $data) {\\n            $brevo->sendContactMessage($data);\\n        }\\";s:5:\\"scope\\";s:38:\\"App\\\\Http\\\\Controllers\\\\ContactController\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001f30000000000000000\\";}\\";s:4:\\"hash\\";s:44:\\"jA03I5E0qgT5TaoBboNEa63bj6z+wmoSJokgWyjNU44=\\";}}}","batchId":null},"createdAt":1774802751,"delay":null}	0	\N	1774802751	1774802751
3	default	{"uuid":"37ec9551-a1ca-4904-a465-b5b0d2d1fef6","displayName":"Closure (ContactController.php:18)","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"Illuminate\\\\Queue\\\\CallQueuedClosure","command":"O:34:\\"Illuminate\\\\Queue\\\\CallQueuedClosure\\":1:{s:7:\\"closure\\";O:47:\\"Laravel\\\\SerializableClosure\\\\SerializableClosure\\":1:{s:12:\\"serializable\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Signed\\":2:{s:12:\\"serializable\\";s:22577:\\"O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:5:\\"brevo\\";O:38:\\"App\\\\Services\\\\BrevoTransactionalService\\":1:{s:9:\\"\\u0000*\\u0000client\\";O:11:\\"Brevo\\\\Brevo\\":34:{s:7:\\"account\\";O:27:\\"Brevo\\\\Account\\\\AccountClient\\":2:{s:36:\\"\\u0000Brevo\\\\Account\\\\AccountClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Account\\\\AccountClient\\u0000client\\";O:27:\\"Brevo\\\\Core\\\\Client\\\\RawClient\\":6:{s:35:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000client\\";O:39:\\"Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\":4:{s:47:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000client\\";O:17:\\"GuzzleHttp\\\\Client\\":1:{s:25:\\"\\u0000GuzzleHttp\\\\Client\\u0000config\\";a:8:{s:7:\\"handler\\";O:23:\\"GuzzleHttp\\\\HandlerStack\\":3:{s:32:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000handler\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:35:\\"GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\":7:{s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:50;}s:50:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000selectTimeout\\";i:1;s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000active\\";i:0;s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000handles\\";a:0:{}s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000delays\\";a:0:{}s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000options\\";a:0:{}s:40:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000_mh\\";N;}s:4:\\"sync\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlHandler\\":1:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:3;}}}s:8:\\"function\\";s:285:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $sync): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options[\\\\GuzzleHttp\\\\RequestOptions::SYNCHRONOUS]) ? $default($request, $options) : $sync($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001ff0000000000000000\\";}s:9:\\"streaming\\";O:32:\\"GuzzleHttp\\\\Handler\\\\StreamHandler\\":1:{s:45:\\"\\u0000GuzzleHttp\\\\Handler\\\\StreamHandler\\u0000lastHeaders\\";a:0:{}}}s:8:\\"function\\";s:264:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $streaming): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options['stream']) ? $default($request, $options) : $streaming($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002010000000000000000\\";}s:30:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000stack\\";a:4:{i:0;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:1:{s:14:\\"bodySummarizer\\";N;}s:8:\\"function\\";s:839:\\"static function (callable $handler) use ($bodySummarizer): callable {\\n            return static function ($request, array $options) use ($handler, $bodySummarizer) {\\n                if (empty($options['http_errors'])) {\\n                    return $handler($request, $options);\\n                }\\n\\n                return $handler($request, $options)->then(\\n                    static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($request, $bodySummarizer) {\\n                        $code = $response->getStatusCode();\\n                        if ($code < 400) {\\n                            return $response;\\n                        }\\n                        throw \\\\GuzzleHttp\\\\Exception\\\\RequestException::create($request, $response, null, [], $bodySummarizer);\\n                    }\\n                );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002020000000000000000\\";}i:1;s:11:\\"http_errors\\";}i:1;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:144:\\"static function (callable $handler): \\\\GuzzleHttp\\\\RedirectMiddleware {\\n            return new \\\\GuzzleHttp\\\\RedirectMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002030000000000000000\\";}i:1;s:15:\\"allow_redirects\\";}i:2;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:1030:\\"static function (callable $handler): callable {\\n            return static function ($request, array $options) use ($handler) {\\n                if (empty($options['cookies'])) {\\n                    return $handler($request, $options);\\n                } elseif (!($options['cookies'] instanceof \\\\GuzzleHttp\\\\Cookie\\\\CookieJarInterface)) {\\n                    throw new \\\\InvalidArgumentException('cookies must be an instance of GuzzleHttp\\\\Cookie\\\\CookieJarInterface');\\n                }\\n                $cookieJar = $options['cookies'];\\n                $request = $cookieJar->withCookieHeader($request);\\n\\n                return $handler($request, $options)\\n                    ->then(\\n                        static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($cookieJar, $request): \\\\Psr\\\\Http\\\\Message\\\\ResponseInterface {\\n                            $cookieJar->extractCookies($request, $response);\\n\\n                            return $response;\\n                        }\\n                    );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002040000000000000000\\";}i:1;s:7:\\"cookies\\";}i:3;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:150:\\"static function (callable $handler): \\\\GuzzleHttp\\\\PrepareBodyMiddleware {\\n            return new \\\\GuzzleHttp\\\\PrepareBodyMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002050000000000000000\\";}i:1;s:12:\\"prepare_body\\";}}s:31:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000cached\\";N;}s:15:\\"allow_redirects\\";a:5:{s:3:\\"max\\";i:5;s:9:\\"protocols\\";a:2:{i:0;s:4:\\"http\\";i:1;s:5:\\"https\\";}s:6:\\"strict\\";b:0;s:7:\\"referer\\";b:0;s:15:\\"track_redirects\\";b:0;}s:11:\\"http_errors\\";b:1;s:14:\\"decode_content\\";b:1;s:6:\\"verify\\";b:1;s:7:\\"cookies\\";b:0;s:14:\\"idn_conversion\\";b:0;s:7:\\"headers\\";a:1:{s:10:\\"User-Agent\\";s:12:\\"GuzzleHttp\\/7\\";}}}s:51:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000maxRetries\\";i:2;s:50:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000baseDelay\\";i:1000;s:54:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000sleepFunction\\";s:6:\\"usleep\\";}s:43:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000requestFactory\\";O:27:\\"GuzzleHttp\\\\Psr7\\\\HttpFactory\\":0:{}s:42:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000streamFactory\\";O:27:\\"GuzzleHttp\\\\Psr7\\\\HttpFactory\\":0:{}s:36:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}s:43:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000getAuthHeaders\\";N;s:7:\\"options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}}}s:13:\\"masterAccount\\";O:39:\\"Brevo\\\\MasterAccount\\\\MasterAccountClient\\":2:{s:48:\\"\\u0000Brevo\\\\MasterAccount\\\\MasterAccountClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\MasterAccount\\\\MasterAccountClient\\u0000client\\";r:13;}s:4:\\"user\\";O:21:\\"Brevo\\\\User\\\\UserClient\\":2:{s:30:\\"\\u0000Brevo\\\\User\\\\UserClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:29:\\"\\u0000Brevo\\\\User\\\\UserClient\\u0000client\\";r:13;}s:7:\\"process\\";O:27:\\"Brevo\\\\Process\\\\ProcessClient\\":2:{s:36:\\"\\u0000Brevo\\\\Process\\\\ProcessClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Process\\\\ProcessClient\\u0000client\\";r:13;}s:7:\\"senders\\";O:27:\\"Brevo\\\\Senders\\\\SendersClient\\":2:{s:36:\\"\\u0000Brevo\\\\Senders\\\\SendersClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Senders\\\\SendersClient\\u0000client\\";r:13;}s:7:\\"domains\\";O:27:\\"Brevo\\\\Domains\\\\DomainsClient\\":2:{s:36:\\"\\u0000Brevo\\\\Domains\\\\DomainsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Domains\\\\DomainsClient\\u0000client\\";r:13;}s:8:\\"webhooks\\";O:29:\\"Brevo\\\\Webhooks\\\\WebhooksClient\\":2:{s:38:\\"\\u0000Brevo\\\\Webhooks\\\\WebhooksClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Webhooks\\\\WebhooksClient\\u0000client\\";r:13;}s:13:\\"externalFeeds\\";O:39:\\"Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\":2:{s:48:\\"\\u0000Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\u0000client\\";r:13;}s:13:\\"customObjects\\";O:39:\\"Brevo\\\\CustomObjects\\\\CustomObjectsClient\\":2:{s:48:\\"\\u0000Brevo\\\\CustomObjects\\\\CustomObjectsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\CustomObjects\\\\CustomObjectsClient\\u0000client\\";r:13;}s:8:\\"contacts\\";O:29:\\"Brevo\\\\Contacts\\\\ContactsClient\\":2:{s:38:\\"\\u0000Brevo\\\\Contacts\\\\ContactsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Contacts\\\\ContactsClient\\u0000client\\";r:13;}s:13:\\"conversations\\";O:39:\\"Brevo\\\\Conversations\\\\ConversationsClient\\":2:{s:48:\\"\\u0000Brevo\\\\Conversations\\\\ConversationsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\Conversations\\\\ConversationsClient\\u0000client\\";r:13;}s:9:\\"ecommerce\\";O:31:\\"Brevo\\\\Ecommerce\\\\EcommerceClient\\":2:{s:40:\\"\\u0000Brevo\\\\Ecommerce\\\\EcommerceClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:39:\\"\\u0000Brevo\\\\Ecommerce\\\\EcommerceClient\\u0000client\\";r:13;}s:7:\\"coupons\\";O:27:\\"Brevo\\\\Coupons\\\\CouponsClient\\":2:{s:36:\\"\\u0000Brevo\\\\Coupons\\\\CouponsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Coupons\\\\CouponsClient\\u0000client\\";r:13;}s:8:\\"payments\\";O:29:\\"Brevo\\\\Payments\\\\PaymentsClient\\":2:{s:38:\\"\\u0000Brevo\\\\Payments\\\\PaymentsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Payments\\\\PaymentsClient\\u0000client\\";r:13;}s:5:\\"event\\";O:23:\\"Brevo\\\\Event\\\\EventClient\\":2:{s:32:\\"\\u0000Brevo\\\\Event\\\\EventClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Event\\\\EventClient\\u0000client\\";r:13;}s:14:\\"inboundParsing\\";O:41:\\"Brevo\\\\InboundParsing\\\\InboundParsingClient\\":2:{s:50:\\"\\u0000Brevo\\\\InboundParsing\\\\InboundParsingClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:49:\\"\\u0000Brevo\\\\InboundParsing\\\\InboundParsingClient\\u0000client\\";r:13;}s:7:\\"balance\\";O:27:\\"Brevo\\\\Balance\\\\BalanceClient\\":2:{s:36:\\"\\u0000Brevo\\\\Balance\\\\BalanceClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Balance\\\\BalanceClient\\u0000client\\";r:13;}s:7:\\"program\\";O:27:\\"Brevo\\\\Program\\\\ProgramClient\\":2:{s:36:\\"\\u0000Brevo\\\\Program\\\\ProgramClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Program\\\\ProgramClient\\u0000client\\";r:13;}s:6:\\"reward\\";O:25:\\"Brevo\\\\Reward\\\\RewardClient\\":2:{s:34:\\"\\u0000Brevo\\\\Reward\\\\RewardClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:33:\\"\\u0000Brevo\\\\Reward\\\\RewardClient\\u0000client\\";r:13;}s:4:\\"tier\\";O:21:\\"Brevo\\\\Tier\\\\TierClient\\":2:{s:30:\\"\\u0000Brevo\\\\Tier\\\\TierClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:29:\\"\\u0000Brevo\\\\Tier\\\\TierClient\\u0000client\\";r:13;}s:14:\\"emailCampaigns\\";O:41:\\"Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\":2:{s:50:\\"\\u0000Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:49:\\"\\u0000Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\u0000client\\";r:13;}s:12:\\"smsCampaigns\\";O:37:\\"Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\":2:{s:46:\\"\\u0000Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:45:\\"\\u0000Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\u0000client\\";r:13;}s:17:\\"whatsAppCampaigns\\";O:47:\\"Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\":2:{s:56:\\"\\u0000Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:55:\\"\\u0000Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\u0000client\\";r:13;}s:9:\\"companies\\";O:31:\\"Brevo\\\\Companies\\\\CompaniesClient\\":2:{s:40:\\"\\u0000Brevo\\\\Companies\\\\CompaniesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:39:\\"\\u0000Brevo\\\\Companies\\\\CompaniesClient\\u0000client\\";r:13;}s:5:\\"deals\\";O:23:\\"Brevo\\\\Deals\\\\DealsClient\\":2:{s:32:\\"\\u0000Brevo\\\\Deals\\\\DealsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Deals\\\\DealsClient\\u0000client\\";r:13;}s:5:\\"files\\";O:23:\\"Brevo\\\\Files\\\\FilesClient\\":2:{s:32:\\"\\u0000Brevo\\\\Files\\\\FilesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Files\\\\FilesClient\\u0000client\\";r:13;}s:5:\\"notes\\";O:23:\\"Brevo\\\\Notes\\\\NotesClient\\":2:{s:32:\\"\\u0000Brevo\\\\Notes\\\\NotesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Notes\\\\NotesClient\\u0000client\\";r:13;}s:5:\\"tasks\\";O:23:\\"Brevo\\\\Tasks\\\\TasksClient\\":2:{s:32:\\"\\u0000Brevo\\\\Tasks\\\\TasksClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Tasks\\\\TasksClient\\u0000client\\";r:13;}s:21:\\"transactionalWhatsApp\\";O:55:\\"Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\":2:{s:64:\\"\\u0000Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:63:\\"\\u0000Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\u0000client\\";r:13;}s:19:\\"transactionalEmails\\";O:51:\\"Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\":2:{s:60:\\"\\u0000Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:59:\\"\\u0000Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\u0000client\\";r:13;}s:16:\\"transactionalSms\\";O:45:\\"Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\":2:{s:54:\\"\\u0000Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:53:\\"\\u0000Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\u0000client\\";r:13;}s:12:\\"smsTemplates\\";O:37:\\"Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\":2:{s:46:\\"\\u0000Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:45:\\"\\u0000Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\u0000client\\";r:13;}s:20:\\"\\u0000Brevo\\\\Brevo\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:19:\\"\\u0000Brevo\\\\Brevo\\u0000client\\";r:13;}}s:4:\\"data\\";a:3:{s:4:\\"name\\";s:25:\\"Mark Fisher & Sara Fisher\\";s:5:\\"email\\";s:24:\\"thefishers5725@gmail.com\\";s:7:\\"message\\";s:102:\\"There once was a man from Peru,\\r\\nWhose limericks end on line two!\\r\\n\\r\\nThere once was a man from Verdun.\\";}}s:8:\\"function\\";s:90:\\"function () use ($brevo, $data) {\\n            $brevo->sendContactMessage($data);\\n        }\\";s:5:\\"scope\\";s:38:\\"App\\\\Http\\\\Controllers\\\\ContactController\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001f30000000000000000\\";}\\";s:4:\\"hash\\";s:44:\\"zNIoK667vJV2dMAagJXXuxd0zc0tyzQWbPIJlcRoBqw=\\";}}}","batchId":null},"createdAt":1774803182,"delay":null}	0	\N	1774803182	1774803182
4	default	{"uuid":"aacc74eb-8e75-44f5-8095-ed485277a7ed","displayName":"Closure (ContactController.php:18)","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"Illuminate\\\\Queue\\\\CallQueuedClosure","command":"O:34:\\"Illuminate\\\\Queue\\\\CallQueuedClosure\\":1:{s:7:\\"closure\\";O:47:\\"Laravel\\\\SerializableClosure\\\\SerializableClosure\\":1:{s:12:\\"serializable\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Signed\\":2:{s:12:\\"serializable\\";s:22472:\\"O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:5:\\"brevo\\";O:38:\\"App\\\\Services\\\\BrevoTransactionalService\\":1:{s:9:\\"\\u0000*\\u0000client\\";O:11:\\"Brevo\\\\Brevo\\":34:{s:7:\\"account\\";O:27:\\"Brevo\\\\Account\\\\AccountClient\\":2:{s:36:\\"\\u0000Brevo\\\\Account\\\\AccountClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Account\\\\AccountClient\\u0000client\\";O:27:\\"Brevo\\\\Core\\\\Client\\\\RawClient\\":6:{s:35:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000client\\";O:39:\\"Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\":4:{s:47:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000client\\";O:17:\\"GuzzleHttp\\\\Client\\":1:{s:25:\\"\\u0000GuzzleHttp\\\\Client\\u0000config\\";a:8:{s:7:\\"handler\\";O:23:\\"GuzzleHttp\\\\HandlerStack\\":3:{s:32:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000handler\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:35:\\"GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\":7:{s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:50;}s:50:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000selectTimeout\\";i:1;s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000active\\";i:0;s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000handles\\";a:0:{}s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000delays\\";a:0:{}s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000options\\";a:0:{}s:40:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000_mh\\";N;}s:4:\\"sync\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlHandler\\":1:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:3;}}}s:8:\\"function\\";s:285:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $sync): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options[\\\\GuzzleHttp\\\\RequestOptions::SYNCHRONOUS]) ? $default($request, $options) : $sync($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001ff0000000000000000\\";}s:9:\\"streaming\\";O:32:\\"GuzzleHttp\\\\Handler\\\\StreamHandler\\":1:{s:45:\\"\\u0000GuzzleHttp\\\\Handler\\\\StreamHandler\\u0000lastHeaders\\";a:0:{}}}s:8:\\"function\\";s:264:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $streaming): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options['stream']) ? $default($request, $options) : $streaming($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002010000000000000000\\";}s:30:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000stack\\";a:4:{i:0;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:1:{s:14:\\"bodySummarizer\\";N;}s:8:\\"function\\";s:839:\\"static function (callable $handler) use ($bodySummarizer): callable {\\n            return static function ($request, array $options) use ($handler, $bodySummarizer) {\\n                if (empty($options['http_errors'])) {\\n                    return $handler($request, $options);\\n                }\\n\\n                return $handler($request, $options)->then(\\n                    static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($request, $bodySummarizer) {\\n                        $code = $response->getStatusCode();\\n                        if ($code < 400) {\\n                            return $response;\\n                        }\\n                        throw \\\\GuzzleHttp\\\\Exception\\\\RequestException::create($request, $response, null, [], $bodySummarizer);\\n                    }\\n                );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002020000000000000000\\";}i:1;s:11:\\"http_errors\\";}i:1;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:144:\\"static function (callable $handler): \\\\GuzzleHttp\\\\RedirectMiddleware {\\n            return new \\\\GuzzleHttp\\\\RedirectMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002030000000000000000\\";}i:1;s:15:\\"allow_redirects\\";}i:2;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:1030:\\"static function (callable $handler): callable {\\n            return static function ($request, array $options) use ($handler) {\\n                if (empty($options['cookies'])) {\\n                    return $handler($request, $options);\\n                } elseif (!($options['cookies'] instanceof \\\\GuzzleHttp\\\\Cookie\\\\CookieJarInterface)) {\\n                    throw new \\\\InvalidArgumentException('cookies must be an instance of GuzzleHttp\\\\Cookie\\\\CookieJarInterface');\\n                }\\n                $cookieJar = $options['cookies'];\\n                $request = $cookieJar->withCookieHeader($request);\\n\\n                return $handler($request, $options)\\n                    ->then(\\n                        static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($cookieJar, $request): \\\\Psr\\\\Http\\\\Message\\\\ResponseInterface {\\n                            $cookieJar->extractCookies($request, $response);\\n\\n                            return $response;\\n                        }\\n                    );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002040000000000000000\\";}i:1;s:7:\\"cookies\\";}i:3;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:150:\\"static function (callable $handler): \\\\GuzzleHttp\\\\PrepareBodyMiddleware {\\n            return new \\\\GuzzleHttp\\\\PrepareBodyMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002050000000000000000\\";}i:1;s:12:\\"prepare_body\\";}}s:31:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000cached\\";N;}s:15:\\"allow_redirects\\";a:5:{s:3:\\"max\\";i:5;s:9:\\"protocols\\";a:2:{i:0;s:4:\\"http\\";i:1;s:5:\\"https\\";}s:6:\\"strict\\";b:0;s:7:\\"referer\\";b:0;s:15:\\"track_redirects\\";b:0;}s:11:\\"http_errors\\";b:1;s:14:\\"decode_content\\";b:1;s:6:\\"verify\\";b:1;s:7:\\"cookies\\";b:0;s:14:\\"idn_conversion\\";b:0;s:7:\\"headers\\";a:1:{s:10:\\"User-Agent\\";s:12:\\"GuzzleHttp\\/7\\";}}}s:51:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000maxRetries\\";i:2;s:50:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000baseDelay\\";i:1000;s:54:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000sleepFunction\\";s:6:\\"usleep\\";}s:43:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000requestFactory\\";O:27:\\"GuzzleHttp\\\\Psr7\\\\HttpFactory\\":0:{}s:42:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000streamFactory\\";O:27:\\"GuzzleHttp\\\\Psr7\\\\HttpFactory\\":0:{}s:36:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}s:43:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000getAuthHeaders\\";N;s:7:\\"options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}}}s:13:\\"masterAccount\\";O:39:\\"Brevo\\\\MasterAccount\\\\MasterAccountClient\\":2:{s:48:\\"\\u0000Brevo\\\\MasterAccount\\\\MasterAccountClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\MasterAccount\\\\MasterAccountClient\\u0000client\\";r:13;}s:4:\\"user\\";O:21:\\"Brevo\\\\User\\\\UserClient\\":2:{s:30:\\"\\u0000Brevo\\\\User\\\\UserClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:29:\\"\\u0000Brevo\\\\User\\\\UserClient\\u0000client\\";r:13;}s:7:\\"process\\";O:27:\\"Brevo\\\\Process\\\\ProcessClient\\":2:{s:36:\\"\\u0000Brevo\\\\Process\\\\ProcessClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Process\\\\ProcessClient\\u0000client\\";r:13;}s:7:\\"senders\\";O:27:\\"Brevo\\\\Senders\\\\SendersClient\\":2:{s:36:\\"\\u0000Brevo\\\\Senders\\\\SendersClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Senders\\\\SendersClient\\u0000client\\";r:13;}s:7:\\"domains\\";O:27:\\"Brevo\\\\Domains\\\\DomainsClient\\":2:{s:36:\\"\\u0000Brevo\\\\Domains\\\\DomainsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Domains\\\\DomainsClient\\u0000client\\";r:13;}s:8:\\"webhooks\\";O:29:\\"Brevo\\\\Webhooks\\\\WebhooksClient\\":2:{s:38:\\"\\u0000Brevo\\\\Webhooks\\\\WebhooksClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Webhooks\\\\WebhooksClient\\u0000client\\";r:13;}s:13:\\"externalFeeds\\";O:39:\\"Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\":2:{s:48:\\"\\u0000Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\u0000client\\";r:13;}s:13:\\"customObjects\\";O:39:\\"Brevo\\\\CustomObjects\\\\CustomObjectsClient\\":2:{s:48:\\"\\u0000Brevo\\\\CustomObjects\\\\CustomObjectsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\CustomObjects\\\\CustomObjectsClient\\u0000client\\";r:13;}s:8:\\"contacts\\";O:29:\\"Brevo\\\\Contacts\\\\ContactsClient\\":2:{s:38:\\"\\u0000Brevo\\\\Contacts\\\\ContactsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Contacts\\\\ContactsClient\\u0000client\\";r:13;}s:13:\\"conversations\\";O:39:\\"Brevo\\\\Conversations\\\\ConversationsClient\\":2:{s:48:\\"\\u0000Brevo\\\\Conversations\\\\ConversationsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\Conversations\\\\ConversationsClient\\u0000client\\";r:13;}s:9:\\"ecommerce\\";O:31:\\"Brevo\\\\Ecommerce\\\\EcommerceClient\\":2:{s:40:\\"\\u0000Brevo\\\\Ecommerce\\\\EcommerceClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:39:\\"\\u0000Brevo\\\\Ecommerce\\\\EcommerceClient\\u0000client\\";r:13;}s:7:\\"coupons\\";O:27:\\"Brevo\\\\Coupons\\\\CouponsClient\\":2:{s:36:\\"\\u0000Brevo\\\\Coupons\\\\CouponsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Coupons\\\\CouponsClient\\u0000client\\";r:13;}s:8:\\"payments\\";O:29:\\"Brevo\\\\Payments\\\\PaymentsClient\\":2:{s:38:\\"\\u0000Brevo\\\\Payments\\\\PaymentsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Payments\\\\PaymentsClient\\u0000client\\";r:13;}s:5:\\"event\\";O:23:\\"Brevo\\\\Event\\\\EventClient\\":2:{s:32:\\"\\u0000Brevo\\\\Event\\\\EventClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Event\\\\EventClient\\u0000client\\";r:13;}s:14:\\"inboundParsing\\";O:41:\\"Brevo\\\\InboundParsing\\\\InboundParsingClient\\":2:{s:50:\\"\\u0000Brevo\\\\InboundParsing\\\\InboundParsingClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:49:\\"\\u0000Brevo\\\\InboundParsing\\\\InboundParsingClient\\u0000client\\";r:13;}s:7:\\"balance\\";O:27:\\"Brevo\\\\Balance\\\\BalanceClient\\":2:{s:36:\\"\\u0000Brevo\\\\Balance\\\\BalanceClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Balance\\\\BalanceClient\\u0000client\\";r:13;}s:7:\\"program\\";O:27:\\"Brevo\\\\Program\\\\ProgramClient\\":2:{s:36:\\"\\u0000Brevo\\\\Program\\\\ProgramClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Program\\\\ProgramClient\\u0000client\\";r:13;}s:6:\\"reward\\";O:25:\\"Brevo\\\\Reward\\\\RewardClient\\":2:{s:34:\\"\\u0000Brevo\\\\Reward\\\\RewardClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:33:\\"\\u0000Brevo\\\\Reward\\\\RewardClient\\u0000client\\";r:13;}s:4:\\"tier\\";O:21:\\"Brevo\\\\Tier\\\\TierClient\\":2:{s:30:\\"\\u0000Brevo\\\\Tier\\\\TierClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:29:\\"\\u0000Brevo\\\\Tier\\\\TierClient\\u0000client\\";r:13;}s:14:\\"emailCampaigns\\";O:41:\\"Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\":2:{s:50:\\"\\u0000Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:49:\\"\\u0000Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\u0000client\\";r:13;}s:12:\\"smsCampaigns\\";O:37:\\"Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\":2:{s:46:\\"\\u0000Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:45:\\"\\u0000Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\u0000client\\";r:13;}s:17:\\"whatsAppCampaigns\\";O:47:\\"Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\":2:{s:56:\\"\\u0000Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:55:\\"\\u0000Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\u0000client\\";r:13;}s:9:\\"companies\\";O:31:\\"Brevo\\\\Companies\\\\CompaniesClient\\":2:{s:40:\\"\\u0000Brevo\\\\Companies\\\\CompaniesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:39:\\"\\u0000Brevo\\\\Companies\\\\CompaniesClient\\u0000client\\";r:13;}s:5:\\"deals\\";O:23:\\"Brevo\\\\Deals\\\\DealsClient\\":2:{s:32:\\"\\u0000Brevo\\\\Deals\\\\DealsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Deals\\\\DealsClient\\u0000client\\";r:13;}s:5:\\"files\\";O:23:\\"Brevo\\\\Files\\\\FilesClient\\":2:{s:32:\\"\\u0000Brevo\\\\Files\\\\FilesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Files\\\\FilesClient\\u0000client\\";r:13;}s:5:\\"notes\\";O:23:\\"Brevo\\\\Notes\\\\NotesClient\\":2:{s:32:\\"\\u0000Brevo\\\\Notes\\\\NotesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Notes\\\\NotesClient\\u0000client\\";r:13;}s:5:\\"tasks\\";O:23:\\"Brevo\\\\Tasks\\\\TasksClient\\":2:{s:32:\\"\\u0000Brevo\\\\Tasks\\\\TasksClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Tasks\\\\TasksClient\\u0000client\\";r:13;}s:21:\\"transactionalWhatsApp\\";O:55:\\"Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\":2:{s:64:\\"\\u0000Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:63:\\"\\u0000Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\u0000client\\";r:13;}s:19:\\"transactionalEmails\\";O:51:\\"Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\":2:{s:60:\\"\\u0000Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:59:\\"\\u0000Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\u0000client\\";r:13;}s:16:\\"transactionalSms\\";O:45:\\"Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\":2:{s:54:\\"\\u0000Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:53:\\"\\u0000Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\u0000client\\";r:13;}s:12:\\"smsTemplates\\";O:37:\\"Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\":2:{s:46:\\"\\u0000Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:45:\\"\\u0000Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\u0000client\\";r:13;}s:20:\\"\\u0000Brevo\\\\Brevo\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:19:\\"\\u0000Brevo\\\\Brevo\\u0000client\\";r:13;}}s:4:\\"data\\";a:3:{s:4:\\"name\\";s:24:\\"Freddy Pitel & David Fox\\";s:5:\\"email\\";s:16:\\"djwfox@gmail.com\\";s:7:\\"message\\";s:8:\\"Ho there\\";}}s:8:\\"function\\";s:90:\\"function () use ($brevo, $data) {\\n            $brevo->sendContactMessage($data);\\n        }\\";s:5:\\"scope\\";s:38:\\"App\\\\Http\\\\Controllers\\\\ContactController\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001f30000000000000000\\";}\\";s:4:\\"hash\\";s:44:\\"bGVx798lmcrbB5uNKqwgekSIbMnM9D012+3vr3NrsKQ=\\";}}}","batchId":null},"createdAt":1774806096,"delay":null}	0	\N	1774806096	1774806096
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."migrations" ("id", "migration", "batch") FROM stdin;
1	0001_01_01_000000_create_users_table	1
2	0001_01_01_000001_create_cache_table	1
3	0001_01_01_000002_create_jobs_table	1
4	2025_07_01_154723_create_guests_table	1
5	2025_07_01_173029_create_households_table	1
6	2025_12_26_095436_add-to-guests	2
7	2025_12_26_102608_accommodation	2
8	2025_12_26_120051_household_accommodation	2
9	2025_12_26_160339_add-to-guests-orig-name	2
10	2025_12_26_162014_add-to-households-extra-invites	2
11	2025_12_26_163747_add-to-guests-extra-invites	2
12	2025_12_26_215338_create_food_choices	2
13	2026_02_27_175928_add_coach_house_column	3
14	2026_04_04_215429_create_personal_access_tokens_table	4
15	2026_04_04_215748_create_train_configs_table	4
16	2026_04_04_215946_create_train_jokes_table	4
17	2026_04_04_220006_create_train_affirmations_table	4
18	2026_04_04_220012_create_train_events_table	4
19	2026_04_04_220020_create_train_slideshows_table	4
20	2026_04_04_220024_create_train_gifs_table	4
21	2026_04_04_220056_create_train_secrets_table	4
22	2026_08_28_145719_create_train_comments_table	5
23	2026_08_28_150751_add_enabled_column	5
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."password_reset_tokens" ("email", "token", "created_at") FROM stdin;
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."personal_access_tokens" ("id", "tokenable_type", "tokenable_id", "name", "token", "abilities", "last_used_at", "expires_at", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: seating; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."seating" ("id", "table", "position") FROM stdin;
1	1	1
2	1	2
3	1	3
4	1	4
5	1	5
6	1	6
7	1	7
8	1	8
9	1	9
10	1	10
11	1	11
12	1	12
13	2	1
14	2	2
15	2	3
16	2	4
17	2	5
18	2	6
19	2	7
20	2	8
21	2	9
22	2	10
23	2	11
24	2	12
25	3	1
26	3	2
27	3	3
28	3	4
29	3	5
30	3	6
31	3	7
32	3	8
33	3	9
34	3	10
35	3	11
36	3	12
37	4	1
38	4	2
39	4	3
40	4	4
41	4	5
42	4	6
43	4	7
44	4	8
45	4	9
46	4	10
47	4	11
48	4	12
49	5	1
50	5	2
51	5	3
52	5	4
53	5	5
54	5	6
55	5	7
56	5	8
57	5	9
58	5	10
59	5	11
60	5	12
61	6	1
62	6	2
63	6	3
64	6	4
65	6	5
66	6	6
67	6	7
68	6	8
69	6	9
70	6	10
71	6	11
72	6	12
73	7	1
74	7	2
75	7	3
76	7	4
77	7	5
78	7	6
79	7	7
80	7	8
81	7	9
82	7	10
83	7	11
84	7	12
85	8	1
86	8	2
87	8	3
88	8	4
89	8	5
90	8	6
91	8	7
92	8	8
93	8	9
94	8	10
95	8	11
96	8	12
97	9	1
98	9	2
99	9	3
100	9	4
101	9	5
102	9	6
103	9	7
104	9	8
105	9	9
106	9	10
107	9	11
108	9	12
109	10	1
110	10	2
111	10	3
112	10	4
113	10	5
114	10	6
115	10	7
116	10	8
117	10	9
118	10	10
119	10	11
120	10	12
121	11	1
122	11	2
123	11	3
124	11	4
125	11	5
126	11	6
127	11	7
128	11	8
129	11	9
130	11	10
131	11	11
132	11	12
133	12	1
134	12	2
135	12	3
136	12	4
137	12	5
138	12	6
139	12	7
140	12	8
141	12	9
142	12	10
143	12	11
144	12	12
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."sessions" ("id", "user_id", "ip_address", "user_agent", "payload", "last_activity") FROM stdin;
GTpJy6uGyMb33gesgVTgjaczxon1KkrCiERibhi6	\N	192.155.90.220	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTVlaazczUmRZQlRHc2dIZHV0dENXcFNZazB1NlZnd1MwSjNqSWxIcyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789983540
7M8KF6t9TTOJfSTcgjhhoD5PnaIcu51UpSUnnsnj	\N	90.243.131.226	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_1) AppleWebKit/601.2.4 (KHTML, like Gecko) Version/9.0.1 Safari/601.2.4 facebookexternalhit/1.1 Facebot Twitterbot/1.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWmNvNnV4YXVDOVJXbktKQW1zRWN3enpscmZ0R2YxSGxaTXdUcjNHUSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1789993574
WayEZAbhc1YjKseueXZHJJxK3XaEa1XWrHleYWMJ	\N	178.62.243.153	Mozilla/5.0 (compatible; ForestEngine/1.0; +https://forestengine.net/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoibTNBRDlhV1RyTEQ1ZzU2ZWlGYTZ0cUNiQzZkS1lia3ZMdDk1bjNNcyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790003829
sIJA2mWQP7ngsk9ujmIo6LsDeo2tpwTK2NKJAH1R	\N	8.138.210.144	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoid2JSd29kdnBPemw2Q1NGVFE1b2lHbkJObk9adUJOQ1hxbG82YkJrTyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790014193
9ILrAkeLdG59i0JvUJGkf6Z5joVc60Z5FOvk4B3M	\N	205.210.31.214	Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUUFKbm56QTVQU3lXRFNLampqRUxuYk85R01KV2luTTVVMkhlck1SYyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790014269
Cd3YKveQEimjvFfJlftRAu57iYkBXhWXvHNDH8We	\N	172.236.228.218	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiY3c2dDh2WEZUUlkxdmpIa2k3OFNEYkQyTnEzSVlWSE1FTE1YRHVYVSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790027553
1lRm8WCzeudChsFz8ebzpKa3byLfgAlHvnDX4EFH	\N	102.220.161.89	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoidVdPOEEyaTBaT2NHMnNQQmdMTjNxQ0M2aEJXaGNBWUdOa2FEeUVwbiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790044607
vFnbYrEpPPL8oCR0JW0ZJzhA88rnzFBRcqSZY3cU	\N	198.244.240.217	Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVHhSVVZSSTVLWFRWQjdEOUNHTXhlZkZFVXhucHRGelRZdWhrVEhEUCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790044637
oJ3sv5CB9U1mkKgZIzip8GmxqXmC8ZXcONdzM3yl	\N	207.180.252.31	Mozilla/5.0 (X11; Linux x86_64; rv:135.0) Gecko/20100101 Firefox/135.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiT3BBbTVrYkczQ3U2S1VNcG1YSkhFMllsZE5Xa1pxRHRyRjZxNzVMdCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790051745
y2vdBukTBy8vIDEGgJNbBOwUZOfkokcaMLgKOJAL	\N	66.240.236.109	Mozilla/5.0 zgrab/0.x	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVllhRzd6Mkw0MDlFSHJ1Q09ZNExLQWFBbEVaT0d6UnhERTB0MXhCdSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790071345
n51tTUy7Anpty6XX2ftg6gdhLi3MVly0bVhJ2zUw	\N	47.245.143.108	curl/7.64.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZEpBTU9KSEd0MEI0RWNManA3c0VmTHVxZFJOdXNQbzU1YzVKNVV3MiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789983770
ZFq8iRoAavB5kFIQk3oYAOiAiPLl887n9CoFwBlw	\N	47.245.143.108	curl/7.74.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiN29mWHAwZkcyTFB0NHp6MU14cTUxdnRrSUM3UUtRUTRMQnNMNENaWCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789983770
ongBLVXR2V8yJa1tquwKbBr1SFsG0kkqmUV4HROT	\N	144.202.92.17	Mozilla/5.0 (compatible; CyberConvoyScout/1.0; +https://scout.cyberconvoy.co)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNkRuQ2IyZk9mTjBzeXpjekVzdVZzTFJWNE5oWlkwajByOHJwVUFXUSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789994747
qgyrgUFn540WvYt0hHpNRzVMHhmHfzqHczKlUD89	\N	172.235.41.245	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUlZyUFNSYWxzN3dYSXVYT0lqckNBaU95blVXbm5oczRlczczRFZWQyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789994800
Z8o5Fj3eAxnnpemIABKmf9rcaQ79rx6yfRPDaTEo	\N	173.255.225.25	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWXRkUk1nMHFTN1dTejk4bmF5MGFzdjRLeUpvZlczeEZaZjMzSWFzcyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790004968
URSAgX3d6oItON3eJZaJQz9041L1i8LfdXIesyAg	\N	213.209.159.175	Mozilla/5.0 (Linux; U; Android 2.3.5; pt-br; GT-S5360B Build/GINGERBREAD) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZTFOeVY2QzB5VW5GMUNzaE1xcmw2dGJYSXNSWnRFWmMyejBiTWwxeCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790005013
3if8ySminhDHY2pf7N2K0TsZLW2gEIEYG8yGgpIs	\N	213.209.159.175	Mozilla/5.0 (Linux; U; Android 2.3.5; pt-br; GT-S5360B Build/GINGERBREAD) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiN09zNVBNNEp5bER5UGVoZHh0VW9RdGc0b3BzNFJlcm1QeE5YWkl5eCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS8/cGhwaW5mbz0tMSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790005013
zJTh62KrfUpDr4JrDl7wgz75zzTlfIMooB3GOOKr	\N	213.209.159.175	Mozilla/5.0 (Linux; U; Android 2.3.5; pt-br; GT-S5360B Build/GINGERBREAD) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQXJadXRMeXJiT3NDUXh5M0pJUjFGbjFFUDl0YkR4dnNXZEZwRFVtZSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS8/dXJsPS5lbnYiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790005014
l5B43BYPv5Wgiw2AojGTPFGbM2boKY1k1FtRnsX3	\N	172.235.40.131	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTURpSWYzS3dQM3p4WWlQUUhUMk9Ec3k1eVBqMTVRbG51blpVWmtzQiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790014684
QarC1Y7QvW0E83vsvLkhqh48cNKPh4cs6hd3E5hk	\N	172.232.108.36	Mozilla/5.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQWRjWlhPUmlNbkRmTktSa3ZnSlJQcDdoR3prc1lWWEd3VWtqbW1SeSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790027902
fDE6Qf8CXYw5U7zBaFFGzaLWsVL8GB2USabCHHgO	\N	18.116.101.220	visionheight.com/scan Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/126.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoib3ZHSlhjSmtxZlUwc1N1cWxXcm10MDZpbzVSQThVN2ttTGlrUzhmciI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790044757
eArkHBm1QdmjUfApTmu8HAKafZpYdvjrnhrEKr21	\N	159.223.225.36	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36 ForestEngine/1.0 (+https://forestengine.net/#opt-out)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRmFQcmxESHVaVFF0elkyTzlBWjJKNmRjdUROWkhIVVdHWmtyMmpsciI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790052797
FJebWxFp8p3ohB9xPxjKt2IKF3B6xhTF362OBIk1	\N	175.178.110.121	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOXRVdTRDQ0hNQk1CV1N1MEl5SjVvaTNoY3FPQjU0dUN2OFFYVUpmSyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790057315
9oo9TbI33r9aDodRnErwlWV0w76rk7SkXuqU3m54	\N	31.53.245.68	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_1) AppleWebKit/601.2.4 (KHTML, like Gecko) Version/9.0.1 Safari/601.2.4 facebookexternalhit/1.1 Facebot Twitterbot/1.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTEY2Z2FUTFZOQWtsclFobWNaamc4cUVEc2hEcEF0MFNNTHNvUXdUeSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1789984133
o9psD9EosuNwEvnKnTQyOVXrYhiQbxOYwAYmkEpa	\N	77.91.122.9	Mozilla/5.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiY0xWYU5jRnlPNVhackpvWGRkQXdmeHJRV3BPN1lCNDFBYWNvcTkzZSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1789994963
8cytk6lxJ17nnVb7ui7bVpMZmvhxMyS5AUWfQUnD	\N	16.5.0.239	Mozilla/5.0 (compatible; FlowIQ/1.0; +https://flowiq-labs.com/scanning-info)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiaDB6dnlDOG5OYlJmM2RsS2V4N3lNWU1lenEzYnh4ODgwbENpRko3NCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789995013
CPWwi45vcMM0f7jSrUzcY7mdOr6HsmoAoeRhy6aL	\N	34.132.43.231	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiM1hvSFhibnZjNE1jOHJWUDIxUlIwS3dIZGpWVTlyNGdndnU3Tk9aWCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790005566
Ak7lN7fTHt8kruRv0KyMVUDXF9IrNy70yROvJYX1	\N	34.132.43.231	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiT09wZHJOYzJBRm5TR2xnMU9QMFY1dGxaRlpXUzFLSGR4OUZVN0IxZCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790005570
onpL61JvmxqWTNkQnaT72djVnzV72LcbtTXKWYPO	\N	71.6.142.213	Mozilla/5.0 zgrab/0.x	YTozOntzOjY6Il90b2tlbiI7czo0MDoicTV3amZNWFZCYnA3NXJGT0NXSndNTnVkdTh2VDBNTE9WbUdVSkRTTCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790017570
QRgIDLb309CgtZQYjlhOsThj2zHU6nJHOIV6DtOW	\N	185.191.171.1	Mozilla/5.0 (compatible; SemrushBot/7~bl; +http://www.semrush.com/bot.html)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSk9FdENOQlRkQ3pNQ0ZMT3dlQnpIbzAyOU94QU5EUnJoMlFxdTFTcCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3RpbWVsaW5lIjtzOjU6InJvdXRlIjtzOjg6InRpbWVsaW5lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790028510
yluOFfeBsE7fhzY1M20vku8XU2ZZzJzKi9JkmHSU	\N	213.230.86.43	Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:122.0) Gecko/20100101 Firefox/122.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiek5aU29pd1o4QVUwa0YySXFIVHdyd3Y0TFdabFZZSXN6R1VUSlpHOCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790045482
2Np8h68zVjTFIJ208u7OLF7ns4XlwncfyCPxZ8aY	\N	43.106.48.229	libredtail-http	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVGdhemk0SmtqaU96QnJoZzdlQTU5TTNZQ29ad2NFcmFRRVlnc0ZCaSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTQ3OiJodHRwczovLzE3OC42Mi44Ny4yMTkvaW5kZXgucGhwP2Z1bmN0aW9uPWNhbGxfdXNlcl9mdW5jX2FycmF5JnM9JTJGaW5kZXglMkYlNUN0aGluayU1Q2FwcCUyRmludm9rZWZ1bmN0aW9uJnZhcnMlNUIwJTVEPW1kNSZ2YXJzJTVCMSU1RCU1QjAlNUQ9SGVsbG8iO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790053207
dLbQ9l6hmS8sj2SXtXNWWZa1MVFn4WCmiMR0Zqki	\N	43.173.1.69	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoieVlDZXFDeTVTNXlkVWFhNUJ3VGZueXhWQTY5ckl4OVNJb2NndkxWUiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790059817
VAG2N9Ikp2rzD8N3RSZA0XBzlfoyxSDuH6lM9pVG	\N	185.218.86.25	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiaGtOMWpBbXY0VVM1WlhrQUhQd01vd29hUjVwQnRsdThHOW03Z3dWRSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790071753
u7H5f7ApRSGu04libhPpNNdxCSK7K53Ob0jz0HTa	\N	43.165.7.74	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ0tpc0Y1RUJUTHBzQnQzb1owTUhoQ1dHeG5ldENqczZvUVVIU0NEMyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790075794
Bxq1InqEENIDBz7CLOnDCpHOg1yx8sa7GyOzHRDK	\N	35.234.18.34	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoidG1FQnRldExIRVNqakhlOXRmampGMk14UjZCeUFzN2d1bmRyZ1RiRSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzI6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL2xvZ2luIjtzOjU6InJvdXRlIjtzOjU6ImxvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozNjoiaHR0cHM6Ly9mcmVkZHlhbmRkYXZpZC5jb20vZGFzaGJvYXJkIjt9fQ==	1790075909
Dg1uIPJlahicZ1LliSAnIp1FOmWGSo2DTJ8LTa7F	\N	49.36.144.195	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Mobile Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZHhuNWNaWGtFOGo5ZmsxYzIxRlVidjBIZnBnQmZlV2N3TXhjUlJEbSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3RpbWVsaW5lIjtzOjU6InJvdXRlIjtzOjg6InRpbWVsaW5lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789977189
33TOMbbBNjXupGUreODee5RI8SdnVxGXUyEMgmW1	\N	43.133.66.51	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoibnE1eFhIallma3lhSnBqTFZPdXU0dTd5aU5SYTJHY0M5bFFyczlKQSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1789984893
f94U21fy5XgvTYytrFtqgEj3Btdlx5toTe5Mku1y	\N	198.235.24.115	Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVXlUeGY1M0w0OFZaM0FjRHFPTHc2T0JRM2tCT3RFcThBWE5HcXZQciI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789995752
UCONgawk0Xoyv9nzK8GjcHAkWIQk53kjMHB6H3vu	\N	34.140.3.155	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoidmFUZnZPV2dqdEdzbkUwV0dGdG9wVGJ2cGJES1dUbEJnNTd5V3ZoNCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790007103
I60jNAKZY5IWOR4VhpHHqPHMlTCIDDVBP7fLfZi0	\N	46.105.48.30	Mozilla/5.0 (compatible; MJ12bot/v2.0.5; http://mj12bot.com/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUU5TUFo2SGd0ZGcxWTJ1U3pIOXRoSW1obWZ2dE9ya0lHWWd1T0tYTiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790018630
1L2LlxmBlElhOXOqMafBb4Ymbhv6JyvYy0jAaCb0	\N	107.150.99.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/113.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZnBiZWR6cHIxTEFreWlKVEZNOURKMEpOVnN1cUR1NDhkVG44a3hWZiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790018749
eB3pkLMNsheQrlPImcUBgl77vCGZeNaUjAw36zYz	\N	152.37.100.7	Mozilla/5.0 (X11; Linux x86_64; rv:156.0) Gecko/20100101 Firefox/156.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTXZwTmlvc2JUbFI4a29vWGFHbUVramN0VHpScG5jbHRIRFROd0VFRiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3RjZyI7czo1OiJyb3V0ZSI7czozOiJ0Y2ciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790029049
To99p5ouivyXwu3uKTFIGwqGY0Gf85VcPvfd7KcG	\N	94.154.43.84	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQzVReHJ6SHhPaDFubFpZcVBsNHZYTVM1YVk0YjBWWTBwMFVNZ1NWaSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790045899
tr1vh5KIoLBBroELnmM3RdAoEjQsBcyXeTZGOfv0	\N	50.116.49.221	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUVpENFllU0lxUml5SHYzRUFoVFZXdk9IQjNTS1V2a1FQb1NrSGt4WiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790054890
nF2UagUkohuRGFgg01ZrFWZprYlsslZtr4JtZiuX	\N	185.73.23.162	Software Security Research/1.0 (+https://reverse-proxies-measurements.softsec.ruhr-uni-bochum.de)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZkkxNjRJYkVKMG1xZElUSEV6Q3M3SGNVUjhWVHpiV3NMQ3k3T0k5ZCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZmxvd2VzcG9ydHMyNDcuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1789980395
ZquygtB4gS0GUJOYUeK3gpgnchPYYNvSMpPLi7OA	\N	45.63.4.69	Mozilla/5.0 (compatible; CyberConvoyScout/1.0; +https://scout.cyberconvoy.co)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQjdXblZvV2dEcmdyNGNPN2RIa2RuQVRLV3RicXFia0VZYU1qcU5TQyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789985304
2JjvQs44SDnWdhn9kyckhukgCQHDRjtgVu8889A0	\N	74.7.242.8	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.4; +https://openai.com/gptbot)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRlZtUHNVNnZEZHlNREpKdTBwdVh0MGJqbnF6TFo2NGdBTHV3SzFIMCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3RpbWVsaW5lIjtzOjU6InJvdXRlIjtzOjg6InRpbWVsaW5lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789997270
Kfnf99qdkCpRYudNGe8wUVsesTWPVvfSzgjvIZzo	\N	152.32.128.204	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiak5wQ28yMlNueU9NclVua2JTOGd4OU1rRVpoMUc1cWVYRTZmR2RBUSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790008484
6uq3FiIG0yVlUKgDzexmRewXu4k69x0xk0paly6f	\N	172.236.228.197	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWmNXWjgwS2VTWmRMYzdXRFc5THJDSlZNZzlrNlo4amJsV3N3YU8xUyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790020157
u23UD37iHCpRzEujaeTQKmZWg2Vwyr5riIYEQfd2	\N	34.185.193.129	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZGJyOXZiRGF2VHdtcDlpbXY4a1Y2MDhzY05FblNiMld1SUxQdEdDZSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790031217
8z53ZkYy79NPyQA1eSRrT0xJsMY2WkkF6AHXbpbj	\N	199.45.154.67	Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ1RUczlKZXhtZU11QXNHZTN4d0JtQXdLTVN4UUJoQlNUZUc3c2NHdyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790046466
lfj0ap7eZQmKsTMK06r8WLuHXGSC8qDuBYgyByac	\N	77.91.71.9	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRUlpU1Eza3A0V2FEV3RDcTJZVkt6UGJRTGs1VzhmVWJ3aTRXWHRMSCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790046471
qC8oB7iPdWnREyskEM46Wge6OmWIkRKW8iJFXnqo	\N	77.91.71.9	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiT3RxN21raEszclpZSjZnYlpXQzNJVmwxb05EZk1EQ1NqdHhYQlRpNSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790046471
ZUW6x0cHSjPGHDc38ERU213yaDyRIhvdYF0PWUQF	\N	71.6.134.230	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNWdBTXhGUG9Jd2xxWjlna293bXpkVEhNUHFkNUZDemdMYVJGWW9uUyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790055699
J0U7dckMix0eaqeoU8pXsp69V2ndPlrASnfM4Ggi	\N	66.228.53.162	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSTR4bndPZFBJUEc4N0cwTXlGbjlzb3BvVFlHdVhRcGR4UXNJWnR4TiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790055760
eZc3g6Uo12bJwV9R6B1AImVwbNBY3ZgGlnysuF1r	\N	47.89.193.162	Mozilla/5.0 (Linux; Android 11; M2004J15SC) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.114 Mobile Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiY0dKbkZ5M3ZITVRXd3VXRUMwTHpoQTRSTWlYaEtNajI3WWMwdVZHNyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790062773
FRbak5xF6Kydt3nmNKsBuHENVFuY3LBqKcObwp1x	\N	172.104.11.51	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMHVMUWdONmtGcEZCMGVwOFZSOXRlMnZNaXZ0d0NhWklrWWZpdEhBMyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790062814
oon0IzK2gYh8PAxpjzfoIpIDRlx4BMlh2EU2p7QA	\N	185.73.23.162	Software Security Research/1.0 (+https://reverse-proxies-measurements.softsec.ruhr-uni-bochum.de)	YTozOntzOjY6Il90b2tlbiI7czo0MDoia1pzZ2pYS2NPUWswd2xxRmJLR1ZBRHY1alJxZTlFRFdFRTd2UDlyZyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vYm9yYXNrYXR0ZW4uc2UiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1789981260
sgWKoVMPKkEaHF3o3QWXsbOiIuEFZw4NgHKLLDGB	\N	66.249.64.129	Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.8010.47 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVHRqM0duVXU4MkFNTU9GZGYwcXhMVmJ5NTBEVHA1YmZ3eWtWU2Z1MCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3RpbWVsaW5lIjtzOjU6InJvdXRlIjtzOjg6InRpbWVsaW5lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789981296
7gx9xaxaV1mTOv8cBl8pjHxnhlHdXCh5qcoNcFAy	\N	178.62.218.164	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZnpjR3lUSXcxeTBnM0ZyOGFDUTVuUVo1NFpCeFlXTkRXQmdON2pWMiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTI6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9yZXN0X3JvdXRlPSUyRmJhdGNoJTJGdjEiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1789986400
prZFGo0IUrmtljpE3PqNHV50oRgMTx47P1P29QSm	\N	172.236.228.208	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMWIzdWFsNW51clR3NDZ1Sko4V0RTQ1A4bGttZzFrM1d5ZWxNZVJlcCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789997938
arhOh3rbClNwfEgL13enS6wy5Mp3PM4apOfuLJwj	\N	198.74.56.6	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRnBRMGZRZlhDd0gzdmFqWjlQM2FhYklVcDZ4RFZtMnRSRmZLSTZZbiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790008935
HJ88TvPbeHGERK7ZuEbENpbjSJeXQemXTaXn8J61	\N	203.55.131.4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNjRkVDhwQ2l3THM4amJoVG9ZYndJY1puWGNJMTRNc1J5MmJDMmFKdyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790009001
hjXWUvPq9AMOWBXVqnfnC8p93DDnySbVueJlu15v	\N	68.69.177.112	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNFNpU2tpTGxPbVBtdEpOdlJhaExmWDMzaU9OWk5ibU11Z2VzTThlMCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790020286
tYdqXvurGX7f7sUD15EwgBCFpjYU8exkYwP2fvCN	\N	68.69.177.112	Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 10.0; .NET4.0C; .NET4.0E; .NET CLR 2.0.50727; .NET CLR 3.0.30729; .NET CLR 3.5.30729)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ292bTBVSHR3WHBqYmxGQ0dRREZnbDFFdDBGWUFMVXo2UFFZdTE2USI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790020287
X5GittYUZvo7BK5uBiv8uioysfnfFkVgJ3mBBCaq	\N	43.134.163.229	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoibXB2RjdXVlZIc2FkNWVkMjg4RmNtSmxYSFpDZzhGQ0txQTB4MURHTyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790020307
ta2TUrMEuLnJjUlautLF5OnMUOi8vkqeAPrWVthF	\N	188.166.127.201	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36 ForestEngine/1.0 (+https://forestengine.net/#opt-out)	YTozOntzOjY6Il90b2tlbiI7czo0MDoic2lOckxvZndPZTVQdzZ6YjNhY1h2QWxNNVNPc0VzelV3eHlEMHNYbyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790032693
D03RS2Yrj1feXt47lbfz3BS2EYuXIRtVEUTFUyVE	\N	149.104.106.97	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.3 Safari/605.1.15	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVm5EdU1ZNnJZaXViaFUzdmtZU2VpU3hMMjVzckI0OWJZSHI1cFl1cSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3JzdnAiO3M6NToicm91dGUiO3M6OToicnN2cC5sb2NrIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790047092
Y4J63rOEkM2lg6EmlpwPKaFdWablHzZD7DOdzl4t	\N	195.184.76.225	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:134.0) Gecko/20100101 Firefox/134.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiYUFIV2dtZTdKM1JIWmZwVkM0eEZWUmY0S0pVVnBRdXNUMDI1dVR1NyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790056049
bI3UtmasMm6E9HDwz2Yx4VFw5p5raEidbV0Aj1NN	\N	134.209.217.177	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoicUM1dVlKa1NXOW5idWdsb09oUjJBdnBDSHd4eEgzN3FrbTE5V212WSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790065740
RfAky06eHdTa7BNqdcN2b2JKxmooQz3S3QwAfFXp	\N	104.236.83.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiM1BuOVZCblhPb1ViRkg3VDJUVk13NFF0WVR5WmFWQW9BcWsxOWx2VSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790071968
ReJf3ImsBhS86peYkM62R6ej825nnUXyMMqBjoP8	\N	185.73.23.162	Software Security Research/1.0 (+https://reverse-proxies-measurements.softsec.ruhr-uni-bochum.de)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiakdsb0tZQktPTjhTd2tOSGpaMlNTUmV0RU1nQWpqMFVBekgwUm5xQyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjI6Imh0dHBzOi8vYXJlbmFzY3JpbS5jb20iO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1789981461
sUI1F04b9ZCk09tpdfN0p7e5A2uiB5zZ5VuMnIC4	\N	169.150.196.214	Mozilla/5.0 (X11; Linux x86_64; rv:156.0) Gecko/20100101 Firefox/156.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSTJtbzRkVlA5cWVKWE0waVhBVUMwSDllOFFER2FJdDJQMVFvcENMeSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3RjZyI7czo1OiJyb3V0ZSI7czozOiJ0Y2ciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1789982455
lfIzN0wprABl8RHAaRwlfPt6ZqvJSqAH7A6pzNHG	\N	45.79.149.50	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiaUNqS3dDd1ZZa0JNTDlKbUNYQmVJdE5qcHp6QmdCMmpHeWJDRnZIeCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789987588
MU0n7FdSMtfy9M5mJP1Ks00T118TkpzZFOJkAIMr	\N	43.130.139.136	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWEwyOXJKTFJQV3VBSEptUW81Q05za2RkaWZpZGJxRUlHVFNCQjdhRSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1789999879
up0cDSV6Kb00d1rYDdSb6szwvkuwILwA6SPtqZOC	\N	185.73.23.162	Software Security Research/1.0 (+https://reverse-proxies-measurements.softsec.ruhr-uni-bochum.de)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTWkzMGxadVpLbURuM21abkxWb2hQTXdtYnNWeEdBT1NvaTN6QjdWaSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjA6Imh0dHBzOi8vcG9ybm8uc3VwcGx5IjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1789999979
zq9M9raBP5VWUv49wLUzc4nZ206vAMtVpNNZsxbk	\N	34.185.229.172	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUWkydXNBMVBUMXE4SDVpZXpCVVdwWkxSYkRRODgzZkR6ZWp0VVZHUiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790011143
7Xp0312ZcaxN8ZkHTLtxwv5ZLd30cp0yLr9LQs3H	\N	64.225.19.143	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiN2NtZTBiYVZaRTRWamZNaE1Ca0lOQWJYb0txR3RTdjJoeXllNTZhZiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790020906
pJhJi5hSGLr92UZud7do3Y7OAYo36eTW5Js0BjVE	\N	172.104.11.4	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVTh3dHM1azR6cWxLSmFVQnhta3ZUUlhYbVVpZFFWQ2x3dlBIbzFJUiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790034430
2GQHq15ILLc7vlZV2x2hnYSvloO5kqHMUx1zKzqU	\N	50.116.1.161	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZDBYZVZjYzhmWk9zRWRwUXd4ZE1SSVZlbWs1a1Q2dVp5N3M1WVU4aCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790047445
L05iRhA0tfhCsE5eElj2pDtH2yN2cOaSlGsN2npY	\N	17.166.151.50	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15 (Applebot/0.1; +http://www.apple.com/go/applebot)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiamZKdVB6em1TMDZFN2x0VXVkZk1NZUNvS2dFMTJrOHhCYjNrcnZ2NSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS90aW1lbGluZSI7czo1OiJyb3V0ZSI7czo4OiJ0aW1lbGluZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790056341
QslzRHtFeOkkJzjSYQc8dzCpU9WqKar7lSKASZAN	\N	172.236.127.133	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoieDJMZFlkZjZ6STBvOXE4N0ZQU0lacFlVUFBhYjRWa0ZXWFdUZkhoaSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790067328
Ec6hmLOHnW1Gb7NA7GlpiExCwbl4praxb3i7Kn3Y	\N	64.62.197.137	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/122.0.6261.94 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ0J4V0pCc2tNZVdEVTFYSER4QWY3bWFpMU1QR1c2SE9QWW9manNMVSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789981609
pyLvPh6IU95DfeEPrcJozD1rDAjG08FY6ta0hyxT	\N	34.186.121.162	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNTlEMzVrNVZiZGlqMU5TNDZDWk84R2pzUk9nd2R5OUllUW1QYWxBTyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789987896
TOWyePit0tToZy2cYTY7rxg1r2YTbmSmlIfC7h3X	\N	34.186.121.162	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiemZaZjR0MjhVUEFCMWY4RVNpOEw0VFRpc1JMRWp5ZHZsYTFhakdIZiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS90aW1lbGluZSI7czo1OiJyb3V0ZSI7czo4OiJ0aW1lbGluZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1789987897
oxvK4dBwatgj3H3wfldZMzpLC7rRkfkKU3bcv5IB	\N	71.6.134.232	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSEVtbGxUQUJGQnppS1pGTDFlbGE2eTVaU0NzSnJhMUVENXkwUHk5biI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789988012
JiCrXHss56KuGR6Xm9Z5FsjcEo0ouoeahc2T3VMM	\N	185.73.23.162	Software Security Research/1.0 (+https://reverse-proxies-measurements.softsec.ruhr-uni-bochum.de)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSmlCd2xJa3RmVkNWZnVPSElSUmV4b0tNZnBMZ2F4cnA2NFFYQVk4OCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vd3d3LmZ1bGx0cmFubnl0dWJlLmNvbSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790000906
r4ifPizsETzlYxG31ngCCsYsAbWJvDoZqZjHeuzG	\N	205.210.31.92	Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUjNDSHRoVjRjc0pWcUk5RVdjeUVpV0xKeUVlRWxHN1Q1OWQ3YlI3bCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790011888
S1voWvB4C9UB5SXesiyIW6JigJoyONBywpPbO1up	\N	94.247.172.129	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2)	YTozOntzOjY6Il90b2tlbiI7czo0MDoieFEzT3lHR3BrVFRGcVZ0WWI1ckFPcERCUnFlYkdZdDgzckZoRmJ5ViI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790011912
XVWT1QgftP2QZ0k7L7iYOHbKkEQuZaJe4JschThT	\N	172.236.228.222	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNzdKcVFwbmFoOHBlcGRPcFZ2UUh4RktYckJrVzY5RmFxUkRnWHdNbiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790023891
snLbHkMIdWOJp5ywUbvP0pMilI3JObJ09yaFzStE	\N	52.44.229.124	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; Amazonbot/0.1; +https://developer.amazon.com/support/amazonbot) Chrome/119.0.6045.214 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ2RJcHYyU3dFamNoV2thYUR4R1JobmJpQWFiOGJ5NDFJQ0RZeWR6SiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3RpbWVsaW5lIjtzOjU6InJvdXRlIjtzOjg6InRpbWVsaW5lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790036566
NJbqdZHQ5dMpPOLTj1w4NdBpddQsmx5GVFnqCpOH	\N	172.236.228.86	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMnVYVjdYTmJQWkJRamxHalBhTGo0NTRCRzJmbGFVU2w3RmU4V1E0eiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790049703
wDA003QUwrlJXNLrCdAFKHl5di026MJsgcFE2jyj	\N	54.172.52.31	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTDdvTGs4VlNSbXhtdWlaeDJsMHpCcnVFZFJDTGZHUUU2elZlS0NuWCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790056565
mHGPivB6j2GaN2nDIaW1ktUH2NDWKPdRUU11MWEn	\N	94.154.43.196	Mozilla/5.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoibzl2ejRWODJKWUh6dk1MNWVEZE9WektyVm5Fckt0c0FzTGZ4MnlwdCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790069131
Urv5OH3eJ3hvbg7PvbiqrNLDGFJ6FNY6KDvIGXNX	\N	34.175.115.43	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiYkc1czF1NVR0TTA1YmdhT2hxOVNKOUJHT2RpRDBHWmdCUEZ4dzA5cCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790072457
GncTFLgzdrOGHxi9IjQXEEskN7ZE728lGF1tr6cv	\N	64.62.197.141	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/122.0.6261.94 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTkxOUGVMZVZkVFJPTnZQUDFmTjhzeFp2bVVaVWVEM1VEdGhJelF1UCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789982220
Pw2eVtENpxeeefL2ZQirGrLBtCMlMUM159WnsBs0	\N	213.209.159.154	Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en) AppleWebKit/522.11 (KHTML, like Gecko) Version/3.0.2 Safari/522.12	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZVpyTlBxSUk2cXQzWUllVGxiWUZqUTlSc1dBZHU5bXBNVzBKelVGeCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789982303
Oj5hx6ppgE4ugq6revPtjBqfmK1X6E6vZSeThSEz	\N	213.209.159.154	Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en) AppleWebKit/522.11 (KHTML, like Gecko) Version/3.0.2 Safari/522.12	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSUx0b25PU2p3WUwyV2R3U0dHMjRhaGUwT2FrVW5lcmpzYzlZeG9MTCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS8/cGhwaW5mbz0tMSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789982307
B8SKWbZNtahwYiBKZC4tmJUprMwXTnRSviFSGhfC	\N	213.209.159.154	Mozilla/5.0 (Macintosh; U; Intel Mac OS X; en) AppleWebKit/522.11 (KHTML, like Gecko) Version/3.0.2 Safari/522.12	YTozOntzOjY6Il90b2tlbiI7czo0MDoiaHZidGdQMmtKY0ZxbVp3Y1hJa1lPZVJvVlNTNXQ4VnU1NVNxcGVQTCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS8/dXJsPS5lbnYiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1789982307
k2aoCKfPEGgEsjtAMqqFoYhSo076wKa6so5rYJHp	\N	45.138.12.51	l9tcpid/v1.1.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTG5VN2VzRzBlbUNWeWZ6eXlVQmhZUDR0S1RHelVOTmtuTXRWakRrWiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789988249
QFdxvmfUKxy81tZ33bQZ5gYgliYK5e62HWBfFnap	\N	209.38.245.105	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiaWFya1pYeXZsRkVTQ2c5U0tSN0pxVDNKemhsU08xUVZKa1k4QUl3eiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790002292
FTR7zpvM3KtD7YHVrLqUp0z20dPOdxrSAxxyMA21	\N	94.154.43.60	odin-scanner/0.4	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMEVMeUtoVGVWdDM5eXhUYTJ1YlN4dndOdEVPQ3R3blVodW1ZUGd5UyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790012405
2DPzBpEdghYAukb6CvQ6T0y4IUHBmeOT4bLyIHF4	\N	165.99.207.153	libredtail-http	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWVBFcjBZOFgxY0NXQktuS2Z3R0RkT0p6Z0hkdnh2ZHp4R3Foa0w0aSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTQ3OiJodHRwczovLzE3OC42Mi44Ny4yMTkvaW5kZXgucGhwP2Z1bmN0aW9uPWNhbGxfdXNlcl9mdW5jX2FycmF5JnM9JTJGaW5kZXglMkYlNUN0aGluayU1Q2FwcCUyRmludm9rZWZ1bmN0aW9uJnZhcnMlNUIwJTVEPW1kNSZ2YXJzJTVCMSU1RCU1QjAlNUQ9SGVsbG8iO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790024099
rMfWSKsuqtqJ2c0Yxq2yNOSQtgq6kPMIUYR8n1YH	\N	165.99.207.153	libredtail-http	YTozOntzOjY6Il90b2tlbiI7czo0MDoidnFYdXZMbko5R0QzMzlpNmdoS3E2SmhybEhRclhzdnlEcVZDNFd4YiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjAwOiJodHRwczovLzE3OC42Mi44Ny4yMTkvaW5kZXgucGhwPyUyRiUzQyUzRmVjaG8lMjhtZDUlMjglMjJoaSUyMiUyOSUyOSUzQiUzRiUzRSUyMCUyRnRtcCUyRmluZGV4MS5waHA9JmNvbmZpZy1jcmVhdGUlMjAlMkY9Jmxhbmc9Li4lMkYuLiUyRi4uJTJGLi4lMkYuLiUyRi4uJTJGLi4lMkYuLiUyRnVzciUyRmxvY2FsJTJGbGliJTJGcGhwJTJGcGVhcmNtZCI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790024100
nh67mvO5b4tDOwYgGGKRc2o9YyjveJTjs52CiTjw	\N	165.99.207.153	libredtail-http	YTozOntzOjY6Il90b2tlbiI7czo0MDoiYzNuaDJhbnp0ZGNzZHhPN2tQOGtxc2NTblZEZnQ4SWlZejF6ajA5QiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6ODk6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS9pbmRleC5waHA/bGFuZz0uLiUyRi4uJTJGLi4lMkYuLiUyRi4uJTJGLi4lMkYuLiUyRi4uJTJGdG1wJTJGaW5kZXgxIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790024101
kqFS9XKAKPm65jRUKDgVVY3yahmsNANqc4OUWWYK	\N	66.228.53.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMkRwZEhpWU5wbjRFcjhvNHNsZ0pmeUR1b3AzNVBaSEhXTU52MG8xOSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790037505
OGKZVTwhUv020CdJUySsZFoxlKhPu8H96J1C52m3	\N	114.119.147.240	Mozilla/5.0 (Linux; Android 7.0;) AppleWebKit/537.36 (HTML, like Gecko) Mobile Safari/537.36 (compatible; PetalBot;+https://webmaster.petalsearch.com/site/petalbot)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVkY0SDRjNDNSNVJLMXJtdEZNbkhabTdrRmZsTkdRQ0tubFBKaVlKOCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3RpbWVsaW5lIjtzOjU6InJvdXRlIjtzOjg6InRpbWVsaW5lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790037610
1znMKRjsCuViCbCUcARv8MauGlT68amdB1ZRgXi5	\N	213.209.159.175	Mozilla/5.0 (X11; U; Linux i686; de; rv:1.8.1.13) Gecko/20080325 Ubuntu/7.10 (gutsy) Firefox/2.0.0.13	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTDRpcDFXcTlwM0dvVnFLM2JMeHZsTnM5a0J5dUNtUWxOc0hORUlWeSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790050796
tCbbZauPvb9T8hdgT6NqzxGEnSVNn2PoEpUQoFax	\N	213.209.159.175	Mozilla/5.0 (X11; U; Linux i686; de; rv:1.8.1.13) Gecko/20080325 Ubuntu/7.10 (gutsy) Firefox/2.0.0.13	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSFgzNWM4dlhhN0ZyQnRaNjI4dGNnQXJTR3JhMW9lbDFHakVJNWQ0TyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS8/cGhwaW5mbz0tMSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790050803
IQEjvJ9zXCFcb8bHTJPd96qV8tjVNM7VQIVVnow6	\N	34.145.185.252	Mozilla/5.0 (compatible; Crusader/1.0)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVUxDVjd2VmM2bndqeDZPZTFNVmo5bmZadlFGOFpUU2t3ZXdFRjBxZiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790077985
e8RNTPZyRW3BrWvmRTffIDKjT15QFwHAmblO5haM	\N	34.22.222.15	python-requests/2.34.2	YTozOntzOjY6Il90b2tlbiI7czo0MDoickNIMklkcWdmR21CUWlEME9YUmpHYW1EQ1JzejBuaElwczhNZEg3ayI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789982819
6NumDPgGoZ1UESnJ1o8y7si18hRq40zHKteSqywe	\N	152.37.100.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:156.0) Gecko/20100101 Firefox/156.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVTU0amNaZWtsMTV5SVdXaTczdzhvWkpHT09xWUp0eENGZkdzQTQwVCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3RjZyI7czo1OiJyb3V0ZSI7czozOiJ0Y2ciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1789982889
ep4apowlT16nGYkJ0sgJPh6ImlqSfp4JNcD1v3ai	\N	68.183.104.244	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZzFNcjl4b3FnaGQ1ZDJJUTYwanhRRFM5RFFaSVNXc1RDeUJmaDVWUCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTI6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9yZXN0X3JvdXRlPSUyRmJhdGNoJTJGdjEiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1789988424
BnLZPOivhQdmP37aTJfWExb0HaZCqSFPbekEixIs	\N	209.38.245.105	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoieHZwQlE1Mzc5bTdWb2l2dkVhRzhIZU02VUJBZW1aSk54WHRiakNhcCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790002292
gkZ8WjU6MBNHowizneMv45itnhV6cgZZGcHFNn5C	\N	46.151.182.40		YTozOntzOjY6Il90b2tlbiI7czo0MDoicVNIS2FUSVdNcDhPalRNb1ZxQ2hVdk4xQnlmY0d4RGpHS2llaXhxTCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790012692
FfWwoXHbMvaNcwHRb8kCceJBmOabVYmhVJLeo3rp	\N	66.132.186.162	Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoibzJkaGlYblQydDVKelY3WnJUNXdmWEVwazdjYUluZWdYSWJVNUt6QyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790024653
JTjbrFFZiKfZSLZ2beBv7yBT4YkLB3bVCROptsIP	\N	34.140.3.155	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVFlOT1BBVGFSOVc0VkwzVzd1VVF0dmRDZzNBVjc4SjBsVXFUTGhOSyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790041719
uKkmCOmx7THWMmslE6N3klFyPcsGXa6QNA4O57Mv	\N	45.79.181.104	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMVhjWlZpdGc3bXBlN2dGZW83d2VzWGkzZ0x4ZkNmZTJDNG1iRDFlZyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790041804
rbRIiTuR52zFFRTWoziuJXhQV7kqLSDi6sVvV8G1	\N	213.209.159.175	Mozilla/5.0 (X11; U; Linux i686; de; rv:1.8.1.13) Gecko/20080325 Ubuntu/7.10 (gutsy) Firefox/2.0.0.13	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZjJDano4a0o2WXM4eVoxeEh3U21ZTFl2c0hVMHNsTDh4OG5GRnU2OCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS8/dXJsPS5lbnYiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790050804
kBNjgkqYYlTUWPhfOWcHquFSNFju0T1iaIQaTYa9	\N	74.7.228.187	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36; compatible; OAI-SearchBot/1.4; +https://openai.com/searchbot	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ2hld3ZLUFBtOUVXc2ZlV0g3QnVHU3o2WVpVMWtMMjhkU0pXVmtpZCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3RpbWVsaW5lIjtzOjU6InJvdXRlIjtzOjg6InRpbWVsaW5lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790056756
d2M0NPRxcwsVFmJIWZC4ZSkCTWtKdwwXxuDdBaBb	\N	74.7.228.208	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36; compatible; OAI-SearchBot/1.4; +https://openai.com/searchbot	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOUZFM0RFN0Q2cVBhTTRySnJZMXdYNERnbXJrT25qNGVubkR3Z1dxMCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790056762
t7S6yErMowd8c2Ua0bzEF6e88B8LyFURoRvcBg7H	\N	176.83.185.6	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_1) AppleWebKit/601.2.4 (KHTML, like Gecko) Version/9.0.1 Safari/601.2.4 facebookexternalhit/1.1 Facebot Twitterbot/1.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiaVUxa0R0emZGS1dncVN2VGxpdUFHSVVZZFNJVkM2ZUJjYlA0NjFIRSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790069435
12tTJEkpkXbtUL7JUIDhaEpy5YJy5cPyhr0oi5zO	\N	34.175.115.43	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSnZVWXBvNGUxdjVBRDQzTnhCdGxVV3ZUZHhNSGRFS2M3RkpkMVNYNSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790072479
7ZME7uULO1P81e5ik1oud3QkkQ3no5X4meFyMSrh	\N	34.140.3.155	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTUdjdnJMekt5QnJDUEpiVmo5VFdTUHdHeVdOaUhSTmlrcmdaTlhTQiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790076221
25eCexo7byB3ZS9PELDBCxFa20REUTfIoaRLCiXU	\N	184.105.247.254	Mozilla/5.0 (Windows NT 10.0.0; Win64; x64; ) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.156 Not(A:Brand/24 YaBrowser/24.4.1.899 Yowser/2.5  Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZVpGQ1BqVnBreGt2S1JXdVdNQVVWcVhNSkZaMmpQZ25pWHRaSnVxSCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790077484
tkaNWCeSdezIVOwjLAplEFnnnihWI24FEKLZSfDa	\N	20.203.40.116	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.98 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMVd2QzFJbExJM09OaHNoeVMyMWZRcUFOQUdUaUE5NW1aZGlCUzExcyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789983217
srB480irpc3UeY2HCBVuDfpL837LZnQlMBgKlTiT	\N	172.236.228.222	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZmVtVzd0ZXA2SDFoRnNiYlZsMkRFYlFEMmhlSmp6ckNsYVhDUUZ1QSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1789991780
WxOuq3R6941ENoSVHjYS8ZedJS0vZb9lvr5K6cD1	\N	185.12.59.118	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOWdYOXdMTGZNUFRjYjNFZHdpSmFoUmpGOU5oS3NxVWRaN25QYjloYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790003659
Jtr81BxND7oNOKNpJgH3pbHJZx77KuZ8UTjqX4Rk	\N	52.4.140.84	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiN0E5UktQMzlVZXJrc1ptMFUyTHdkajlGQlNDdm10QWFjSzhCWFZPaSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790013388
OOhyNPKCgLWv2cXc1FW045EpDmUKwakgx2WBkmcI	\N	66.132.195.67	Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZnRybTlOVU5ZVDhhVGNXdGZUYjNCOW43akdYOTh4bEZoREdEWk9pViI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790025056
XNH9IftxRzAhyNQDOs83sC6WO8CfFTa9JVmdzfly	\N	205.210.31.132	Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUTRJcXI0TUt1dTdjT2dHZW9wMzZ1MWJNbG1JSTNqQ2lSWkREUUcyUSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790025077
yNXWb4Resf65vxVWWrklAnTQ6CGNlXUaie1IeKtX	\N	43.158.91.71	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoia0lVSlNRRTNZd3BjZElVVFdkYkcwUHdsbmVUTUpRVm0walFSV3k1VyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790042601
McOR6xrQc4AivcIpYjJpAYswTYdCLY4XN9VWvu2m	\N	45.138.12.52	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoib0hCUmFpTHg4YkxFSzlySWc3aU10QzhwenI0N3dqbWYwSnpnVk9NYiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790051260
7rIjyEyOeTRzEQf1NtYJrVErtUFu5UbyDTLal3sN	\N	57.131.131.18	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/30.0 Chrome/143.0.0.0 Mobile Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRGd4aDZpQ0cyNVd5d1pKa3Jqemg2R2VsUjhJY1I0S010YWFlUUFWWSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790057128
fMyakAI4AqGc4YlzyMwGoCfHnVAgfAtuFJUwEtFg	\N	172.236.228.39	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoia0RuZENFRk14ODYyY1lxMDRjSVIxTU9ZSmlZYWljSmVod3FxazhWUSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790070242
lU0ZNTg9DukYlFANZEy3IIqGv9LRvMkDeSNWL7u9	\N	31.53.245.68	Mozilla/5.0 (iPhone; CPU iPhone OS 26_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/153.0.8010.24 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoib0FjNHhQU2Raek5YalZBYlNSNkl0VGJoMzlBNmNHdlk3Q0xzWlNkciI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790075319
m639UUYs5Mm2DZ4Z7dU6iNeHpfkeRftO2JynRXwg	\N	184.105.247.254	Mozilla/5.0 (Windows NT 10.0.0; Win64; x64; ) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6261.156 Not(A:Brand/24 YaBrowser/24.4.1.899 Yowser/2.5  Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWldiRTZlUHFkZ2FMTFdTOWlMVDAxcXZhZ3kzRW9yY054N1g3WUtncSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790076878
cbRt73ymfnABkeKjDs4MD4eXOp6A3Xi7VKB99T3U	\N	173.255.225.25	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoieTFJMk1CY0JmMzV0akQ4Q1RJdGJzb3hlNU9sdk9qRGR0bHNLN1E5WCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790077601
DlMhRJiKRPmzIWJrwP0f1lPRK883ixnBeD2FfbCN	\N	34.145.185.252	Mozilla/5.0 (compatible; Crusader/1.0)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNnN0aFBBVTM4SEJ4bmxnaGM3bGFKZ1BVSUdmeGxkOFFHUmZIMVBSVyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790077988
xLHFu9TRjwja25pMubMlSjHKgOtHV2KHNxCMOcRA	\N	185.218.86.25	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoia1lwMFd4RXBoUFJHY3RlMU81N0ZjcVlSM21yeVg3SjkzQzFVd1JkSCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790078084
hrFD2FGhjEQjuFtyqhZkNXJjhwqQ8Z3KfHq9l1Vn	\N	198.235.24.156	Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUzFtYWNJcFdWSVpKd1kwem82Rm8xQlVQWXBxdnE3V0VPV05lY2h2SCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790078141
BCA6oSaO7EbGLNrehfVXwJCHkay6viSmcoHiHxg8	\N	85.217.149.17	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 ModatScanner/1.2 (+https://modat.io/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSkk5eFZtbkZ5VUNXWjhQZEdyblY3bnVCSXBQckphNVBjQTN4OTcweiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790079570
yt5agzNyKfMJNPvlO3cqo5iJtDB0oCDKzqC7Joo4	\N	94.154.43.203	Mozilla/5.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoic2o2VnMycTVrZjdyZmdpSllXcW9kUUMxWm5sQmNGNVNubnRxbUVDUiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790079676
MlmpfVUum9yMwOXnRqjGsM5ZvikmWbMfOJ8WPaHx	\N	194.164.107.5	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiM296bWhXVHNNMXI3akVMTUxuRjFlc25FeXZCRzdobEEyQzVSdW9wWiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790079883
0P2UNWmIG5SIVimWDzpIe7fcclLTgNxcIXkAGP8o	\N	174.212.97.32	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6.1 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTXZweHFxbHlBY0dIVDhLNDd4VVJNVDRhcWhvb1hNdWdscU96cWVaciI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790079899
QOGl7jqlqtaFqOrVca7mHBDzXbKMbLIydrvcKalb	\N	174.212.97.32	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_1) AppleWebKit/601.2.4 (KHTML, like Gecko) Version/9.0.1 Safari/601.2.4 facebookexternalhit/1.1 Facebot Twitterbot/1.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoieXFDckx4dGFYWXZYdFpXVHU3OGRQbmZXNmtJY0pYNkZHamxZNGVqWSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790079903
bvi54yptsruieHojGJXZZQXKSp2QDQmkoeQIXLAw	\N	85.217.149.6	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 ModatScanner/1.2 (+https://modat.io/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiblVLdHhaZWk0anhxOXVEcmtzemFCaXdLMU00M2xycHdWSURBVFRBSCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790080358
hRAX2Zo2aiC92h1PDjGIYjZOAWHF8T6fPj3BiY2u	\N	94.154.43.7	Mozilla/5.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoibEREVmNhWU4xeHVKVFNhME1mRmx4MmRyYmFKSXA1QkR6d2dDM2J4MSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790080750
7KRjDl2mfGrXXQb9BkiRHT3besWOz7jO2KJvymew	\N	34.102.87.237	crusader-worker/1.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoibWtLMXYxb1hFRVBXb1E0ZEtud2JvNjVMZDhrbUd6TG5LTmFTTXRucSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790082887
LZNXCd1PkJi016DuKxX3fC2TkewBBbtvakde8T3v	\N	94.154.46.245	Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)	YTozOntzOjY6Il90b2tlbiI7czo0MDoia2tTeEM4UHZzNHpPQlVCd2l1UnFLWjlDTlk0Zll4Z1AxaFlwc2x3cSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790083691
wKIKxfUAADnulghmwEHM4KKi1lDkMU6BrT4uNE7j	\N	94.154.46.245	Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)	YTozOntzOjY6Il90b2tlbiI7czo0MDoidkxRUGZSbFZRanRUQmVLRlZQNW5VakxiNHhhWDl4alJOWXRlTXhxcCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790083692
rbkmZDJTJkZTKbViBIuwwyuUsXy8YOKjIkYWhmR2	\N	47.84.202.173	curl/7.64.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiaGkzWnp6SUNrTHdDSjkwOVA4WGhQTVNxV01rOFRoV3JWQ2Z6WXo1OSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790085809
5wv1z6Tpe10JUVy5tiTEIUn5ncs35GoDydLSX6o7	\N	47.84.202.173	curl/7.74.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiT2hRUWpyMHpJbzNjNTN5MVFTMkpueEdMbk02SjUydzdOSnZhc1ZlSiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790085811
vNcu97tB7XG4vWNIKmw0GOc3Vs3tybvMqdWa3C2r	\N	188.166.121.76	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36 ForestEngine/1.0 (+https://forestengine.net/#opt-out)	YTozOntzOjY6Il90b2tlbiI7czo0MDoidFUwQXBqc1g1QzdXWUFiTmNWUVJQenhFVWJ3V1o1WlByUHhYMzRMWSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790088764
fZmXaoSbgTRs9mcXsGcoKNoZhVSpdrvE1PTK6lcD	\N	94.154.43.60	odin-scanner/0.4	YTozOntzOjY6Il90b2tlbiI7czo0MDoidWtOUVc3SlF6Wll0WXlXM2Fia1UyeDFGNjNRSXRsazVRcTdnREh6eSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790089252
wORTQMli2fElPXaFZrKXxzue9yMTibYFrxEDkVUb	\N	139.59.182.65	Mozilla/5.0 (X11; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoibmJxNEhQTHdSbWlQRDB6cDJRN256Zm55b1dDa2tvQ2hxUmRoajF3biI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790089572
qimzX3QU5X5mfJkD1Orx4YFWBWGqD1PjpTuHWZdL	\N	103.187.169.31	titlegrabber/1.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVW0wMkVmSGp1NzZoVHBQUWprWDFUdDRoMk04NnZmV0VIZ0NOTXU4WCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790089667
FmTpDoktVeZ6lZQPEC4bJRxtgGl8odyHJQyFwdh3	\N	185.12.59.118	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoib0g3bEx6SHpNa1VmMndaNFA2SEtmdVFJVHJVbkZQOVNXWEF2Q21IRSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790089820
vpcPwqWCm5j3f7AczhAo72OcamB8ujkW6dzas7rt	\N	109.41.112.19	Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/153.0.8010.24 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoibVVmY3kyYXJVTzQ0dzBkWFZQZ2o1Ull2ZnNBVzZNUmphcXlReGdZWiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790090095
S0EvTFB6y6cf7c4dDn4xqkJNQKYr4mURNg9mBHd1	\N	45.156.129.134	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.6312.86 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoibzRuNEROQVZ4VUNXYnlEakM1TUhhVzNSaUp0THBDakllTDRjVG5vSyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790090629
KEcBMsMj97JBau252QpgIQn0ZIQ9BJGOjDRestjJ	\N	205.210.31.73	Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQVRmdHFwekNFSU9wQkllTDFoQW1IblQ0Wk9PcmhtdmdWUWljU2lkQiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790090645
w9QNXMJ2FimN8mHxkNymH3IWqCRlYqRgYMnTmPJI	\N	49.51.183.75	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZGJWZzdiTEdacktzbHdKNFN1eVRJc1hqMThhYVZtakF3aEVTdWYwdiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790090665
M0fTuDcYWRpbj8rpUsjyradkYHWlMhVauiijQnDK	\N	172.105.196.91	Mozilla/5.0 zgrab/0.x	YTozOntzOjY6Il90b2tlbiI7czo0MDoiYWFhNGQ3Um5ic0RMbVBGWE9veGM2d1pvYVFKdXZYMDJlSVY1bXhyOCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790091546
3LJV38mAZMCtSana1SC84U7S9nwud5sjJw9w6XcD	\N	35.205.208.244	python-requests/2.34.2	YTozOntzOjY6Il90b2tlbiI7czo0MDoiS3Z2bFhpNjlIU2plOW1NdDdHU0pNaXUxNkwzYmtFV0JMQ0c3dW1ueCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790091579
ugcxndsRV3DdB8ak78tqZ9DeZoN0lHoqYFpbgU9O	\N	172.236.228.198	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiREtXYXlwOTNHZjJPdFJWeFF1emhCUjd5RVBHT1YyZFNFaVFGeDJ2ayI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790091723
AoVH1Seu1YxecwdLyYUvtvMIDfW8ucxsadQngqBJ	\N	213.209.159.175	Mozilla/5.0 (iPhone; U; CPU like Mac OS X; en) AppleWebKit/420+ (KHTML, like Gecko) Version/3.0 Mobile/1C25 Safari/419.3	YTozOntzOjY6Il90b2tlbiI7czo0MDoiaEZ1UXNjZW5UV3VkdU4wQXJwcVZTNURuQVBBanczSUZHOE9TZTl2UiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790092493
4nuKTpvgihmWuMecjJf1fhdQRFjgz7EjnNNzB05L	\N	213.209.159.175	Mozilla/5.0 (iPhone; U; CPU like Mac OS X; en) AppleWebKit/420+ (KHTML, like Gecko) Version/3.0 Mobile/1C25 Safari/419.3	YTozOntzOjY6Il90b2tlbiI7czo0MDoidkZvY0w0VmZESVlvU05xcDZKMml1WjJiOXNVcTBhM2dscTFYbHJTQiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS8/cGhwaW5mbz0tMSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790092493
CJNmVP72zB9xjyrHa2BQ2BmEajddMegJb7B6yOfM	\N	213.209.159.175	Mozilla/5.0 (iPhone; U; CPU like Mac OS X; en) AppleWebKit/420+ (KHTML, like Gecko) Version/3.0 Mobile/1C25 Safari/419.3	YTozOntzOjY6Il90b2tlbiI7czo0MDoiM2MwekZEUGZyYjdlOE1kWTZNMzZVT2E1UWJxMkJlOFNZVm45WHdSQyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS8/dXJsPS5lbnYiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790092494
2CP50dfroWuTOyAVEUGVNL0M9e0fxVIvPzCdFNZu	\N	152.32.234.97	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiU0x1elFLZW9reHlVV3pHdURZU3kxYjAwVzdacnJvZkE1WHBnN1NGRCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790094365
pMeb5lu9JXbkzCF3DsD2kbOaq0WqDh5C8lF5fi93	\N	104.28.40.140	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_1) AppleWebKit/601.2.4 (KHTML, like Gecko) Version/9.0.1 Safari/601.2.4 facebookexternalhit/1.1 Facebot Twitterbot/1.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiYlZESE5WR1l3M21Lb1YzRnViWWNlZkc3S2Jrd010Q1lMSnFxZ09FayI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790094505
GFAAYvyA21asahP1mqBH7n5dhDb95x46Cdrzf6Nk	\N	172.234.217.192	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWnVHdGl5QWx5VVh2cnJRQTJsUlkzM3RYZEl2SjFRQndvT3p6dGxtcCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790095023
7qgOP3K3ATiVGdumhFnZv3n6IoHn4DKtZUbbi5Pb	\N	80.94.95.211	Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; T312461)	YTozOntzOjY6Il90b2tlbiI7czo0MDoieU5rekgzdUh3VVh2cjBwUDJyN3lPOFBCNTc0Vkx5cUdlQ0IyVGFjdSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790097234
RElhqgHcsEaiO0MuqdTiqB0R2tlprJObqRv73ACg	\N	80.94.95.211	Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; T312461)	YTozOntzOjY6Il90b2tlbiI7czo0MDoid3dmQm10cGhmcUJLdGpJMUlGV2JSSHYyZzhXOXlhV1NJWk1reElNQSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS8/cGhwaW5mbz0tMSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790097242
zVBJFlrbpfCHJOyLDDZZKRpbOhhCxGZhZasiQvBI	\N	80.94.95.211	Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0; T312461)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVGJWU2RNZWVjemtxZjVkY1g5eWRYdFZWazlwbUg0WXNFZWRnNmhOQiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS8/dXJsPS5lbnYiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790097242
IqkAhbyaAokH4pvwq2N4bolEBDIIJehxwSEXuere	\N	151.245.151.77	Mozilla/5.0 (compatible; ForestEngine/1.0; +https://forestengine.net/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiY3NsRmxVRU9DeHdPT3JxVlVPQmVhdlFUem1LczVHMmtNSEhFcFNFayI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790097492
aoZbRmSyhtFvf9R2TXfjkXkKstEQ3CR7APa0WRgb	\N	8.216.3.215	curl/7.64.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZzRZd3RRTzJEVm80WDJiaXk3enZOOTROZ0FnSHNvUW9XSVN6MmhldCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790098175
m98p4A5wpGChDXw2GnzsG3OBHYdYUkb28eePdJBp	\N	8.216.3.215	curl/7.74.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiaFFyRHZaS2t1MFlTY0dwbUtwV085V0owdDJGS2xhbkRIRmJSTDhIeCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790098176
fq2wYRwWeyuIIXVsQGJM1EAXoyXatdMiHJqkRnnz	\N	172.239.71.245	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMVZRdUV0cVExd09wanR6cHBYWndJVlNadlUxNnR4VnUzRW9qS1hsOSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790099416
6nWc89sGHH605e9WwhBAOOIDT2ZMu2mtsMwQui01	\N	45.148.10.60	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiV2M5OGlNU0ZHUzNqbjRrb0doRU9RbVQ3MFBWeFBSVERYbnBJRjhxTiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9yZXN0X3JvdXRlPSUyRndwJTJGdjIlMkZwb3N0cyUyRjk5OTk5OSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790099918
WPgddPjr10ERFmUK2yNf6drBP5v52G5dvIpeuW1G	\N	45.148.10.60	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoicGdLRHpMU2N0NXNmeEkyeXhVT0M1YTRQQnZiU2hOeGZKa29nbTJIViI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790099923
9r1PAeMuWrIR9ibvgACb8HOqApR1lwVNpIajtFmD	\N	45.148.10.60	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNE92WEJOVHNjN2pwVDdtTWY5aXVtNXo5WXpQYnRrU3JMQTNnU2hUeiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790099923
oRUmxzrplvfQOvfrBSvk0baMpdrEbkjdXfbL4zAi	\N	45.148.10.60	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUUlRVVRNVFgzTDBQQzF6aTkxa3pZWkZqTWlHTHVodE1YRTZBUElwMiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790099923
dfI9B5r8aLmmkHHr0o4g5E7cY9nboy1o93kXwxXj	\N	45.148.10.60	Mozilla/5.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTFNaUGZUMklVUVZWUDJzZ0RHdU82eTkzekZMc1I3ck4wVWttWmJpSiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790099923
TTLopQ82s0ZG2cuIee6xXGquBBeQnkaDn2l72M0e	\N	45.148.10.60	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15	YTozOntzOjY6Il90b2tlbiI7czo0MDoidG5NWjBNUEJUQ1Q4UjRWWm01UkJ2dzV6VVVuZTAydm1YeU1EcFVsNSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTA0OiJodHRwczovL2ZyZWRkeWFuZGRhdmlkLmNvbS8/cGFnZT1ncmF2aXR5c210cC1zZXR0aW5ncyZyZXN0X3JvdXRlPSUyRmdyYXZpdHlzbXRwJTJGdjElMkZ0ZXN0cyUyRm1vY2stZGF0YSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790099923
Af3EWYjw5lrLpD5GbGEt29KVvwbaMHT9G1Kh2cOt	\N	45.148.10.60	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOTV4N0ZHWmRMMGpkRFNoV0RTQnIwMklCcWF6bUFWcHdub3l2Q3N5WSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTA3OiJodHRwczovL2ZyZWRkeWFuZGRhdmlkLmNvbS8/cGFnZT1ncmF2aXR5c210cC1jb25uZWN0aW9ucyZyZXN0X3JvdXRlPSUyRmdyYXZpdHlzbXRwJTJGdjElMkZ0ZXN0cyUyRm1vY2stZGF0YSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790099925
A0D8F6BfoTppwNjV5OQPkcneXZK0nazP0Uhu9ROX	\N	45.148.10.60	Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNVloeXVzVEZEWkpXM2MyZDM4cE9LWm02czJIWWRqS1JJNmhyOHhSUSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTEzOiJodHRwczovL2ZyZWRkeWFuZGRhdmlkLmNvbS9pbmRleC5waHA/cGFnZT1ncmF2aXR5c210cC1zZXR0aW5ncyZyZXN0X3JvdXRlPSUyRmdyYXZpdHlzbXRwJTJGdjElMkZ0ZXN0cyUyRm1vY2stZGF0YSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790099925
FD4cffRwBgTqggECLRBRQMcaIL55N8qEgr5ZuQMQ	\N	45.148.10.60	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiajF5dW56T2hwYUgwaE92TDFJbkEzWnk5SlJOdlJ6UDBNZ016QWRSeiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790100108
y778LWqYgZoPZM1FUrwNIhyebgcLZJhOsbkQgKiH	\N	34.156.249.47	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoibTlUZXhiTzJnSGFKUkNyaFBmbUlWdDM0V0N3aXY1OVlOTHBRSmZyZCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790100330
xeeNdLHkgFtIYX4LIn6BMmvZvS48TdnqraUAAJp4	\N	34.156.249.47	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoieGU0Zk1uSmUwWnM4UjBmNE9lWkI4MTJqZTJ2Q0IwdmhEZWZrS3dJcSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzc6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9waHBpbmZvPTEiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790100331
jG1L9Lu1hu4KCf1UIiTzKs4mwj3EFZZSRwEz17f0	\N	216.180.246.151	Mozilla/5.0 (compatible; GenomeCrawlerd/1.0; +https://www.nokia.com/genomecrawler)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRGtsTjYybHpQQWF5NllWZ25vSWI0S2xzQXNYdXlKMVF0TlZhbmc3WiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790100601
CsYrjuuV9EBKB3ijMLvoLxtQq8CIgNgM4on2ooSH	\N	123.160.223.74	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVm5kUmlqUUhac1hNZEJ1UWxKeXVWa05sRUN4ckEyNDE0eU1FWkFGNyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790101025
WWL2EmQ1LzSXkgtgPK6W87Xex76M8zCxZB0Erq7L	\N	149.56.150.53	Mozilla/5.0 (compatible; Dataprovider.com)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiR09Jc0dZYnJJWGFIU2FwR2V4UzVCTTdmOWcxNVJsWG1ZNlNDUVNGdSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790102190
y6b3Ese93r48ZRau1QvSdays5D49LsG0AWXKIT53	\N	149.56.150.53	Mozilla/5.0 (Linux; Android 10; SM-G981B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.162 Mobile Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQWhrcjY2aVl3TXZLZVNWUlliTDlkTGNQQWx6SWRaNmpNdnlyNEZqcSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790102193
pjf9L7xr8NtIw5LMzkefI5gXfIB4ilZ14tMEnITF	\N	45.79.181.94	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSlJhSDBHMTExcm1Wa1JRMENKRFNUYzdTVE9FZ0cyT3pHQm50Q3FPbCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790103330
14fr3ZjwUpqT6IlSypn8ikfbV1e5Q6oGn5MBAkYi	\N	47.79.201.69	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRHVsSnZkS1FnQkJnWWF3bnhPdTFXSjgxR2VTYXE2SnY3S1YxVGJacCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790103634
TkKCSEOJ3DA2WCgCCZTRyboi3bTuNLH2XFUXdnJD	\N	140.213.95.235	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_1) AppleWebKit/601.2.4 (KHTML, like Gecko) Version/9.0.1 Safari/601.2.4 facebookexternalhit/1.1 Facebot Twitterbot/1.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOXB3YWU3S0JlMW9wMFN5T0tWd2FOY3djRGJ6RWtoOFVBYVRQN3lIdCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790104690
ThhoutyujnQBvuPnQUU3wRGDhntGt9pzJZEHi9vS	\N	92.211.0.57	Mozilla/5.0 (iPhone; CPU iPhone OS 26_5_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/153.0.8010.24 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiM2RpNVM0amdQWlBiY3Q2Q3BQaVBCSnVsYjI2eG03SDQ5bXpOUkRodCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790106302
I5CP411oLiwmX3DsfCXRL4RVoOS4w2n6WbrOsOof	\N	172.236.228.220	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiT0dRYVpYZkUzV0ZkUjhjODk1VTBzVzFjNDRnclI5WDhRQ3lqR3p0MCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790106507
UW7mvjkWRwJNOih1IRGRPBYUX3dFlE8t4IfvGeIj	\N	47.251.42.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoickZIVHhZZWxWVmZVWG9ZRld4aWM2WkFLV1MwdGxCdGN5cTF1c1JUVSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790106721
Gfoxa2UfKriaGYFtnkHG88vYttFJNtnzf1Kpx4rC	\N	45.33.90.118	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiYnViT0FrZzVZbEM3dnVDemtzVWxGeWtReHJYUHA2OExlR3VPcFZmTyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790109589
U6NUvbTqdfkU6QjVAd6Nf21rJT3McITGJBn2ndj9	\N	185.218.86.25	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoia3BUclNuVWJxQ0N6d0pHVEZBcVdrS05NTGlCZDdrTEJjOUtMMURqWiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790110949
buONRKL32gnCCUYu5WclqltkyKrsjr61mnS8jJs1	\N	205.210.31.32	Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity	YTozOntzOjY6Il90b2tlbiI7czo0MDoiODdIMzhCRzhibzdObGY4SzBXSEJBSW9vSVZaaFpQeTRuQVRRUEpYdCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790111417
D6v11fUtRdgjxYAoNVZ5mdgmJtOKEHL7yD2fgujl	\N	161.35.109.100	Mozilla/5.0 zgrab/0.x	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRWhUdEZKUnJrU2s2dldDS0tvZUh2c2NTS2xuVlVhQWJUeWNaWklIdiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790111502
Niws2UtXgjilSkVgPX9UMGqDhbG1WPtIA0pT0SLh	\N	34.140.3.155	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoidVduVjBteTlzSVVjOFAwNU5STklsTFVUR2dhMzJFSHB1cURWQTlNMiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790112445
hZK9YiJe4J6FZYvPaGAFVnLbCVBUNLseSubHO01m	\N	3.130.168.2	visionheight.com/scan Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/126.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVHJTdFhxcXNwNU1MQlloTnlSYjRnbWdHeHlaWDdjbGVIMkpSSEFWSSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790112529
oy2bw7ySllTs35L8GfRZS0qVvRpxkfD2nFIYiKam	\N	66.228.53.162	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoicGZQVWxKaW8yRWlPWU1xU1RuVFNrSVJtRXhaTWNuN1ExSDViRG9NRSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790113163
INoF4VQCWKr3FWT8EXeMUCiOvIbqVwdNXkYAoh5B	\N	198.235.24.84	Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOW16RHVGam1FcUNTVVhnNkJZa1FKeExQSlJsTmdZbVVEN2Q3WUdVUCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790113240
RmAMp89GauzxcO1XM3Y9VPtzk7xr07HZA67MxuQc	\N	66.132.172.143	Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRHRBTmMxcEhWV3RBNEg0bm54cjNCUHVzZGJvTGl1OGpudVVEMFZYTiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790113621
ui3ewv0T75xd4hF9pHLVDl3T0nY4BI9WPeoRnU6m	\N	66.132.195.103	Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoibE1EYk9IQmxlTkxQSUpwOVByc0VuU2IyUTZZckxabXZNTm4zSHFKaCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790114489
2Yv9dRsdDIlhUwGX7CaxlsL3VkieknJqjtwJcr7P	\N	43.164.129.191	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTjdNVlpqcGVIbTZGVXh2RnhiN0dEaTlCelk3NVcxQnhkcW5xajR6cCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790115415
FSUmlOzxxJHJEngJGWLslhojisL0DkCm6y6NT1F1	\N	43.130.3.120	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMEVCR0VEbGdIbExSNEpxNGlPTkpkMWV6SXZxQ0hCT3Nhd0ZnczA1cSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3RpbWVsaW5lIjtzOjU6InJvdXRlIjtzOjg6InRpbWVsaW5lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790115689
QwVqgZzcfuSGRRtK6AtxG4jsfduPYnZdhhpu9MGg	\N	213.209.159.133	Mozilla/5.0 (compatible; jscrawler/0.1; +https://github.com/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoieW1VbTlIbFRSd1hJYnR5T1l4T0JManRCb2huVDNRQzNnVjg0enVMMyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790115755
4hyfIAUDvtwD2p7e6V9i9yYH8Pza2oH3ONgggpwG	\N	213.209.159.133	Mozilla/5.0 (compatible; jscrawler/0.1; +https://github.com/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNlcyak9MMTBvcnFzaFA3T0VuV3Y5eXV5SlVQSDZid1ZzdUZvUUxHaiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3RpbWVsaW5lIjtzOjU6InJvdXRlIjtzOjg6InRpbWVsaW5lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790115764
a5SRrQBwbVT35bxYddaRsn2TK9hkeiE61nxs0JXm	\N	18.116.101.220	visionheight.com/scan Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/126.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMFZ2ck1MVzdqelBCQUl0alE1VDdmOFdyR0xpYzQ5WkYxdmp4SGk3dSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790116032
jT1ebQc3anHCmqze7wIFXWjrY6AeFxFa06HGzuVW	\N	43.134.94.96	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoicDR3T09pS3JJZlN3Rks1aFNraU5qNWZHcm5lWGxNYldYMXMwYkhSTyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790116849
YhA2G8jqtCEnAYExY5ys3dfLC5jEfWjgLNt5m8js	\N	45.79.128.205	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMTl4YlNlcDdXaXNXWWNDbERRZ1d3OHRUU1ZEa0dTS3dWaWhpSUlxciI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790117662
JbaeGNOpVQmZ2OMTxea588OYmagu2W7ZXfpoLzSl	\N	77.91.71.55	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)  Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOHZEZ1g3cWtGQ1ZCRnNKencwSnJzRUc4alRDZnNYQ3F5NHNZOVg3NCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790118621
UXCoyLAF6b9RriJQTnHnwyMV8IvDfL0RxlGNxVsj	\N	139.162.69.42	Mozilla/5.0 zgrab/0.x	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ3BzUHFTQWJoNGdBVkRSR2RNdXN5MkVnR2ZTbW9QU1hIbVlKNEdDayI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790121468
FWtCcsAAPVIhGDUo4tGdCIhoqNbsuaf3ZU8vehPe	\N	64.62.156.80	Mozilla/5.0 (Windows NT 10.0.0; Win64; x64; ) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6367.63 Chrome/124.0.6367.63 Not-A.Brand/99  Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTzhSTWw5TUROVTdhajBMaE9vY3dVbUY4Q0FiSktsRG5JcXpsUFlhcCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790122330
vQK4RYEcnouq3AoSpyl2hO8IFVr6VIE9J8uQL2IJ	\N	64.62.156.85	Mozilla/5.0 (Windows NT 10.0.0; Win64; x64; ) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.6367.63 Chrome/124.0.6367.63 Not-A.Brand/99  Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiN2RFSlM0ZXlyVzduMmNGc0FqVEJ4Vm9pOEVmbGtxNWNaVjdMOFhiWCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790123062
0rafWBLltoplKKwVYPBWoBYkxd2ezjonI7h91zyv	\N	172.239.64.86	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZXR1S2IwdUZCMGhJYk5tTHpOTFh3YlE5aG1McTcwd2tEdmg3d3lsYyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790123946
fsEtUs416qry0v5HtbQa5zufmz7ZmI4vKyA9Tmy8	\N	71.6.134.237	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSWdmOEF4YUZCendCcjhFNEFlZzB3cTNSdUhUQXBTT3hzajVtQTVobCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790126946
aW5HuJQxsqjInGFXnByKacVXCcJiagC94yS3bXTP	\N	172.234.217.192	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZE92Sk1CQ1ZpOFoyTEp2Z0lMZVRWUjl2bEM5dE1wcjh1NlJQTzVUYyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790127618
eRldFfJilj45zrrB74DkIRMC8P3ZwUPDA2ru6b4l	\N	195.178.110.72	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMnZSdFlxT2JSY3gwSjNiRFZOVWI4V3Nwb3pLZUtkc0VvUkh3cUdzbiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTI6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9yZXN0X3JvdXRlPSUyRmJhdGNoJTJGdjEiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790129916
xjXkMnbIfZwCmwxLgYr0fJTXuSlrVl5nGdReNKav	\N	195.178.110.72	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRk5nNWRSZ3N0Q0VORGNTVll1SVo1aER6U09VRTBGM294aXVYVWpVZiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NjE6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL2luZGV4LnBocD9yZXN0X3JvdXRlPSUyRmJhdGNoJTJGdjEiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790129918
169RwAXmmrt8n8F0wfLPA0MXRrLbW0kfMRRkrVAR	\N	195.178.110.72	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiT0JvanVsWTUydXIyM0NyWVIxTjBVOUNuVFl1SmlxMlVmMjBnZnVqMiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NjE6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL2luZGV4LnBocD9yZXN0X3JvdXRlPSUyRmJhdGNoJTJGdjEiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790129921
EFd0Jg5iN9Xjr2dwpg7TQXRXno7z6YFOqYgTnwMc	\N	195.178.110.72	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRDN3TXdVS0prYXFGSnZVSlV3cmdpYXI1a3c3MTNZQmpycWhuQlhHdiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTI6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9yZXN0X3JvdXRlPSUyRmJhdGNoJTJGdjEiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790129921
MunyECLsJBTXMQxvSTg7wtBMd9kbZ7caXlxyS2J4	\N	195.178.110.72	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiYnhaazBLcHVHamtWSDBsVkRJbENzd3c5ZEhJS3drcm45TklQYll1dCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTI6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9yZXN0X3JvdXRlPSUyRmJhdGNoJTJGdjEiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790129921
cFLsCejrayjmVWNy7WYdShxBcwjeTwgmSu8vqU1i	\N	195.178.110.72	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoielhVeGZqaGIyR2htNDRkTTYycU0xUVhTSGxDR250eUZwTDlKWk45VSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTI6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9yZXN0X3JvdXRlPSUyRmJhdGNoJTJGdjEiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790129921
gDCQY3Y28ERcLJSQihPAEMmwup1qxMfH8a8EYitm	\N	195.178.110.72	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiYVl3Z1lVNVhBc21pQzFnQXNUTHl5eHBBemdEV25xUW1GWE5VTGRoViI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NjE6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL2luZGV4LnBocD9yZXN0X3JvdXRlPSUyRmJhdGNoJTJGdjEiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790129928
gAu9NDQGEVzr5Jo9BkToM9tD1FH9Un2vWviziAM9	\N	195.178.110.72	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoicjJod3AxZEZha2VwOHQ0NGgwQzVtZkZGNUxzOHNPRm5OckJVOWlHRyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NjE6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL2luZGV4LnBocD9yZXN0X3JvdXRlPSUyRmJhdGNoJTJGdjEiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790129932
2o7G6uHE25ZG6kt0zOmYRYKXsCAclg3UoRTXw9IY	\N	195.178.110.72	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiM1JTSFRVbFRVTmZKaUw5VGVpU2VFd2RHZ2U1enVITzZUWnJabmxQOCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTI6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9yZXN0X3JvdXRlPSUyRmJhdGNoJTJGdjEiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790129932
gGnuqWvTyVkZitNUAbtSGPisbWTY3FB1qcWFDDxA	\N	195.178.110.72	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVDE5NDdvQVI0a0R4cFJYZDFqRkJDaEpjSXBvams3YmJxZkNINmdDMCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTI6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9yZXN0X3JvdXRlPSUyRmJhdGNoJTJGdjEiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790129933
sG9TPbBMXo372kVZhk3megbUXh9QXAMCdbmxwWny	\N	195.178.110.72	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiM3IwUzdtNzNhWUxhRjlrNjJFcDNOVVRGN3pqS3J4T1d3SnRINkF4YiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTI6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9yZXN0X3JvdXRlPSUyRmJhdGNoJTJGdjEiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790129939
ifOaABOxaLKZrGwkG6SKBjaB8oCaSQn3PS4HQ0GR	\N	195.178.110.72	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15	YTozOntzOjY6Il90b2tlbiI7czo0MDoiR1I4Q0lsdXE0dGFac0lvT1RyTUlLQnhxYXVER21kREVyUkUwaUNwVyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTA0OiJodHRwczovL2ZyZWRkeWFuZGRhdmlkLmNvbS8/cGFnZT1ncmF2aXR5c210cC1zZXR0aW5ncyZyZXN0X3JvdXRlPSUyRmdyYXZpdHlzbXRwJTJGdjElMkZ0ZXN0cyUyRm1vY2stZGF0YSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790129942
u9UcHJKpvsZjjNgHQBrsp7KdmSvZBADvKOpBvriW	\N	195.178.110.72	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiME5BUkJhcEdTTGl6dTlsaWhpR3JFb0lHYzlHalFrT3M3dEkzTmpadCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790129944
yTc7JOKcFLZHssHH1lUX11uqOwRKbbBgHMDq3QK6	\N	195.178.110.72	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoidkNOeE9ieVRWZVR1RmlKdGdaVk4xamdpYVAwRDZLMGNRYWIyTDlVbCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790129944
Ph4KJKLISI8Xx43ot6Hl8k47u71s0Aw2MlowpGSk	\N	195.178.110.72	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTWZpUVdWeEltR3NTTk1FZlMyMGxHVTEyWVZEZlZ3VDRka3p1N3JVeSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTA3OiJodHRwczovL2ZyZWRkeWFuZGRhdmlkLmNvbS8/cGFnZT1ncmF2aXR5c210cC1jb25uZWN0aW9ucyZyZXN0X3JvdXRlPSUyRmdyYXZpdHlzbXRwJTJGdjElMkZ0ZXN0cyUyRm1vY2stZGF0YSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790129944
gcBu1LTvnkpkhlRzNCxD9wKp5I3VNHzvvxQFhIam	\N	195.178.110.72	Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoidHdHQlBkZjc3Mk5aYk84Wkp3NFNBMnJLZkh1WXNPa0o4UDMwSkttRSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTEzOiJodHRwczovL2ZyZWRkeWFuZGRhdmlkLmNvbS9pbmRleC5waHA/cGFnZT1ncmF2aXR5c210cC1zZXR0aW5ncyZyZXN0X3JvdXRlPSUyRmdyYXZpdHlzbXRwJTJGdjElMkZ0ZXN0cyUyRm1vY2stZGF0YSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790129946
RDx6IkPSeYH8qeqlZXbYtBiZE8P5O2Qu4sRkaq3F	\N	195.178.110.72	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSndORkJ4eWt5aWZqeE1oYlBDUzNGZHJjYTlhSE9LUTZxVUc3eW5NUiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790129946
wuDasE2eZ8vUUjbbyawH8ksp39oDhFbBMN6iksh2	\N	195.178.110.72	Mozilla/5.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiR1hCNndhQjh1VXIxWXlRYVlDZ0FjNjZ1Wm14aXhwMFZqUWwzSEdpUyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790129946
7UculninQLEs3dCKHS9vPinPLgNOjljdMzb9KWLS	\N	195.178.110.72	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoibWJLVTN6S3FPd00zTWJpMlp2VHh2enE5bVNBb1NKMldFYkh1ZUR5ZiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1790130122
hh6q9LiN86xbk79MjoHG3wmVchEb9zKe7AI5jCY2	\N	213.209.159.175	Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36 OPR/47.0.2631.39	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSTFQRXBObTVqY2F3TlZPVlpWZjRZSDBNdzJqaTlUdmxpNDh4NU1HTCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790131631
p6JL0oPVW2ZB36WCW9a3D0hy3W45mfU0OlfVs1rq	\N	213.209.159.175	Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36 OPR/47.0.2631.39	YTozOntzOjY6Il90b2tlbiI7czo0MDoidnVBQVB4eGJVa0M0cmJRbkRYU2hRZHlxelpiUzJwSzR2eEVBV052VCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS8/cGhwaW5mbz0tMSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1790131641
hvx7snC0Ray77jmLPvxeJLzqymBo4H9dlyE28LTu	\N	213.209.159.175	Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36 OPR/47.0.2631.39	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTDBZNTZ4WEgzbzBjNXNjRVJycm9yR2JnbjN0azF0d3ZPb1AwQjdSWCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS8/dXJsPS5lbnYiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1790131641
\.


--
-- Data for Name: tables; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tables" ("id", "name", "elmore_id") FROM stdin;
8	Star Realms	8
4	Rainbow	1
5	Choir	2
1	Heroes	3
7	Elizabeth	4
9	Number	6
10	Backstage	7
11	DIY	10
2	Train	11
3	Bridge	12
12	Fantasy	5
6	Family	9
\.


--
-- Data for Name: train_affirmations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_affirmations" ("id", "created_at", "updated_at", "message", "enabled") FROM stdin;
1	2026-04-05 15:57:00	2026-04-05 15:57:00	We love you all so much, thank you for celebrating with us today!!	t
2	\N	\N	Thank you all for your wonderful cards, we can't wait to read them!	t
3	\N	\N	A big congratulations to Adam and Shel who are celebrating their 10th wedding anniversary!	t
4	\N	\N	Congratulations to Roman and Julia who are celebrating their 5th anniversary!	t
6	\N	\N	Thank you to all my Ready Singer One friends who've made the journey out from London for us!	t
7	\N	\N	Thank you to all of the Backstage Crew, the most solid group of friends a guy could have!	t
8	\N	\N	Humongous thanks to all those who've travelled from overseas to be here! We have guests from Spain, Germany and Poland!	t
9	\N	\N	A personal thank you to Corinne from David for being in Freddy's corner these past years; your support has meant the world.	t
10	\N	\N	To my Foxguard: You're all incredible and ridiculous and I love you all so much!	t
11	\N	\N	Thank you to all our close friends and family who have helped out so much behind the scenes in preparation for today!	t
12	\N	\N	Thank you to Freddy's mum Helen for growing many of the flowers used today!	t
13	\N	\N	Thank you to all of our wedding party; we're honoured to have you help make our day so special!	t
14	\N	\N	A special thanks to Paul Dunn, who helped make Freddy's engagement ring!	t
17	\N	\N	Thank you Tom and Giada for providing a beautiful backdrop to our engagement! Happy second anniversary!	t
18	\N	\N	Our warmest thanks go out to Helena for making our wedding rings, and for putting up with David at his grumpiest!	t
19	\N	\N	To my wonderful new husband - I love you with all my heart, and I can't wait to share the rest of my life with you. - David	t
20	\N	\N	Thanks to our wonderful Stationmaster Alyssa, who has helped the day flow so smoothly, and who organised David's Fox party!	t
21	\N	\N	Thank you to all our vendors, you've all done a smashing job!	t
22	\N	\N	A massive shout out to Jordan and his band Stroma, who will be playing the ceilidh this evening!	t
5	\N	2026-08-29 15:10:13	Congratulations to Hannah and Kieron who will be celebrating their 10th anniversary next week!	t
15	\N	2026-08-31 11:54:30	Much love goes to Kieron for hand-crafting the engagement ring boxes AND the housing for this train board!	t
16	\N	2026-08-31 11:54:44	The beautiful cake was painstakingly made by Hannah, and it is gluten and dairy-free so everyone can have a slice!	t
\.


--
-- Data for Name: train_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_comments" ("id", "created_at", "updated_at", "message", "enabled") FROM stdin;
5	\N	\N	Cheesecake yeah! - Erika Sojkova	t
7	\N	\N	I tried to follow your spaceship directions and flew into the sun :( - Alyssa Burling	t
44	\N	\N	All looks lovely, looking forward to coming! I have a hat!!! - Debby Fisher	t
45	\N	2026-09-03 23:46:51	Looking forward to enjoying the day with you both! - Paul Dunn	t
33	\N	2026-09-04 13:37:51	Love the website and invite design! - Stephen Briscoe	f
41	\N	2026-08-31 12:00:11	Please leave off the aubergine jam. Is there a less cheesy alternative to cheesecake for dessert? - Stephen Quinn	f
32	\N	2026-09-04 13:37:53	I also think your invite is excellent, we're both very much looking forward to your big day! - James Lyons	f
42	\N	2026-09-04 13:38:09	This wedding website design is amazing! We love it. And we are both already looking forward to joining you. - Nick Bartley	f
13	\N	2026-09-04 13:38:15	I love the invite and website design - Matthew Burnett	f
37	\N	2026-08-31 12:00:31	Dessert, I'll have what Freddy's having :)  Missing a box for "I'm special" - Alex Pritchard	f
40	\N	2026-09-04 13:38:21	Amazing invitation, amazing website! Can't wait to celebrate the big day with you both 💑 - Evie Fisher	f
35	\N	2026-08-31 12:00:37	Gah, we still haven’t worked out what we’re doing Accommodation wise, sorry! we’ll Make sure to let you know asap. Elliot’s looking forward to it! - Oliver Byford	f
30	\N	2026-08-31 12:00:54	If possible please can we have a highchair - no worries if not possible! - Oliver Nicholson	f
29	\N	2026-08-31 12:02:07	Hi Fred,\r\nApologies for the late reply here.  We were really hoping to make it to Blighty to finally meet you and David in person but a few conflicts with planning the trip arose. - Daniel Calinski	f
28	\N	2026-08-31 12:02:08	More testing - I love you! - David Fox	f
27	\N	2026-08-31 12:02:09	Looking forward to it! :) - Kashish Jaiswal	f
24	\N	2026-08-31 12:02:14	If it's possible to just have strawberries for dessert, that would be my choice. But if too faffy, then just nothing. - John McManus	f
18	\N	2026-08-31 12:09:39	I'm so excited! - Dan Pope	t
25	\N	2026-08-31 12:09:55	Sounds yummy 😋 - SB	t
23	\N	2026-08-31 12:02:26	Congratulations!!! Can't wait. - Nathan Williams	f
22	\N	2026-08-31 12:02:31	Many thanks for the invite, looking forward to it!! - Marianne Baker	f
21	\N	2026-08-31 12:02:36	Apologies. Unless a global lack of jet fuel intervenes, I'm planning to be in the South Pacific. Can I take you out for a celebratory dinner when you're back from the honeymoon? - Edward Sanders	f
20	\N	2026-08-31 12:02:37	Delicious menu, thank you - Helen Pitel	f
19	\N	2026-08-31 12:02:39	Not sure they will have BBQ sauce there, but if they do, will be appreciated :) - Gerry Lovelace	f
26	\N	2026-08-31 12:09:58	Going to be the best wedding with an underground themed wedding invitation I've ever been to 💙 - Daniel Hanvey	t
31	\N	2026-08-31 12:10:03	/* Insert witty comment here. */ - Shaun Zedlewski	t
15	\N	2026-08-31 12:02:55	Thanks for the invite and accommodation! - Will Saunders	f
34	\N	2026-08-31 12:10:08	Congratulationssss!! - Nanditha Garge	t
36	\N	2026-08-31 12:10:11	High five (he's learnt it and will insist on it) - Henry Holttum	t
39	\N	2026-08-31 12:10:16	It all looks simply delicious - Sally Pitel	t
38	\N	2026-08-31 12:10:17	I'm so excited!!!! It's going to be a wonderful day. xoxo - Louise O'Young	t
43	\N	2026-08-31 12:10:24	Lots of love from us both XX - Nigel Pitel	t
9	\N	2026-08-31 12:04:50	Yummy yummy yummy I got yummy in my tummy - Ian Ang	t
1	\N	2026-08-31 12:08:38	I am incredibly excited and audibly hungry for this!! Can’t wait xx - Madeline MacLean	t
2	\N	2026-08-31 12:08:50	Looking forward to it. - Ian Barwick	t
3	\N	2026-08-31 12:08:50	So excited!! - Pandora Blair	t
6	\N	2026-08-31 12:08:52	I can't wait! - Todd Francis	t
4	\N	2026-08-31 12:03:48	Your invitation is fantastic! So much love for this! - Alix Lyons	f
8	\N	2026-08-31 12:08:54	I’m so happy for you two. Thank you for inviting me. - Amelia Pritchard	t
10	\N	2026-08-31 12:08:59	Super joyfully yes. Thanks guys 🤗🥳🏳️‍🌈 - Ezra Attwood	t
12	\N	2026-08-31 12:09:05	Happy wedding planning! Nth time is the charm! - Sara Fisher	t
14	\N	2026-08-31 12:09:10	Your story on the website was amazing, I’m getting misty eyed already! X - Kirsty Blythe	t
16	\N	2026-08-31 12:09:15	Can't wait to celebrate - Heather Holttum	t
17	\N	2026-08-31 12:09:28	I’d really like to come but mummy and daddy won’t let me. Something about wanting to have a good time! - Harriet Little	t
11	\N	2026-08-31 12:10:37	Wahoo! It's working! - Mark Fisher	f
\.


--
-- Data for Name: train_configs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_configs" ("id", "created_at", "updated_at", "key", "value") FROM stdin;
4	2026-09-03 11:07:08	2026-09-05 19:25:57	openLatch	1788632757
1	\N	2026-09-05 13:48:39	importantMessage	He said I do!
3	2026-08-28 22:06:36	2026-09-05 13:48:54	mode	all_screens
2	2026-08-28 22:06:02	2026-09-05 18:50:35	secretEnabled	1
\.


--
-- Data for Name: train_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_events" ("id", "created_at", "updated_at", "destination", "description", "scheduled_time", "estimated_time", "enabled") FROM stdin;
2	2026-04-05 15:57:00	2026-04-05 15:57:00	Drinks Reception	Enjoy a glass of bubbly and a canape (or ten!)	2026-09-05 14:15:00	2026-09-05 14:15:00	t
3	2026-04-05 15:57:00	2026-04-05 15:57:00	Confetti Throw	Grab a handful and get ready to throw!	2026-09-05 14:00:00	2026-09-05 14:00:00	t
8	\N	\N	Full Group Photo	Gather for a full group photo!	2026-09-05 14:10:00	2026-09-05 14:10:00	t
21	\N	\N	Wedding Breakfast	Please head into the Gillyflower and take your seat (if you can find it)!	2026-09-05 15:45:00	2026-09-05 15:45:00	t
4	2026-04-05 15:57:00	2026-09-03 23:50:32	RS1 Photos	Now calling: Liz, Jamie, Ian, Kirsty, Mia, Sam, Gerry, Lawrence, Anthony, Rachel, Dan, Marianne, Nathan, Lucy, Louise, Jordan, Reuben, Madeline	2026-09-05 14:20:00	2026-09-05 14:20:00	t
31	\N	\N	Evening Food	Now serving: Tacos!	2026-09-05 20:30:00	2026-09-05 20:30:00	t
32	\N	\N	The Ceilidh	Join us for round 2 of the ceilidh!	2026-09-05 21:30:00	2026-09-05 21:30:00	t
33	\N	\N	Evening Dancing	DJ Spotify until the evening ends!	2026-09-05 22:30:00	2026-09-05 22:30:00	t
5	2026-04-05 15:57:00	2026-04-05 15:57:00	Backstage Photos	Now calling: Alyssa, Mark, Jon, Hannah	2026-09-05 14:25:00	2026-09-05 14:25:00	t
35	\N	\N	Morning Breakfast	Breakfast will be served in the Morning Room.	2026-09-06 08:00:00	2026-09-06 08:00:00	t
6	2026-04-05 15:57:00	2026-04-05 15:57:00	Archway Photos	Now calling: Adam, Stacey, Martin, Amy, Theo, Craig, Sam	2026-09-05 14:30:00	2026-09-05 14:30:00	t
36	\N	\N	Checkout	Please checkout of your rooms at 10am at the latest!	2026-09-06 10:00:00	2026-09-06 10:00:00	t
37	\N	\N	Leave the Venue	Please depart from the venue.	2026-09-06 10:20:00	2026-09-06 10:20:00	t
38	\N	\N	Leave	Seriously, hurry up and leave.	2026-09-06 10:25:00	2026-09-06 10:25:00	t
1	2026-04-05 15:57:00	2026-09-05 13:26:05	The Ceremony	Please gather on the East Lawn and find your seats!	2026-09-05 13:30:00	2026-09-05 13:32:00	t
10	\N	2026-09-04 08:41:36	Parents Photos	Now calling: Helen, Nigel	2026-09-05 14:45:00	2026-09-05 14:45:00	t
22	\N	2026-09-05 17:00:19	Main Course	Now serving: Roast Hereford beef rump; Root vegetable and lentil loaf; all served with roast potatoes, leek gratin, seasonal vegetables, Yorkshire pudding, gravy and condiments.	2026-09-05 16:45:00	2026-09-05 17:15:00	t
23	\N	2026-09-05 17:59:13	Speech #1	Hold on to your hats!	2026-09-05 17:45:00	2026-09-05 18:04:00	t
39	\N	2026-08-29 14:23:34	Get Out	GET OUT. GET OUT. GET OUT. GET OUT. GET OUT. GET OUT. GET OUT. GET OUT. GET OUT. GET OUT. GET OUT. GET OUT.	2026-09-06 10:30:00	2026-09-06 10:30:00	t
7	2026-04-05 15:57:00	2026-09-04 08:38:04	Moomin's Crew Photos	Now calling: Jon, Helena, Mark, Sara, Alyssa, Leah, Katie, Alexei, Ian, Ellie, Luca, Enzo, Tom, Giada, Richie, Helen, Oliver, Debby	2026-09-05 14:35:00	2026-09-05 14:35:00	t
24	\N	2026-09-05 17:59:17	Speech #2	Now speaking: Adam, Quinn, Ian, Alex	2026-09-05 17:50:00	2026-09-05 18:09:00	t
19	\N	2026-09-05 14:44:44	Wedding Party +1s	Now calling: Jon, Mark, Alyssa, Hannah, Quinn, Ian, Adam, Alex, Helena, Sara, Leah, Kieron, Libby, Shreya, Stacey, Rowan, Maggie, Artie, Rae-Rae	2026-09-05 15:30:00	2026-09-05 14:30:00	t
25	\N	2026-09-05 17:59:21	Speech #3	Now speaking: Alyssa Burling	2026-09-05 18:00:00	2026-09-05 18:19:00	t
9	\N	2026-09-04 08:40:05	Warwick Photos	Now calling: Jon, Mark, Alyssa, Katie, Ian	2026-09-05 14:40:00	2026-09-05 14:40:00	t
20	\N	2026-09-05 16:26:09	Starter Course	Now serving: Spring vegetable & goats cheese tart and dressed leaves; hot smoked salmon fillet, curried fried rice, sesame yoghurt, aubergine jam	2026-09-05 16:15:00	2026-09-05 16:36:00	t
26	\N	2026-09-05 17:59:25	Speech #4	This is the last one!	2026-09-05 18:10:00	2026-09-05 18:29:00	t
27	\N	2026-09-05 18:55:17	Dessert Course	Now serving: Baked vanilla cheesecake, poached strawberries; Triple chocolate brownie; Teas and Coffees	2026-09-05 18:30:00	2026-09-05 19:00:00	t
28	\N	2026-09-05 18:55:31	Table Clearing	Some of the tables will be removed to make way for the ceilidh! Please feel free to head outside.	2026-09-05 18:45:00	2026-09-05 19:10:00	t
18	\N	2026-09-05 14:44:50	Wedding Party Photos	Now calling: Jon, Mark, Alyssa, Hannah, Quinn, Ian, Adam, Alex	2026-09-05 15:25:00	2026-09-05 14:25:00	t
17	\N	2026-09-05 14:44:54	Foxguard Photos	Now calling: Jon, Mark, Alyssa, Hannah	2026-09-05 15:20:00	2026-09-05 14:20:00	t
16	\N	2026-09-05 14:45:00	Groomsmen Photos	Now calling: Quinn, Ian, Adam, Alex	2026-09-05 15:15:00	2026-09-05 14:15:00	t
15	\N	2026-09-05 14:45:09	David's Family	Now calling: Marcus	2026-09-05 15:10:00	2026-09-05 14:10:00	t
34	\N	2026-09-04 09:21:49	End of the Line	The Gillyflower shuts at midnight. Resident guests and treehousers are welcome to relocate to the Drawing Room.	2026-09-06 00:00:00	2026-09-06 00:00:00	t
13	\N	2026-09-05 14:45:17	Full Family Photos	Now calling: Helen, Nigel, Bea, Dermot, Laura, John, Maggie, Rowan, Charlie, Evie, Katie, Tom, Sinead, Sally	2026-09-05 15:00:00	2026-09-05 14:00:00	t
12	\N	2026-09-05 14:45:33	Core Family Photos	Now calling: Helen, Nigel, Bea, Dermot, Laura, John, Maggie, Rowan, Sally	2026-09-05 14:55:00	2026-09-05 13:55:00	t
11	\N	2026-09-05 14:45:38	Parents and Dunn Photos	Now calling: Helen, Nigel, Janet, Paul	2026-09-05 14:50:00	2026-09-05 13:50:00	t
14	\N	2026-09-05 14:45:58	Cousins + Granny	Now calling: Laura, Bea, Charlie, Evie, Katie, Tom, Sally	2026-09-05 15:05:00	2026-09-05 14:05:00	t
30	\N	2026-09-05 19:20:09	The Ceilidh	Join us on the dancefloor to dance a ceilidh! Remember to slip on your dancing shoes!	2026-09-05 19:30:00	2026-09-05 19:45:00	t
29	\N	2026-09-05 19:20:20	Cutting of the Cake	Please gather in the Gillyflower for the cutting of the cake!	2026-09-05 19:15:00	2026-09-05 19:35:00	t
\.


--
-- Data for Name: train_gifs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_gifs" ("id", "created_at", "updated_at", "link") FROM stdin;
\.


--
-- Data for Name: train_jokes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_jokes" ("id", "created_at", "updated_at", "message", "enabled") FROM stdin;
1	2026-04-05 15:57:00	2026-04-05 15:57:00	Why can't a steam locomotive sit down? It has a tender behind!	t
2	2026-04-05 15:57:00	2026-04-05 15:57:00	What do you get when you cross a railway engine with bubblegum? A chew-chew train!	t
3	2026-04-05 15:57:00	2026-04-05 15:57:00	How does a train avoid detection? It covers its tracks.	t
4	2026-04-05 15:57:00	2026-04-05 15:57:00	How do locomotives hear? Through their engineers.	t
5	2026-04-05 15:57:00	2026-04-05 15:57:00	What’s a train’s favourite type of shoes? Platforms.	t
6	\N	\N	What's another word for a late train? A slowcomotive.\n	t
7	\N	\N	Where can you buy train buffers? At an end of line sale.\n	t
8	\N	\N	I wanted to drive a train for ages, but I kept getting sidetracked.\n	t
9	\N	\N	It's hard to find anyone with more focus than a conductor because they have complete tunnel vision.\n	t
11	\N	\N	Why were the rail workers digging up a graveyard? They needed more underground sleepers!	t
12	\N	\N	Why did the train run smoothly? Superconductors. 	t
13	\N	\N	What's the difference between a teacher and a railway security guard? One trains the mind, the other minds the trains.	t
14	\N	\N	A friend of mine quit his job as a reporter and left town by railway. It was an ex-press train.	t
15	\N	\N	A friend got to the final of the local model railway competition. He lost on points.	t
16	\N	\N	The conductor has never missed a day of work in over 20 years on the job. He was there come train or shine.	t
17	\N	\N	I tried to get a job as a railway conductor, but they didn’t think I had enough training.	t
18	\N	\N	You can always tell when a train driver is stressed because they bite their rails.	t
19	\N	\N	Train conductors are clever and known for their engine-uity.	t
10	\N	2026-08-31 12:08:12	They finally caught that Spanish railway murderer. Police say he had loco motives.	t
\.


--
-- Data for Name: train_secrets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_secrets" ("id", "created_at", "updated_at", "message", "enabled") FROM stdin;
3	2026-09-05 12:02:57	2026-09-05 12:02:57	SECRET: THE FIRST CODE FOR THE PARLOUR BOXES IS 2	t
4	2026-09-05 12:03:10	2026-09-05 12:03:10	SECRET: THERE IS AN EXTRA GREEN BRACELET	t
5	2026-09-05 12:03:32	2026-09-05 12:03:32	SECRET: BRIDGE: YOU NEED TO THINK ABOUT TRANSPORTATION	t
6	2026-09-05 12:03:50	2026-09-05 12:03:50	SECRET: LOOK AT EACH PAIR OF PHOTOS IN TURN	t
7	2026-09-05 12:04:03	2026-09-05 12:04:03	SECRET: SMALLEST KOMMON YIELD	t
8	2026-09-05 12:04:19	2026-09-05 12:04:19	SECRET: WILD(con)CAT	t
9	2026-09-05 12:05:54	2026-09-05 12:05:54	SECRET: LES MIS	t
10	2026-09-05 12:06:03	2026-09-05 12:06:03	SECRET: GATHER THE DARK CITIES GAMES	t
11	2026-09-05 12:06:08	2026-09-05 12:06:08	SECRET: GO FISH!	t
12	2026-09-05 12:07:15	2026-09-05 12:07:15	SECRET: THE TRAIN CONNECTION NUMBERS USE THE SEATING PLAN, NOT THE TABLE PLAN	t
\.


--
-- Data for Name: train_slideshows; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_slideshows" ("id", "created_at", "updated_at", "link") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."users" ("id", "name", "email", "email_verified_at", "password", "remember_token", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type", "versioning_status") FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_analytics" ("name", "type", "format", "created_at", "updated_at", "id", "deleted_at") FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_vectors" ("id", "type", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."objects" ("id", "bucket_id", "name", "owner", "created_at", "updated_at", "last_accessed_at", "metadata", "version", "owner_id", "user_metadata", "archived_at", "is_delete_marker", "is_versioned") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads" ("id", "in_progress_size", "upload_signature", "bucket_id", "key", "version", "owner_id", "created_at", "user_metadata", "metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads_parts" ("id", "upload_id", "size", "part_number", "bucket_id", "key", "etag", "owner_id", "version", "created_at") FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."vector_indexes" ("id", "name", "bucket_id", "data_type", "dimension", "distance_metric", "metadata_configuration", "created_at", "updated_at") FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 1, false);


--
-- Name: accommodation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."accommodation_id_seq"', 1, false);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."failed_jobs_id_seq"', 1, false);


--
-- Name: food_choices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."food_choices_id_seq"', 3, true);


--
-- Name: guests_duplicate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."guests_duplicate_id_seq"', 1, false);


--
-- Name: guests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."guests_id_seq"', 4, true);


--
-- Name: households_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."households_id_seq"', 3, true);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."jobs_id_seq"', 4, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."migrations_id_seq"', 23, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."personal_access_tokens_id_seq"', 1, false);


--
-- Name: seating_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."seating_id_seq"', 144, true);


--
-- Name: tables_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."tables_id_seq"', 12, true);


--
-- Name: train_affirmations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_affirmations_id_seq"', 1, false);


--
-- Name: train_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_comments_id_seq"', 45, true);


--
-- Name: train_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_configs_id_seq"', 4, true);


--
-- Name: train_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_events_id_seq"', 6, true);


--
-- Name: train_gifs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_gifs_id_seq"', 1, false);


--
-- Name: train_jokes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_jokes_id_seq"', 6, true);


--
-- Name: train_secrets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_secrets_id_seq"', 12, true);


--
-- Name: train_slideshows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_slideshows_id_seq"', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."users_id_seq"', 1, false);


--
-- PostgreSQL database dump complete
--

-- \unrestrict tpTEXijV9OL91D6ydDLruTl23BGUEZuvQrUNzInXBKVroxQc9jJTDbjjM8g7soB

RESET ALL;
