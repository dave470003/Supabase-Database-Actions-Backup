SET session_replication_role = replica;

--
-- PostgreSQL database dump
--

-- \restrict DKKKrfxh1Php0o9vTdfT0O1YKWyhwTIOq6C5Mi06WY3Mf0dtNkxZgqFUbMhBKDB

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."audit_log_entries" ("instance_id", "id", "payload", "created_at", "ip_address") FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."custom_oauth_providers" ("id", "provider_type", "identifier", "name", "client_id", "client_secret", "acceptable_client_ids", "scopes", "pkce_enabled", "attribute_mapping", "authorization_params", "enabled", "email_optional", "issuer", "discovery_url", "skip_nonce_check", "cached_discovery", "discovery_cached_at", "authorization_url", "token_url", "userinfo_url", "jwks_uri", "created_at", "updated_at", "custom_claims_allowlist") FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."flow_state" ("id", "user_id", "auth_code", "code_challenge_method", "code_challenge", "provider_type", "provider_access_token", "provider_refresh_token", "created_at", "updated_at", "authentication_method", "auth_code_issued_at", "invite_token", "referrer", "oauth_client_state_id", "linking_target_id", "email_optional") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."users" ("instance_id", "id", "aud", "role", "email", "encrypted_password", "email_confirmed_at", "invited_at", "confirmation_token", "confirmation_sent_at", "recovery_token", "recovery_sent_at", "email_change_token_new", "email_change", "email_change_sent_at", "last_sign_in_at", "raw_app_meta_data", "raw_user_meta_data", "is_super_admin", "created_at", "updated_at", "phone", "phone_confirmed_at", "phone_change", "phone_change_token", "phone_change_sent_at", "email_change_token_current", "email_change_confirm_status", "banned_until", "reauthentication_token", "reauthentication_sent_at", "is_sso_user", "deleted_at", "is_anonymous") FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."identities" ("provider_id", "user_id", "identity_data", "provider", "last_sign_in_at", "created_at", "updated_at", "id") FROM stdin;
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."instances" ("id", "uuid", "raw_base_config", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_clients" ("id", "client_secret_hash", "registration_type", "redirect_uris", "grant_types", "client_name", "client_uri", "logo_uri", "created_at", "updated_at", "deleted_at", "client_type", "token_endpoint_auth_method") FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sessions" ("id", "user_id", "created_at", "updated_at", "factor_id", "aal", "not_after", "refreshed_at", "user_agent", "ip", "tag", "oauth_client_id", "refresh_token_hmac_key", "refresh_token_counter", "scopes") FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_amr_claims" ("session_id", "created_at", "updated_at", "authentication_method", "id") FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_factors" ("id", "user_id", "friendly_name", "factor_type", "status", "created_at", "updated_at", "secret", "phone", "last_challenged_at", "web_authn_credential", "web_authn_aaguid", "last_webauthn_challenge_data") FROM stdin;
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_challenges" ("id", "factor_id", "created_at", "verified_at", "ip_address", "otp_code", "web_authn_session_data") FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_authorizations" ("id", "authorization_id", "client_id", "user_id", "redirect_uri", "scope", "state", "resource", "code_challenge", "code_challenge_method", "response_type", "status", "authorization_code", "created_at", "expires_at", "approved_at", "nonce") FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_client_states" ("id", "provider_type", "code_verifier", "created_at") FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_consents" ("id", "user_id", "client_id", "scopes", "granted_at", "revoked_at") FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."one_time_tokens" ("id", "user_id", "token_type", "token_hash", "relates_to", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."refresh_tokens" ("instance_id", "id", "token", "user_id", "revoked", "created_at", "updated_at", "parent", "session_id") FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_providers" ("id", "resource_id", "created_at", "updated_at", "disabled") FROM stdin;
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_providers" ("id", "sso_provider_id", "entity_id", "metadata_xml", "metadata_url", "attribute_mapping", "created_at", "updated_at", "name_id_format") FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_relay_states" ("id", "sso_provider_id", "request_id", "for_email", "redirect_to", "created_at", "updated_at", "flow_state_id") FROM stdin;
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_domains" ("id", "sso_provider_id", "domain", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_challenges" ("id", "user_id", "challenge_type", "session_data", "created_at", "expires_at") FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_credentials" ("id", "user_id", "credential_id", "public_key", "attestation_type", "aaguid", "sign_count", "transports", "backup_eligible", "backed_up", "friendly_name", "created_at", "updated_at", "last_used_at") FROM stdin;
\.


--
-- Data for Name: accommodation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."accommodation" ("id", "is_at_venue", "is_treehouse", "name", "slug", "is_paid_for", "price", "suggested_donation", "description", "link", "check_in", "check_out", "model") FROM stdin;
1	t	f	The Map Room	the-map-room	\N	\N	100.00	The Map Room celebrates James Augustus Grant, Anselm’s great-great-grandfather and famed explorer of the Nile. With a nod to adventure and discovery, the room is filled with character and provides an inspiring retreat for guests seeking both comfort and storytelling.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=35&sr=-2.98,-1.08
2	t	f	The Master Suite	the-master-suite	\N	\N	100.00	For centuries, the Master Suite has been the main bedroom of Elmore Court. With elegant wooden panelled walls, sweeping views over the estate and a generously sized bed, it exudes historic charm and contemporary comfort.	https://www.elmorecourt.com/house/	2026-09-05 12:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=220&sr=-.49,.83
3	t	f	The Dressing Room	the-dressing-room	\N	\N	100.00	Located next to the Master Suite, the Dressing Room is a beautiful room in it's own right, and comes complete with elegant wooden panelled walls, sweeping views over the estate and a generously sized bed.	https://www.elmorecourt.com/house/	2026-09-05 12:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=213&sr=-2.67,.62
22	t	t	Kite	kite	\N	\N	100.00	Swaddled by evergreen Laurels, the L-shaped pod is perched on the eastern edge of the woodlands. High on style, comfort and coziness, it has a properly awesome sheltered outdoor kitchen and copper bath on the deck alongside an outside fire pit. 	https://www.rewildthings.com/treehouses/kite/	2026-09-04 15:00:00	2026-09-06 11:00:00	\N
24	t	t	Adder	adder	\N	\N	100.00	Slithered among the foliage around the western edge of the woodlands, the L-shaped cabin has floor-to-ceiling windows washing natural light over the mellow timbers. 	https://www.rewildthings.com/treehouses/adder/	2026-09-05 15:00:00	2026-09-06 11:00:00	\N
4	t	f	The Smoking Room	the-smoking-room	\N	\N	100.00	Originally a place to relax after lively days, the Smoking Room carries its historic name while offering contemporary luxury. It boasts an Emperor-sized bed, elegant painted panelling and a deep, indulgent bath, perfect for unwinding in style after a busy day at the house or wedding festivities.	https://www.elmorecourt.com/house/	2026-09-05 12:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=194&sr=-2.98,.45
21	t	t	Sky	sky	\N	\N	0.00	Positioned high up in the canopy of Laurels to the east, Sky has cracking views over our rewilding wetlands and is of course built using sustainable materials in a way that caused minimal damage to the woodlands. The design is contemporary, energy efficient, comfortable and super cool.	https://www.rewildthings.com/treehouses/sky/	2026-09-04 15:00:00	2026-09-06 11:00:00	\N
18	t	f	The Coach House	the-coach-house	\N	\N	0.00	Though close to the main property feels very contained. It’s comfy, private and includes 2 double bedrooms and a sitting room with a sofa bed.	https://www.elmorecourt.com/stay/#coach	2026-09-04 16:00:00	2026-09-05 12:00:00	\N
6	t	f	The Porch Room	the-porch-room	\N	\N	100.00	The Porch Room is a flexible, dormitory-style space designed for families or groups. With four single beds that can be linked in multiple configurations and a charming Armoire reminiscent of a storybook wardrobe, it’s a playful and practical choice for guests seeking comfort with a hint of whimsy.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=49&sr=-.34,-.59
5	t	f	The Oak Room	the-oak-room	\N	\N	100.00	The Oak Room is a bold and characterful retreat, featuring a 1636 four-poster bed, captivating artwork of serpents and unicorns and a decadent deep wooden bath. A striking blend of drama and comfort makes it one of the most memorable rooms in the house.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=29&sr=-2.77,-1.53
19	t	t	Wildcat	wildcat	\N	\N	100.00	A fabulous (sheltered) outdoor kitchen lives on the deck, along with a copper bath, fire pit and snooze chairs. While indoors there’s a wood burner, handmade super king bed with an organic mattress, soft linen and a bunch of cushions. Wildcat also has indoor cooking, tea and coffee facilities and a bathroom with a walk-in shower, sumptuous robes and top-notch bath products created from natural oils and healing plant extracts. 	https://www.rewildthings.com/treehouses/wildcat/	2026-09-05 15:00:00	2026-09-06 11:00:00	\N
20	t	t	Wren	wren	\N	\N	100.00	Wren is, like her namesake, small and perfectly formed. She rests lightly among the branches and leaves of the evergreen laurels, slap-bang in the middle of the woodlands with belting views. 	https://www.rewildthings.com/treehouses/wren/	2026-09-05 15:00:00	2026-09-06 11:00:00	\N
12	t	f	The Hole In The Wall	the-hole-in-the-wall	\N	\N	100.00	Accessible via its own private staircase, the Hole in the Wall feels almost like a suite. This charming and secluded double bedroom includes a well-designed bathroom, offering privacy, comfort and a whimsical twist on traditional accommodation.	https://www.elmorecourt.com/house/	2026-09-05 12:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=243&sr=-.31,.05
23	t	t	Earth	earth	\N	\N	100.00	Rooted in a particularly fine spot in the canopy, L-shaped Earth enjoys almost safari views from her deck and panoramic windows, along with cool contemporary, energy efficient design. 	https://www.rewildthings.com/treehouses/earth/	2026-09-05 15:00:00	2026-09-06 11:00:00	\N
7	t	f	The Nursery	the-nursery	\N	\N	100.00	Traditionally the nursery, this spacious room features a double bed, an optional single bed and a marble-tiled bathroom. Its generous proportions make it ideal for families, combining practicality with timeless elegance and comfort.	https://www.elmorecourt.com/house/	2026-09-05 12:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=182&sr=-2.77,1.04
11	t	f	The Butler's Room	the-butlers-room	\N	\N	100.00	On the second floor, the Butler’s Room offers a double bed, sweeping views over the Gillyflower and Cedar Lawn and a beautifully appointed bathroom. A calm and refined space for restful nights.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=76&sr=-.4,-.42
10	t	f	The North Room	the-north-room	\N	\N	100.00	Step back in time in the North Room, a classic wood-panelled bedroom with timeless elegance. Guests enjoy tranquil views of a majestic cedar tree and the Gillyflower, creating a serene and restorative stay.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=17&sr=-2.92,-.09
9	t	f	The General's Room	the-generals-room	\N	\N	100.00	The General’s Room once housed a high-ranking military officer and is perfect for families. It includes a twin bed (or double bed, depending on how close you want to get) and a bunk bed, offering a fun and comfortable space for guests of all ages.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=102&sr=-2.87,-.3
8	t	f	The Time Room	the-time-room	\N	\N	100.00	Light, airy, and full of character, the Time Room is named for “Old Father Time,” a reminder to savour life’s moments. The room features quirky 1920s graffiti and is celebrated for its brightness and charm, making it one of the most popular guest rooms in the house.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=1&sr=-2.31,-1.15
16	t	f	The Governesses Room	the-governesses-room	\N	\N	0.00	On the second floor, the Governess’ Room shares a bathroom with the adjacent Footman’s Room. This cosy, inviting space balances traditional charm with modern comfort, making it perfect for guests seeking a warm, communal feel.	https://www.elmorecourt.com/house/	2026-09-05 12:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=66&sr=-.88,-1
15	t	f	The Bachelor's Room	the-bachelors-room	\N	\N	100.00	Once home to the young masters after leaving the nursery, the Bachelor’s Room is a simple and comfortable double bedroom with a private shower room, offering a restful and historically resonant stay.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=42&sr=-2.58,-1.02
14	t	f	The Cook's Room	the-cooks-room	\N	\N	100.00	Tucked away on the upper floor, the Cook’s Room features bold, vibrant colours and a sleek shower room. With views over the walled garden, it is a cheerful, lively space that combines practicality with flair.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=84&sr=-2.77,.35
13	t	f	The Private's Room	the-privates-room	\N	\N	100.00	Located beside the General’s Room, Privates is a cosy double bedroom with a grand bathroom just steps away. Its charm is amplified by a set of standout curtains, providing both elegance and a touch of humour.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=98&sr=-2.32,-1.1
17	t	f	The Footman's Room	the-footmans-room	\N	\N	100.00	On the second floor, the Footman’s Room shares a bathroom with the Governess’ Room. Light, comfortable and full of character, it’s an ideal choice for guests who appreciate historic charm with contemporary amenities.	https://www.elmorecourt.com/house/	2026-09-05 15:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=78&sr=-2.29,-.9
\.


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."cache" ("key", "value", "expiration") FROM stdin;
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."cache_locks" ("key", "owner", "expiration") FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."failed_jobs" ("id", "uuid", "connection", "queue", "payload", "exception", "failed_at") FROM stdin;
\.


--
-- Data for Name: food_choices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."food_choices" ("id", "name", "description", "allergens", "course_number", "is_child_food", "options", "cost") FROM stdin;
0	No Meal	No Meal	0	0	f	0	0.00
1	Tart	Spring vegetable & goats cheese tart, dressed leaves	0	1	f	0	0.00
2	Salmon	Hot smoked salmon fillet, curried fried rice, sesame yoghurt, aubergine jam	0	1	f	0	0.00
5	Cheesecake	Baked vanilla cheesecake, poached strawberries	0	3	f	0	0.00
7	Beef Roast	Roast Hereford beef rump	0	2	f	0	0.00
8	Veggie Roast	Root vegetable and lentil loaf	0	2	f	0	0.00
14	Pizza	Mini pitta pizza	0	1	t	0	0.00
15	Spaghetti	Spaghetti, tomato sauce	0	2	t	0	0.00
3	Bread Roll	A selection of rustic farmhouse bread	0	1	f	0	\N
16	Brownie	Triple chocolate brownie & vanilla ice cream	0	3	f	0	0.00
\.


--
-- Data for Name: guests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."guests" ("id", "reference_name", "name", "email", "rsvp", "household", "role", "requires_childcare_data", "requires_childrens_menu", "requires_childcare", "dietary_requirements", "comments", "favourite_board_game", "invited_day_after", "invited_evening_before", "evening_only", "partner_invited", "is_child", "day_before_rsvp", "day_after_rsvp", "course_1_id", "course_2_id", "course_3_id", "seat") FROM stdin;
41	Jon Wooldridge	Jon Wooldridge	jonlou16@gmail.com	t	20	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	1	7	5	34
172	Madeline MacLean	Madeline MacLean	madelinemaclean9@gmail.com	t	91	Day Guest	f	f	f	\N	I am incredibly excited and audibly hungry for this!! Can’t wait xx	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	53
170	Reuben Goldmark	Reuben Goldmark	reubengoldmark@gmail.com	t	89	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	52
56	Jonathan Vooght	Jon Vooght	jon@jonvooght.co.uk	t	27	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	115
21	Christopher Price-Dahlgren	Christopher Price-Dahlgren	Chriskillik@gmail.com	t	12	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	81
34	Margot McTel	Margot McTel	\N	t	17	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	14	15	16	72
13	Katie Hannaford	Katie Hannaford	kjhannaford92@gmail.com	t	9	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	138
66	Shreya Garge	Shreya Garge	shreyagarge@gmail.com	t	8	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	yes	2	8	5	134
1	Freddy Pitel	Freddy Pitel	fwbpitel@gmail.com	t	1	Groom	f	f	f	Gluten and dairy intollerance	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	16	21
14	Alexei Barnes	Alexei Barnes	alexei.barnes@live.co.uk	t	9	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	137
12	Helena Chan	Helena Chan	helena002@gmail.com	t	4	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5	105
5	Jon Masson	Jon Masson	jmasson91@googlemail.com	t	4	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5	104
15	Ian Barwick	Ian Barwick	Ianbarwick1@gmail.com	t	10	Day Guest	f	f	f	\N	Looking forward to it.	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	103
17	Enzo Barwick	Enzo Barwick	\N	t	10	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	14	15	16	102
16	Ellie Barwick	Ellie Barwick	ejbarwick250@gmail.com	t	10	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	100
46	Harriet Blair	Harriet Blair	\N	t	22	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	18
20	Reem Khurshid	Reem Khurshid	reem.khurshid@gmail.com	t	11	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	16
72	Matthew Nutt	Matthew Nutt	matthew.charles.nutt@googlemail.com	t	35	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	111
73	Matthew Wyles	Matthew Wyles	matthewwyles@gmail.com	t	36	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	110
53	Alix Lyons	Alix Lyons	chidz1612@gmail.com	t	25	Day Guest	f	f	f	\N	Your invitation is fantastic! So much love for this!	\N	f	\N	\N	\N	\N	\N	\N	2	8	0	113
55	Colin Paxton	Colin Paxton	FandD@colinpaxton.com	t	26	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	116
80	Erika Sojkova	Erika Sojkova	\N	t	40	Day Guest	f	f	f	\N	Cheesecake yeah!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	119
19	Todd Francis	Todd Francis	toddish.f@gmail.com	t	11	Day Guest	f	f	f	\N	I can't wait!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	15
32	Laura Pitel	Laura Pitel	laura.pitel@gmail.com	t	17	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	no	1	8	5	61
28	Marcus Fox	Marcus Fox	marcusfox137@hotmail.com	t	14	Day Guest	f	f	f	no pork/shellfish	\N	\N	t	\N	\N	\N	\N	\N	\N	2	7	5	23
58	Tanya Burnett	Tanya Burnett	tanyamarieknox@gmail.com	t	28	Day Guest	f	f	f	Vegetarian	\N	\N	f	\N	\N	\N	\N	\N	\N	1	8	5	93
45	Pandora Blair	Pandora Blair	pandora.donegan@gmail.com	t	22	Day Guest	f	f	f	\N	So excited!!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	17
27	Astraea Capocci-Hunt	Astraea Capocci-Hunt	\N	t	13	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	14	15	16	91
25	Kieron Capocci-Hunt	Kieron Capocci-Hunt	khunt500@gmail.com	t	13	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5	92
65	Georgia Dunnicliffe	Georgia Dunnicliffe	\N	t	31	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	14	15	16	87
64	Joel Dunnicliffe	Joel Dunnicliffe	\N	t	31	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	14	15	16	86
50	Theodore Paul	Theo Paul	\N	t	23	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	14	7	16	40
49	Amy Paul	Amy Paul	martinjpaul@me.com	t	23	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	41
52	Sam Sargent	Sam Sargent	samuelsargent89@icloud.com	t	24	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	45
47	Stacey Chodera	Stacey Chodera	\N	t	7	Day Guest	f	f	f	Vegetarian, no mushrooms	\N	\N	t	\N	\N	\N	\N	\N	no	1	8	5	38
8	Adam Chodera	Adam Chodera	chodera.adam@gmail.com	t	7	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	no	1	8	5	37
51	Craig Sargent	Craig Sargent	craigsargent@hotmail.co.uk	t	24	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	46
76	Elliot Byford	Elliot Byford	\N	t	37	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	14	15	16	123
62	Adam Dunnicliffe	Adam Dunnicliffe	adam.ajd@gmail.com	t	31	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	88
75	Emily Byford	Emily Byford	emily@ek-smith.com	t	37	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	122
42	Libby Dunn	Libby Dunn	Libbyrosestephen@gmail.com	t	5	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5	127
68	David Holtum	David Holttum	David@Holttum.co.uk	t	33	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	130
3	Alyssa Burling	Alyssa Burling	alyssa.burlton@gmail.com	t	2	Wedding Party	f	f	f	\N	I tried to follow your spaceship directions and flew into the sun :(	\N	t	\N	\N	\N	\N	\N	yes	1	8	16	135
77	Sian Ebsworth	Sian Ebsworth	\N	\N	38	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
90	Timothy Finlay	Timothy Finlay	\N	\N	46	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
93	Ameila Pritchard	Amelia Pritchard	amelia.pritchard10@gmail.com	t	47	Day Guest	f	f	f	Vegetarian	I’m so happy for you two. Thank you for inviting me.	\N	t	\N	\N	\N	\N	\N	\N	0	8	5	25
189	Rachel Dowse	Rachel Dowse	r.e.dowse@hotmail.co.uk	t	105	Day Guest	f	f	f	None	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	60
168	Anthony Whelan	Anthony Whelan	Anthony.tux@gmail.com	t	87	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	56
119	Sinead	Sinead Geraghty	tomdanderson27@gmail.com	t	60	Day Guest	f	f	f	None	\N	\N	t	\N	\N	\N	\N	\N	unsure	1	7	5	69
114	Katie Styles	Katie Styles	katiestylesmail@gmail.com	t	59	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	no	1	8	5	65
112	Charlie Fisher	Charles Fisher	cfisher1993267@gmail.com	t	58	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	no	1	7	5	64
102	Adrian Gralak	Adrian Gralak	adrian.gralak95@gmail.com	t	51	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5	1
97	Julia Marych	Julia Marych	julia.kub.mar@gmail.com	t	49	Day Guest	f	f	f	N/A	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5	7
22	Cilla Price-Dahlgren	Cilla Price-Dahlgren	Cillasilvia@hotmail.com	t	12	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	73
192	Jamie Jones	Jamie Jones	jones.j15@gmail.com	t	108	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	75
188	Ian Ang	Ian Ang	ianang1993@gmail.com	t	104	Day Guest	f	f	f	\N	Yummy yummy yummy I got yummy in my tummy	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	76
191	Lawrence Bishop	Lawrence Bishop	banjoses@gmail.com	t	107	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	77
86	Richard Nicholson	Richard Nicholson	richienicholson@googlemail.com	t	44	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	141
195	Corrine O'Connor	Corinne O'Connor	Corinne.oconnor@hotmail.com	t	110	Day Guest	f	f	f	None :-)	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	9
18	Luca Barwick	Luca Barwick	\N	t	10	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	8	16	101
82	Tom Jordan	Tom Jordan	Tma.jordan@outlook.com	t	42	Day Guest	f	f	f	None	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	98
4	Mark Fisher	Mark Fisher	thefishers5725@gmail.com	t	3	Wedding Party	f	f	f	\N	Wahoo! It's working!	\N	t	\N	\N	\N	\N	\N	yes	1	7	5	97
96	Roman Marych	Roman Marych	marych.roman@gmail.com	t	49	Day Guest	f	f	f	N/A	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5	6
87	Helen Nicholson	Helen Nicholson	\N	t	44	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	139
10	Leah Burling	Leah Burling	leah.ann.king93@gmail.com	t	2	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	0	8	0	136
11	Sara Fisher	Sara Fisher	thefishers5725@gmail.com	t	3	Day Guest	f	f	f	\N	Happy wedding planning! Nth time is the charm!	\N	t	\N	\N	\N	\N	\N	yes	1	7	5	106
85	Chris Bradley	Chris Bradley	chris4794@hotmail.co.uk	t	43	Day Guest	f	f	f	None	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	13
105	Beth Little	Beth Little	Jolly_rodgers7@hotmail.com	t	54	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	8	5	20
106	Martin Little	Martin Little	martinlittle90@gmail.com	t	54	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	19
57	Matthew Burnett	Matthew Burnett	Foxtel@mattburnett.co.uk	t	28	Day Guest	f	f	f	\N	I love the invite and website design	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	94
24	Hannah Capocci-Hunt	Hannah Capocci-Hunt	khunt500@gmail.com	t	13	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	1	7	5	89
63	Michel Dunnicliffe	Michel Dunnicliffe-Ward	shelward999@googlemail.com	t	31	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	85
187	Mia Violentano	Mia Violentano	maria.violentano@gmail.com	t	103	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	42
175	Kirsty Blythe	Kirsty Blythe	kirsty.blythe@hotmail.co.uk	t	94	Day Guest	f	f	f	\N	Your story on the website was amazing, I’m getting misty eyed already! X	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	43
167	Sam Kenny	Sam Kenny	samuel_j_kenny@hotmail.co.uk	t	86	Day Guest	f	f	f	N/A	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	44
84	Lawrance Bailes	Lawrance Bailes	lawrance.bailes21@googlemail.com	t	43	Day Guest	f	f	f	No gravy, salad dressings or condiments please	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	14
88	Cherie Fox	Cherie Fox	\N	f	45	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
89	John Fox	John Fox	\N	f	45	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
81	Will Saunders	Will Saunders	wrs@wrsaunders.co.uk	t	41	Day Guest	f	f	f	N/a	Thanks for the invite and accommodation!	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	121
98	Julian Marych	Julian Marych	\N	f	49	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
69	Heather Holtum	Heather Holttum	heather@holttum.co.uk	t	33	Day Guest	f	f	f	\N	Can't wait to celebrate	\N	f	\N	\N	\N	\N	\N	\N	0	7	5	128
71	Ezra Attwood	Ezra Attwood	cub7391@gmail.com	t	34	Day Guest	f	f	f	\N	Super joyfully yes. Thanks guys 🤗🥳🏳️‍🌈	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	79
116	George Styles	George Styles	\N	f	59	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
100	Angela Calinski	Angela Calinski	\N	f	50	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
101	Ana Lu Calinksi	Ana Lu Calinksi	\N	f	50	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
115	James Styles	James Styles	\N	f	59	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
117	Wilf Styles	Wilf Styles	\N	f	59	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
91	Eileen Finlay	Eileen Finlay	\N	\N	46	Day Guest	f	f	f	Pescatarian	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
107	Harriet Little	Harriet Little	\N	f	54	Day Guest	t	t	t	\N	I’d really like to come but mummy and daddy won’t let me. Something about wanting to have a good time!	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
186	Dan Pope	Dan Pope	djpope2365@gmail.com	t	102	Day Guest	f	f	f	\N	I'm so excited!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	49
166	Gerry Lovelace	Gerry Lovelace	gerrelou@gmail.com	t	85	Day Guest	f	f	f	Lactose intolerance	Not sure they will have BBQ sauce there, but if they do, will be appreciated :)	\N	f	\N	\N	\N	\N	\N	\N	2	7	16	78
29	Helen Pitel	Helen Pitel	helenpitel1@gmail.com	t	15	Day Guest	f	f	f	\N	Delicious menu, thank you	\N	t	\N	\N	\N	\N	\N	yes	1	7	5	29
44	Edward Sanders	Edward Sanders	\N	f	21	Day Guest	f	f	f	\N	Apologies. Unless a global lack of jet fuel intervenes, I'm planning to be in the South Pacific. Can I take you out for a celebratory dinner when you're back from the honeymoon?	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
173	Marianne Baker	Marianne Baker	marianne.baker@outlook.com	t	92	Day Guest	f	f	f	Veggie (with some fish allowed)!	Many thanks for the invite, looking forward to it!!	\N	f	\N	\N	\N	\N	\N	\N	2	8	0	59
194	Lucy Williams	Lucy Williams	lucy@thehenhouse.co.uk	t	106	Day Guest	f	f	f	Vegetarian (yes to eggs and cheese etc, no thanks to meat/fish)	\N	\N	f	\N	\N	\N	\N	\N	\N	1	8	5	58
190	Nathan Williams	Nathan Williams	nathan@thehenhouse.co.uk	t	106	Day Guest	f	f	f	vegetarian (cheese and eggs OK)	Congratulations!!! Can't wait.	\N	f	\N	\N	\N	\N	\N	\N	1	8	5	57
171	Jordan Murray	Jordan Murray	\N	t	90	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	8	5	54
23	Saphi Price-Dahlgren	Saphi Price-Dahlgren	\N	t	12	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	0	15	0	84
67	Daniel Hanvey	Daniel Hanvey	danhanvey@googlemail.com	t	32	Day Guest	f	f	f	\N	Going to be the best wedding with an underground themed wedding invitation I've ever been to 💙	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	80
118	Tom Anderson	Tom Anderson	tomdanderson27@gmail.com	t	60	Day Guest	f	f	f	None	\N	\N	t	\N	\N	\N	\N	\N	unsure	1	7	5	68
169	Elisabeth Swedlund	Elisabeth Swedlund	elisabeth.swedlund@gmail.com	t	88	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	74
79	SB	SB	stephen.baldwin.personal@gmail.com	t	40	Day Guest	f	f	f	Gluten Free	Sounds yummy 😋	\N	f	\N	\N	\N	\N	\N	\N	2	7	16	120
54	James Lyons	James Lyons	lyons.james.r@gmail.com	t	25	Day Guest	f	f	f	\N	I also think your invite is excellent, we're both very much looking forward to your big day!	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	112
37	Dermot Colton	Dermot Colton	Dermotcolton@gmail.com	t	18	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5	67
103	Michal Leczycki	Michal Leczycki	leczyckim24@interia.pl	t	52	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5	10
197	Kashish Jaiswal	Kashish Jaiswal	kashishjaiswal999@gmail.com	t	51	Wedding Guest	f	f	f	Vegetarian	Looking forward to it! :)	\N	t	f	f	t	f	\N	yes	1	8	5	2
83	Giada Jordan	Giada Jordan	Giada.piero@gmail.com	t	42	Day Guest	f	f	f	None	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	99
2	David Fox	David Fox	djwfox@gmail.com	t	1	Groom	f	f	f	no pork/shellfish	More testing - I love you!	\N	t	\N	\N	\N	\N	\N	yes	1	7	5	22
99	Daniel Calinski	Daniel Calinski	\N	f	50	Day Guest	f	f	f	\N	Hi Fred,\r\nApologies for the late reply here.  We were really hoping to make it to Blighty to finally meet you and David in person but a few conflicts with planning the trip arose.	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
196	Matt O'Connor	Matt O'Connor	\N	t	110	Day Guest	f	f	f	Matt O’Connor has a rather severe intolerance to onion (including leeks, shallots, chives etc). Garlic is fine, and he’s fine for his meal to be cooked in an environment where there are onions- just no onions on the plate please!	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	8
92	Oliver Nicholson	Oliver Nicholson	\N	t	44	Day Guest	t	t	t	\N	If possible please can we have a highchair - no worries if not possible!	\N	f	\N	\N	\N	\N	\N	\N	14	15	0	140
61	Shaun Zedlewski	Shaun Zedlewski	sir.shaih+freddyanddavid@gmail.com	t	30	Day Guest	f	f	f	Food should be edible	/* Insert witty comment here. */	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	109
78	Stephen Briscoe	Stephen Briscoe	freddydavid@stephenbriscoe.co..uk	t	39	Day Guest	f	f	f	\N	Love the website and invite design!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	114
60	Jana Bartly	Jana Bartley	jana@nickandjana.co.uk	t	29	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	118
193	Nanditha Garge	Nanditha Garge	nanditagarge1123@gmail.com	t	109	Day Guest	f	f	f	No specific requirements	Congratulationssss!!	\N	f	\N	\N	\N	\N	\N	\N	2	8	5	142
26	Artemis Capocci-Hunt	Artemis Capocci-Hunt	\N	t	13	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	14	15	16	90
48	Martin Paul	Martin Paul	martinjpaul@me.com	t	23	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	39
6	Ian Dunn	Ian Dunn	Dunny118@gmail.com	t	5	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	1	7	5	125
74	Oliver Byford	Oliver Byford	o@byford.org	t	37	Day Guest	f	f	f	\N	Gah, we still haven’t worked out what we’re doing Accommodation wise, sorry! we’ll Make sure to let you know asap. Elliot’s looking forward to it!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	124
70	Henry Holtum	Henry Holttum	\N	t	33	Day Guest	t	t	t	\N	High five (he's learnt it and will insist on it)	\N	f	\N	\N	\N	\N	\N	\N	14	7	16	129
43	Millie Dunn	Millie Dunn	\N	t	5	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	14	8	5	126
7	Alex Prichard	Alex Pritchard	alexdpritchard@hotmail.com	t	6	Wedding Party	f	f	f	Dairy free, specifically A1 beta-casein, Goats milk therefore is fine:)	Dessert, I'll have what Freddy's having :)  Missing a box for "I'm special"	\N	t	\N	\N	\N	\N	\N	yes	1	7	16	36
33	John McManus	John McManus	johnmcman@gmail.com	t	17	Day Guest	f	f	f	\N	If it's possible to just have strawberries for dessert, that would be my choice. But if too faffy, then just nothing.	\N	t	\N	\N	\N	\N	\N	no	2	7	0	70
185	Louise O'Young	Louise O'Young	ms.louise.oyoung@gmail.com	t	101	Day Guest	f	f	f	I would like to know how the leaves are dressed so I can coordinate my outfit accordingly.	I'm so excited!!!! It's going to be a wonderful day. xoxo	\N	f	\N	\N	\N	\N	\N	\N	1	7	5	55
35	Rowan McTel	Rowan McTel	\N	t	17	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	no	14	15	16	71
36	Beatrix Pitel	Beatrix Pitel	Bea.pitel@googlemail.com	t	18	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	1	7	5	66
31	Sally Pitel	Sally Pitel	sallypitel@gmail.com	t	16	Day Guest	f	f	f	\N	It all looks simply delicious	\N	t	\N	\N	\N	\N	\N	no	1	7	5	63
110	Evie Fisher	Evie Fisher	evie.fisher96@gmail.com	t	57	Day Guest	f	f	f	\N	Amazing invitation, amazing website! Can't wait to celebrate the big day with you both 💑	\N	t	\N	\N	\N	\N	\N	no	1	7	5	62
9	Stephen Quinn	Stephen Quinn	sckrikor@gmail.com	t	8	Wedding Party	f	f	f	Lactose intolerance, allergy to aubergines (eggplants)	Please leave off the aubergine jam. Is there a less cheesy alternative to cheesecake for dessert?	\N	t	\N	\N	\N	\N	\N	yes	2	7	16	133
59	Nick Bartly	Nick Bartley	freddyanddavidwedding@nb221.com	t	29	Day Guest	f	f	f	\N	This wedding website design is amazing! We love it. And we are both already looking forward to joining you.	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	117
39	Janet Dunn	Janet Dunn	Janet.dunn62@gmail.com	t	19	Day Guest	f	f	f	Well done beef if possible.	\N	\N	t	\N	\N	\N	\N	\N	\N	1	7	5	32
30	Nigel Pitel	Nigel Pitel	nigelpitel@gmail.com	t	15	Day Guest	f	f	f	Very Stroud, like my clothing	Lots of love from us both XX	\N	t	\N	\N	\N	\N	\N	yes	1	7	5	30
109	Debbie Fisher	Debby Fisher	debbyfisher6873@gmail.com	t	56	Day Guest	f	f	f	\N	All looks lovely, looking forward to coming! I have a hat!!!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5	28
38	Paul Dunn	Paul Dunn	Paul.dunn59@gmail.com	t	19	Day Guest	f	f	f	If my beef can be well done that would be very helpful.	Looking forward to enjoying the day with you both!	\N	t	\N	\N	\N	\N	\N	\N	1	7	5	31
40	Louise Wooldridge	Louise Wooldridge	louisedunn94@gmail.com	t	20	Day Guest	f	f	f	Mushroom Intolerance (although doesn’t look like that will be an issue)	\N	\N	t	\N	\N	\N	\N	\N	\N	3	7	5	33
\.


--
-- Data for Name: guests_duplicate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."guests_duplicate" ("id", "reference_name", "name", "email", "rsvp", "household", "role", "requires_childcare_data", "requires_childrens_menu", "requires_childcare", "dietary_requirements", "comments", "favourite_board_game", "invited_day_after", "invited_evening_before", "evening_only", "partner_invited", "is_child", "day_before_rsvp", "day_after_rsvp", "course_1_id", "course_2_id", "course_3_id") FROM stdin;
5	Jon Masson	Jon Masson	\N	\N	4	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
6	Ian Dunn	Ian Dunn	\N	\N	5	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
7	Alex Prichard	Alex Prichard	\N	\N	6	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
8	Adam Chodera	Adam Chodera	\N	\N	7	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
9	Stephen Quinn	Stephen Quinn	\N	\N	8	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
12	Helena Chan	Helena Chan	\N	\N	4	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
13	Katie Hannaford	Katie Hannaford	\N	\N	9	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
14	Alexei Barnes	Alexei Barnes	\N	\N	9	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
15	Ian Barwick	Ian Barwick	\N	\N	10	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
16	Ellie Barwick	Ellie Barwick	\N	\N	10	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
17	Enzo Barwick	Enzo Barwick	\N	\N	10	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
18	Luca Barwick	Luca Barwick	\N	\N	10	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
19	Todd Francis	Todd Francis	\N	\N	11	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
20	Reem Khurshid	Reem Khurshid	\N	\N	11	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
21	Christopher Price-Dahlgren	Christopher Price-Dahlgren	\N	\N	12	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
22	Cilla Price-Dahlgren	Cilla Price-Dahlgren	\N	\N	12	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
23	Saphi Price-Dahlgren	Saphi Price-Dahlgren	\N	\N	12	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
24	Hannah Capocci-Hunt	Hannah Capocci-Hunt	\N	\N	13	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
26	Artemis Capocci-Hunt	Artemis Capocci-Hunt	\N	\N	13	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
27	Astraea Capocci-Hunt	Astraea Capocci-Hunt	\N	\N	13	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
28	Marcus Fox	Marcus Fox	\N	\N	14	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
29	Helen Pitel	Helen Pitel	\N	\N	15	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
31	Sally Pitel	Sally Pitel	\N	\N	16	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
32	Laura Pitel	Laura Pitel	\N	\N	17	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
33	John McManus	John McManus	\N	\N	17	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
34	Margot McTel	Margot McTel	\N	\N	17	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
35	Rowan McTel	Rowan McTel	\N	\N	17	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
36	Beatrix Pitel	Beatrix Pitel	\N	\N	18	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
37	Dermot Colton	Dermot Colton	\N	\N	18	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
38	Paul Dunn	Paul Dunn	\N	\N	19	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
39	Janet Dunn	Janet Dunn	\N	\N	19	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
40	Louise Wooldridge	Louise Wooldridge	\N	\N	20	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
41	Jon Wooldridge	Jon Wooldridge	\N	\N	20	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
42	Libby Dunn	Libby Dunn	\N	\N	5	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
43	Millie Dunn	Millie Dunn	\N	\N	5	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
44	Edward Sanders	Edward Sanders	\N	\N	21	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
45	Pandora Blair	Pandora Blair	\N	\N	22	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
46	Harriet Blair	Harriet Blair	\N	\N	22	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
47	Stacey Chodera	Stacey Chodera	\N	\N	7	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
48	Martin Paul	Martin Paul	\N	\N	23	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
49	Amy Paul	Amy Paul	\N	\N	23	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
50	Theodore Paul	Theodore Paul	\N	\N	23	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
51	Craig Sargent	Craig Sargent	\N	\N	24	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
52	Sam Sargent	Sam Sargent	\N	\N	24	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
53	Alix Lyons	Alix Lyons	\N	\N	25	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
54	James Lyons	James Lyons	\N	\N	25	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
55	Colin Paxton	Colin Paxton	\N	\N	26	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
56	Jonathan Vooght	Jonathan Vooght	\N	\N	27	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
57	Matthew Burnett	Matthew Burnett	\N	\N	28	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
58	Tanya Burnett	Tanya Burnett	\N	\N	28	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
59	Nick Bartly	Nick Bartly	\N	\N	29	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
60	Jana Bartly	Jana Bartly	\N	\N	29	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
61	Shaun Zedlewski	Shaun Zedlewski	\N	\N	30	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
62	Adam Dunnicliffe	Adam Dunnicliffe	\N	\N	31	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
63	Michel Dunnicliffe	Michel Dunnicliffe	\N	\N	31	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
64	Joel Dunnicliffe	Joel Dunnicliffe	\N	\N	31	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
65	Georgia Dunnicliffe	Georgia Dunnicliffe	\N	\N	31	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
66	Shreya Garge	Shreya Garge	\N	\N	8	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
67	Daniel Hanvey	Daniel Hanvey	\N	\N	32	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
68	David Holtum	David Holtum	\N	\N	33	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
69	Heather Holtum	Heather Holtum	\N	\N	33	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
70	Henry Holtum	Henry Holtum	\N	\N	33	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
71	Ezra Attwood	Ezra Attwood	\N	\N	34	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
72	Matthew Nutt	Matthew Nutt	\N	\N	35	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
73	Matthew Wyles	Matthew Wyles	\N	\N	36	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
74	Oliver Byford	Oliver Byford	\N	\N	37	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
75	Emily Byford	Emily Byford	\N	\N	37	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
76	Elliot Byford	Elliot Byford	\N	\N	37	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
77	Sian Ebsworth	Sian Ebsworth	\N	\N	38	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
78	Stephen Briscoe	Stephen Briscoe	\N	\N	39	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
79	SB	SB	\N	\N	40	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
80	Erika Sojkova	Erika Sojkova	\N	\N	40	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
81	Will Saunders	Will Saunders	\N	\N	41	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
82	Tom Jordan	Tom Jordan	\N	\N	42	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
3	Alyssa Burling	Alyssa Burling	alyssa.burlton@gmail.com	t	2	Wedding Party	f	f	f	\N	I tried to follow your spaceship directions and flew into the sun :(	\N	t	\N	\N	\N	\N	\N	yes	1	8	0
25	Kieron Capocci-Hunt	Kieron Capocci-Hunt	\N	\N	13	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
1	Freddy Pitel	Freddy Pitel	fwbpitel@gmail.com	t	1	Groom	f	f	f	Gluten and dairy intollerance	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5
30	Nigel Pitel	Nigel Pitel	\N	\N	15	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
83	Giada Jordan	Giada Jordan	\N	\N	42	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
84	Lawrance Bailes	Lawrance Bailes	\N	\N	43	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
85	Chris Bradley	Chris Bradley	\N	\N	43	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
86	Richard Nicholson	Richard Nicholson	\N	\N	44	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
87	Helen Nicholson	Helen Nicholson	\N	\N	44	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
88	Cherie Fox	Cherie Fox	\N	\N	45	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
89	John Fox	John Fox	\N	\N	45	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
90	Timothy Finlay	Timothy Finlay	\N	\N	46	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
91	Eileen Finlay	Eileen Finlay	\N	\N	46	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
92	Oliver Nicholson	Oliver Nicholson	\N	\N	44	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
93	Ameila Pritchard	Ameila Pritchard	\N	\N	47	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
96	Roman Marych	Roman Marych	\N	\N	49	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
97	Julia Marych	Julia Marych	\N	\N	49	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
98	Julian Marych	Julian Marych	\N	\N	49	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
99	Daniel Calinski	Daniel Calinski	\N	\N	50	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
100	Angela Calinski	Angela Calinski	\N	\N	50	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
101	Ana Lu Calinksi	Ana Lu Calinksi	\N	\N	50	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
102	Adrian Gralak	Adrian Gralak	\N	\N	51	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
103	Michal Leczycki	Michal Leczycki	\N	\N	52	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
105	Beth Little	Beth Little	\N	\N	54	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
106	Martin Little	Martin Little	\N	\N	54	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
107	Harriet Little	Harriet Little	\N	\N	54	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
109	Debbie Fisher	Debbie Fisher	\N	\N	56	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
110	Evie Fisher	Evie Fisher	\N	\N	57	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
112	Charlie Fisher	Charlie Fisher	\N	\N	58	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
114	Katie Styles	Katie Styles	\N	\N	59	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
115	Tom Anderson	Tom Anderson	\N	\N	59	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
116	George Styles	George Styles	\N	\N	59	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
117	Wilf Styles	Wilf Styles	\N	\N	59	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
118	Tom Anderson	Tom Anderson	\N	\N	60	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
119	Sinead	Sinead	\N	\N	60	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
166	Gerry Lovelace	Gerry Lovelace	\N	\N	85	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
167	Sam Kenny	Sam Kenny	\N	\N	86	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
168	Anthony Whelan	Anthony Whelan	\N	\N	87	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
169	Elisabeth Swedlund	Elisabeth Swedlund	\N	\N	88	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
171	Jordan Murray	Jordan Murray	\N	\N	90	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
173	Marianne Baker	Marianne Baker	\N	\N	92	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
175	Kirsty Blythe	Kirsty Blythe	\N	\N	94	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
185	Louise O'Young	Louise O'Young	\N	\N	101	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
186	Dan Pope	Dan Pope	\N	\N	102	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
187	Mia Violentano	Mia Violentano	\N	\N	103	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
189	Rachel Dowse	Rachel Dowse	\N	\N	105	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
190	Nathan Williams	Nathan Williams	\N	\N	106	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
191	Lawrence Bishop	Lawrence Bishop	\N	\N	107	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
192	Jamie Jones	Jamie Jones	\N	\N	108	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
193	Nanditha Garge	Nanditha Garge	\N	\N	109	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
194	Lucy Williams	Lucy Williams	\N	\N	106	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
195	Corrine O'Connor	Corrine O'Connor	\N	\N	110	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
196	Matt O'Connor	Matt O'Connor	\N	\N	110	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
11	Sara Fisher	Sara Fisher	thefishers5725@gmail.com	t	3	Day Guest	f	f	f	\N	Happy wedding planning! Nth time is the charm!	\N	t	\N	\N	\N	\N	\N	yes	1	7	5
4	Mark Fisher	Mark Fisher	thefishers5725@gmail.com	t	3	Wedding Party	f	f	f	\N	Wahoo! It's working!	\N	t	\N	\N	\N	\N	\N	yes	1	7	5
170	Reuben Goldmark	Reuben Goldmark	reubengoldmark@gmail.com	t	89	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
172	Madeline MacLean	Madeline MacLean	madelinemaclean9@gmail.com	t	91	Day Guest	f	f	f	\N	I am incredibly excited and audibly hungry for this!! Can’t wait xx	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
10	Leah Burling	Leah Burling	leah.ann.king93@gmail.com	t	2	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	0	8	0
188	Ian Ang	Ian Ang	ianang1993@gmail.com	t	104	Day Guest	f	f	f	\N	Yummy yummy yummy I got yummy in my tummy	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
2	David Fox	David Fox	djwfox@gmail.com	t	1	Groom	f	f	f	no pork/shellfish	I love you!	\N	t	\N	\N	\N	\N	\N	yes	1	7	5
\.


--
-- Data for Name: households; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."households" ("id", "name", "code", "rsvp_sent", "accommodation_id", "invited_day_after", "invited_evening_before", "day_before_response", "day_after_response", "in_coach_house") FROM stdin;
107	Bishop	ALEL	t	\N	f	f	\N	\N	f
105	Dowse	ARKB	t	\N	f	f	\N	\N	f
91	MacLean	BBZM	t	\N	f	f	\N	\N	f
40	SB	BHUP	t	1	f	f	\N	\N	f
85	Lovelace	BLOX	t	\N	f	f	\N	\N	f
94	Blythe	BOLW	t	\N	f	f	\N	\N	f
30	Zedlewski	CCCM	t	6	f	f	\N	\N	f
25	Lyons	EKQE	t	23	f	f	\N	\N	f
37	Byford	DALP	t	8	f	f	\N	\N	f
104	Ang	DEND	t	\N	f	f	\N	\N	f
24	Sargent	FIVD	t	\N	f	f	\N	\N	f
103	Violentano	EICM	t	\N	f	f	\N	\N	f
101	O'Young	CSHH	t	\N	f	f	\N	\N	f
22	Blair	GWII	t	\N	f	f	\N	\N	f
7	Chodera	GXZU	t	\N	t	f	\N	\N	f
16	Pitel	HDDI	t	\N	t	f	\N	\N	f
33	Holtum	JATR	t	15	f	f	\N	\N	f
89	Goldmark	JRCU	t	\N	f	f	\N	\N	f
32	Hanvey	KCHT	t	9	f	f	\N	\N	f
35	Nutt	IRYU	t	6	f	f	\N	\N	f
38	Ebsworth	KPNH	t	9	f	f	\N	\N	f
56	Fisher	LNZX	t	\N	f	f	\N	\N	f
23	Paul	MNYS	t	\N	f	f	\N	\N	f
26	Paxton	NXDQ	t	6	f	f	\N	\N	f
29	Bartly	NCWV	t	24	f	f	\N	\N	f
59	Styles	ODFE	t	\N	t	f	\N	\N	f
39	Briscoe	OECP	t	\N	f	f	\N	\N	f
90	Murray	OJPB	t	\N	f	f	\N	\N	f
9	Hannaford	OYAW	t	19	f	f	\N	\N	f
11	Francis	OJBO	t	5	f	f	\N	\N	f
27	Vooght	PAJW	t	\N	f	f	\N	\N	f
87	Whelan	PCUN	t	\N	f	f	\N	\N	f
88	Swedlund	PQSM	t	\N	f	f	\N	\N	f
102	Pope	QGIU	t	\N	f	f	\N	\N	f
8	Quinn	PPLN	t	22	t	f	\N	\N	f
31	Dunnicliff	REZT	t	13	f	f	\N	\N	f
2	Burling	STCX	t	3	t	f	\N	\N	t
10	Barwick	QTNN	t	7	f	f	\N	\N	f
28	Burnett	RXEM	t	20	f	f	\N	\N	f
108	Jones	TMEH	t	\N	f	f	\N	\N	f
92	Baker	UMGQ	t	\N	f	f	\N	\N	f
18	Pitel	TCVD	t	\N	t	f	\N	\N	f
43	Bailes	UZYQ	t	\N	f	f	\N	\N	f
21	Sanders	VNNR	t	\N	f	f	\N	\N	f
106	Williams	WIWN	t	\N	f	f	\N	\N	f
6	Prichard	XOVG	t	17	t	f	\N	\N	f
3	Fisher	XLVR	t	2	t	f	\N	\N	f
109	Garge	XWMW	t	22	f	f	\N	\N	f
60	Anderson	XSKW	t	\N	t	f	\N	\N	f
86	Kenny	ZHXK	t	\N	f	f	\N	\N	f
15	Pitel	YSRN	t	\N	t	f	\N	\N	f
1	Pitel	MBWG	t	4	t	f	\N	\N	t
58	Fisher	CFJH	t	\N	t	f	\N	\N	f
57	Fisher	RTOE	t	\N	t	f	\N	\N	f
50	Calinski	XNNX	t	\N	t	f	\N	\N	f
49	Marych	XFKG	t	\N	t	f	\N	\N	f
17	Pitel	JVFF	t	\N	t	f	\N	\N	f
47	Pritchard	FGOZ	t	17	f	f	\N	\N	f
36	Wyles	BCQD	t	6	f	f	\N	\N	f
41	Saunders	YQVC	t	9	f	f	\N	\N	f
110	O'Connor	SOFF	t	\N	f	f	\N	\N	f
51	Gralak	FZBU	t	\N	t	f	\N	\N	f
34	Attwood	NISB	t	9	f	f	\N	\N	f
54	Little	ABKA	t	\N	f	f	\N	\N	f
52	Leczycki	IGBH	t	\N	t	f	\N	\N	f
13	Capocci-Hunt	FRGO	t	21	t	f	\N	\N	f
4	Masson	BMTD	t	14	t	f	\N	\N	f
12	Price-Dahlgren	HPLQ	t	11	f	f	\N	\N	f
14	Fox	BTLL	t	16	t	f	\N	\N	f
45	Fox	XQTY	t	\N	t	f	\N	\N	f
46	Finlay	MJRY	t	\N	t	f	\N	\N	f
44	Nicholson	CNJE	t	\N	f	f	\N	\N	f
42	Jordan	AKGN	t	10	f	f	\N	\N	f
5	Dunn	GNRA	t	12	t	f	\N	\N	f
20	Woolridge	CHNE	t	\N	f	f	\N	\N	f
19	Dunn	ULEM	t	\N	f	f	\N	\N	f
111	Munroe	XKCD	t	\N	f	f	\N	\N	\N
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."job_batches" ("id", "name", "total_jobs", "pending_jobs", "failed_jobs", "failed_job_ids", "options", "cancelled_at", "created_at", "finished_at") FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."jobs" ("id", "queue", "payload", "attempts", "reserved_at", "available_at", "created_at") FROM stdin;
1	default	{"uuid":"7b26b83f-e324-4fbb-943a-074570c5a085","displayName":"Closure (ContactController.php:18)","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"Illuminate\\\\Queue\\\\CallQueuedClosure","command":"O:34:\\"Illuminate\\\\Queue\\\\CallQueuedClosure\\":1:{s:7:\\"closure\\";O:47:\\"Laravel\\\\SerializableClosure\\\\SerializableClosure\\":1:{s:12:\\"serializable\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Signed\\":2:{s:12:\\"serializable\\";s:6840:\\"O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:5:\\"brevo\\";O:38:\\"App\\\\Services\\\\BrevoTransactionalService\\":1:{s:6:\\"\\u0000*\\u0000api\\";O:44:\\"SendinBlue\\\\Client\\\\Api\\\\TransactionalEmailsApi\\":3:{s:9:\\"\\u0000*\\u0000client\\";O:17:\\"GuzzleHttp\\\\Client\\":1:{s:25:\\"\\u0000GuzzleHttp\\\\Client\\u0000config\\";a:8:{s:7:\\"handler\\";O:23:\\"GuzzleHttp\\\\HandlerStack\\":3:{s:32:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000handler\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:35:\\"GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\":7:{s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:50;}s:50:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000selectTimeout\\";i:1;s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000active\\";i:0;s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000handles\\";a:0:{}s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000delays\\";a:0:{}s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000options\\";a:0:{}s:40:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000_mh\\";N;}s:4:\\"sync\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlHandler\\":1:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:3;}}}s:8:\\"function\\";s:285:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $sync): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options[\\\\GuzzleHttp\\\\RequestOptions::SYNCHRONOUS]) ? $default($request, $options) : $sync($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001ff0000000000000000\\";}s:9:\\"streaming\\";O:32:\\"GuzzleHttp\\\\Handler\\\\StreamHandler\\":1:{s:45:\\"\\u0000GuzzleHttp\\\\Handler\\\\StreamHandler\\u0000lastHeaders\\";a:0:{}}}s:8:\\"function\\";s:264:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $streaming): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options['stream']) ? $default($request, $options) : $streaming($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002010000000000000000\\";}s:30:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000stack\\";a:4:{i:0;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:1:{s:14:\\"bodySummarizer\\";N;}s:8:\\"function\\";s:839:\\"static function (callable $handler) use ($bodySummarizer): callable {\\n            return static function ($request, array $options) use ($handler, $bodySummarizer) {\\n                if (empty($options['http_errors'])) {\\n                    return $handler($request, $options);\\n                }\\n\\n                return $handler($request, $options)->then(\\n                    static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($request, $bodySummarizer) {\\n                        $code = $response->getStatusCode();\\n                        if ($code < 400) {\\n                            return $response;\\n                        }\\n                        throw \\\\GuzzleHttp\\\\Exception\\\\RequestException::create($request, $response, null, [], $bodySummarizer);\\n                    }\\n                );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002020000000000000000\\";}i:1;s:11:\\"http_errors\\";}i:1;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:144:\\"static function (callable $handler): \\\\GuzzleHttp\\\\RedirectMiddleware {\\n            return new \\\\GuzzleHttp\\\\RedirectMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002030000000000000000\\";}i:1;s:15:\\"allow_redirects\\";}i:2;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:1030:\\"static function (callable $handler): callable {\\n            return static function ($request, array $options) use ($handler) {\\n                if (empty($options['cookies'])) {\\n                    return $handler($request, $options);\\n                } elseif (!($options['cookies'] instanceof \\\\GuzzleHttp\\\\Cookie\\\\CookieJarInterface)) {\\n                    throw new \\\\InvalidArgumentException('cookies must be an instance of GuzzleHttp\\\\Cookie\\\\CookieJarInterface');\\n                }\\n                $cookieJar = $options['cookies'];\\n                $request = $cookieJar->withCookieHeader($request);\\n\\n                return $handler($request, $options)\\n                    ->then(\\n                        static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($cookieJar, $request): \\\\Psr\\\\Http\\\\Message\\\\ResponseInterface {\\n                            $cookieJar->extractCookies($request, $response);\\n\\n                            return $response;\\n                        }\\n                    );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002040000000000000000\\";}i:1;s:7:\\"cookies\\";}i:3;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:150:\\"static function (callable $handler): \\\\GuzzleHttp\\\\PrepareBodyMiddleware {\\n            return new \\\\GuzzleHttp\\\\PrepareBodyMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002050000000000000000\\";}i:1;s:12:\\"prepare_body\\";}}s:31:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000cached\\";N;}s:15:\\"allow_redirects\\";a:5:{s:3:\\"max\\";i:5;s:9:\\"protocols\\";a:2:{i:0;s:4:\\"http\\";i:1;s:5:\\"https\\";}s:6:\\"strict\\";b:0;s:7:\\"referer\\";b:0;s:15:\\"track_redirects\\";b:0;}s:11:\\"http_errors\\";b:1;s:14:\\"decode_content\\";b:1;s:6:\\"verify\\";b:1;s:7:\\"cookies\\";b:0;s:14:\\"idn_conversion\\";b:0;s:7:\\"headers\\";a:1:{s:10:\\"User-Agent\\";s:12:\\"GuzzleHttp\\/7\\";}}}s:9:\\"\\u0000*\\u0000config\\";O:31:\\"SendinBlue\\\\Client\\\\Configuration\\":10:{s:10:\\"\\u0000*\\u0000apiKeys\\";a:1:{s:7:\\"api-key\\";s:89:\\"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\\";}s:17:\\"\\u0000*\\u0000apiKeyPrefixes\\";a:0:{}s:14:\\"\\u0000*\\u0000accessToken\\";s:0:\\"\\";s:11:\\"\\u0000*\\u0000username\\";s:0:\\"\\";s:11:\\"\\u0000*\\u0000password\\";s:0:\\"\\";s:7:\\"\\u0000*\\u0000host\\";s:29:\\"https:\\/\\/api.sendinblue.com\\/v3\\";s:12:\\"\\u0000*\\u0000userAgent\\";s:31:\\"sendinblue_clientAPI\\/v8.4.2\\/php\\";s:8:\\"\\u0000*\\u0000debug\\";b:0;s:12:\\"\\u0000*\\u0000debugFile\\";s:12:\\"php:\\/\\/output\\";s:17:\\"\\u0000*\\u0000tempFolderPath\\";s:4:\\"\\/tmp\\";}s:17:\\"\\u0000*\\u0000headerSelector\\";O:32:\\"SendinBlue\\\\Client\\\\HeaderSelector\\":0:{}}}s:4:\\"data\\";a:3:{s:4:\\"name\\";s:24:\\"Freddy Pitel & David Fox\\";s:5:\\"email\\";s:13:\\"test@test.com\\";s:7:\\"message\\";s:26:\\"Main website comment test!\\";}}s:8:\\"function\\";s:90:\\"function () use ($brevo, $data) {\\n            $brevo->sendContactMessage($data);\\n        }\\";s:5:\\"scope\\";s:38:\\"App\\\\Http\\\\Controllers\\\\ContactController\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001f30000000000000000\\";}\\";s:4:\\"hash\\";s:44:\\"L0GSJZBx+ZPYobKzik3DcTBFcYKXzVgCE0JakSMeGik=\\";}}}","batchId":null},"createdAt":1774791002,"delay":null}	0	\N	1774791002	1774791002
2	default	{"uuid":"b8bd3c3b-475b-406e-aae5-d2890fa2a76d","displayName":"Closure (ContactController.php:18)","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"Illuminate\\\\Queue\\\\CallQueuedClosure","command":"O:34:\\"Illuminate\\\\Queue\\\\CallQueuedClosure\\":1:{s:7:\\"closure\\";O:47:\\"Laravel\\\\SerializableClosure\\\\SerializableClosure\\":1:{s:12:\\"serializable\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Signed\\":2:{s:12:\\"serializable\\";s:22468:\\"O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:5:\\"brevo\\";O:38:\\"App\\\\Services\\\\BrevoTransactionalService\\":1:{s:9:\\"\\u0000*\\u0000client\\";O:11:\\"Brevo\\\\Brevo\\":34:{s:7:\\"account\\";O:27:\\"Brevo\\\\Account\\\\AccountClient\\":2:{s:36:\\"\\u0000Brevo\\\\Account\\\\AccountClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Account\\\\AccountClient\\u0000client\\";O:27:\\"Brevo\\\\Core\\\\Client\\\\RawClient\\":6:{s:35:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000client\\";O:39:\\"Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\":4:{s:47:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000client\\";O:17:\\"GuzzleHttp\\\\Client\\":1:{s:25:\\"\\u0000GuzzleHttp\\\\Client\\u0000config\\";a:8:{s:7:\\"handler\\";O:23:\\"GuzzleHttp\\\\HandlerStack\\":3:{s:32:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000handler\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:35:\\"GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\":7:{s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:50;}s:50:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000selectTimeout\\";i:1;s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000active\\";i:0;s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000handles\\";a:0:{}s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000delays\\";a:0:{}s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000options\\";a:0:{}s:40:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000_mh\\";N;}s:4:\\"sync\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlHandler\\":1:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:3;}}}s:8:\\"function\\";s:285:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $sync): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options[\\\\GuzzleHttp\\\\RequestOptions::SYNCHRONOUS]) ? $default($request, $options) : $sync($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001ff0000000000000000\\";}s:9:\\"streaming\\";O:32:\\"GuzzleHttp\\\\Handler\\\\StreamHandler\\":1:{s:45:\\"\\u0000GuzzleHttp\\\\Handler\\\\StreamHandler\\u0000lastHeaders\\";a:0:{}}}s:8:\\"function\\";s:264:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $streaming): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options['stream']) ? $default($request, $options) : $streaming($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002010000000000000000\\";}s:30:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000stack\\";a:4:{i:0;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:1:{s:14:\\"bodySummarizer\\";N;}s:8:\\"function\\";s:839:\\"static function (callable $handler) use ($bodySummarizer): callable {\\n            return static function ($request, array $options) use ($handler, $bodySummarizer) {\\n                if (empty($options['http_errors'])) {\\n                    return $handler($request, $options);\\n                }\\n\\n                return $handler($request, $options)->then(\\n                    static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($request, $bodySummarizer) {\\n                        $code = $response->getStatusCode();\\n                        if ($code < 400) {\\n                            return $response;\\n                        }\\n                        throw \\\\GuzzleHttp\\\\Exception\\\\RequestException::create($request, $response, null, [], $bodySummarizer);\\n                    }\\n                );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002020000000000000000\\";}i:1;s:11:\\"http_errors\\";}i:1;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:144:\\"static function (callable $handler): \\\\GuzzleHttp\\\\RedirectMiddleware {\\n            return new \\\\GuzzleHttp\\\\RedirectMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002030000000000000000\\";}i:1;s:15:\\"allow_redirects\\";}i:2;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:1030:\\"static function (callable $handler): callable {\\n            return static function ($request, array $options) use ($handler) {\\n                if (empty($options['cookies'])) {\\n                    return $handler($request, $options);\\n                } elseif (!($options['cookies'] instanceof \\\\GuzzleHttp\\\\Cookie\\\\CookieJarInterface)) {\\n                    throw new \\\\InvalidArgumentException('cookies must be an instance of GuzzleHttp\\\\Cookie\\\\CookieJarInterface');\\n                }\\n                $cookieJar = $options['cookies'];\\n                $request = $cookieJar->withCookieHeader($request);\\n\\n                return $handler($request, $options)\\n                    ->then(\\n                        static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($cookieJar, $request): \\\\Psr\\\\Http\\\\Message\\\\ResponseInterface {\\n                            $cookieJar->extractCookies($request, $response);\\n\\n                            return $response;\\n                        }\\n                    );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002040000000000000000\\";}i:1;s:7:\\"cookies\\";}i:3;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:150:\\"static function (callable $handler): \\\\GuzzleHttp\\\\PrepareBodyMiddleware {\\n            return new \\\\GuzzleHttp\\\\PrepareBodyMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002050000000000000000\\";}i:1;s:12:\\"prepare_body\\";}}s:31:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000cached\\";N;}s:15:\\"allow_redirects\\";a:5:{s:3:\\"max\\";i:5;s:9:\\"protocols\\";a:2:{i:0;s:4:\\"http\\";i:1;s:5:\\"https\\";}s:6:\\"strict\\";b:0;s:7:\\"referer\\";b:0;s:15:\\"track_redirects\\";b:0;}s:11:\\"http_errors\\";b:1;s:14:\\"decode_content\\";b:1;s:6:\\"verify\\";b:1;s:7:\\"cookies\\";b:0;s:14:\\"idn_conversion\\";b:0;s:7:\\"headers\\";a:1:{s:10:\\"User-Agent\\";s:12:\\"GuzzleHttp\\/7\\";}}}s:51:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000maxRetries\\";i:2;s:50:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000baseDelay\\";i:1000;s:54:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000sleepFunction\\";s:6:\\"usleep\\";}s:43:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000requestFactory\\";O:27:\\"GuzzleHttp\\\\Psr7\\\\HttpFactory\\":0:{}s:42:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000streamFactory\\";O:27:\\"GuzzleHttp\\\\Psr7\\\\HttpFactory\\":0:{}s:36:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}s:43:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000getAuthHeaders\\";N;s:7:\\"options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}}}s:13:\\"masterAccount\\";O:39:\\"Brevo\\\\MasterAccount\\\\MasterAccountClient\\":2:{s:48:\\"\\u0000Brevo\\\\MasterAccount\\\\MasterAccountClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\MasterAccount\\\\MasterAccountClient\\u0000client\\";r:13;}s:4:\\"user\\";O:21:\\"Brevo\\\\User\\\\UserClient\\":2:{s:30:\\"\\u0000Brevo\\\\User\\\\UserClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:29:\\"\\u0000Brevo\\\\User\\\\UserClient\\u0000client\\";r:13;}s:7:\\"process\\";O:27:\\"Brevo\\\\Process\\\\ProcessClient\\":2:{s:36:\\"\\u0000Brevo\\\\Process\\\\ProcessClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Process\\\\ProcessClient\\u0000client\\";r:13;}s:7:\\"senders\\";O:27:\\"Brevo\\\\Senders\\\\SendersClient\\":2:{s:36:\\"\\u0000Brevo\\\\Senders\\\\SendersClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Senders\\\\SendersClient\\u0000client\\";r:13;}s:7:\\"domains\\";O:27:\\"Brevo\\\\Domains\\\\DomainsClient\\":2:{s:36:\\"\\u0000Brevo\\\\Domains\\\\DomainsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Domains\\\\DomainsClient\\u0000client\\";r:13;}s:8:\\"webhooks\\";O:29:\\"Brevo\\\\Webhooks\\\\WebhooksClient\\":2:{s:38:\\"\\u0000Brevo\\\\Webhooks\\\\WebhooksClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Webhooks\\\\WebhooksClient\\u0000client\\";r:13;}s:13:\\"externalFeeds\\";O:39:\\"Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\":2:{s:48:\\"\\u0000Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\u0000client\\";r:13;}s:13:\\"customObjects\\";O:39:\\"Brevo\\\\CustomObjects\\\\CustomObjectsClient\\":2:{s:48:\\"\\u0000Brevo\\\\CustomObjects\\\\CustomObjectsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\CustomObjects\\\\CustomObjectsClient\\u0000client\\";r:13;}s:8:\\"contacts\\";O:29:\\"Brevo\\\\Contacts\\\\ContactsClient\\":2:{s:38:\\"\\u0000Brevo\\\\Contacts\\\\ContactsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Contacts\\\\ContactsClient\\u0000client\\";r:13;}s:13:\\"conversations\\";O:39:\\"Brevo\\\\Conversations\\\\ConversationsClient\\":2:{s:48:\\"\\u0000Brevo\\\\Conversations\\\\ConversationsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\Conversations\\\\ConversationsClient\\u0000client\\";r:13;}s:9:\\"ecommerce\\";O:31:\\"Brevo\\\\Ecommerce\\\\EcommerceClient\\":2:{s:40:\\"\\u0000Brevo\\\\Ecommerce\\\\EcommerceClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:39:\\"\\u0000Brevo\\\\Ecommerce\\\\EcommerceClient\\u0000client\\";r:13;}s:7:\\"coupons\\";O:27:\\"Brevo\\\\Coupons\\\\CouponsClient\\":2:{s:36:\\"\\u0000Brevo\\\\Coupons\\\\CouponsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Coupons\\\\CouponsClient\\u0000client\\";r:13;}s:8:\\"payments\\";O:29:\\"Brevo\\\\Payments\\\\PaymentsClient\\":2:{s:38:\\"\\u0000Brevo\\\\Payments\\\\PaymentsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Payments\\\\PaymentsClient\\u0000client\\";r:13;}s:5:\\"event\\";O:23:\\"Brevo\\\\Event\\\\EventClient\\":2:{s:32:\\"\\u0000Brevo\\\\Event\\\\EventClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Event\\\\EventClient\\u0000client\\";r:13;}s:14:\\"inboundParsing\\";O:41:\\"Brevo\\\\InboundParsing\\\\InboundParsingClient\\":2:{s:50:\\"\\u0000Brevo\\\\InboundParsing\\\\InboundParsingClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:49:\\"\\u0000Brevo\\\\InboundParsing\\\\InboundParsingClient\\u0000client\\";r:13;}s:7:\\"balance\\";O:27:\\"Brevo\\\\Balance\\\\BalanceClient\\":2:{s:36:\\"\\u0000Brevo\\\\Balance\\\\BalanceClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Balance\\\\BalanceClient\\u0000client\\";r:13;}s:7:\\"program\\";O:27:\\"Brevo\\\\Program\\\\ProgramClient\\":2:{s:36:\\"\\u0000Brevo\\\\Program\\\\ProgramClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Program\\\\ProgramClient\\u0000client\\";r:13;}s:6:\\"reward\\";O:25:\\"Brevo\\\\Reward\\\\RewardClient\\":2:{s:34:\\"\\u0000Brevo\\\\Reward\\\\RewardClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:33:\\"\\u0000Brevo\\\\Reward\\\\RewardClient\\u0000client\\";r:13;}s:4:\\"tier\\";O:21:\\"Brevo\\\\Tier\\\\TierClient\\":2:{s:30:\\"\\u0000Brevo\\\\Tier\\\\TierClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:29:\\"\\u0000Brevo\\\\Tier\\\\TierClient\\u0000client\\";r:13;}s:14:\\"emailCampaigns\\";O:41:\\"Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\":2:{s:50:\\"\\u0000Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:49:\\"\\u0000Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\u0000client\\";r:13;}s:12:\\"smsCampaigns\\";O:37:\\"Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\":2:{s:46:\\"\\u0000Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:45:\\"\\u0000Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\u0000client\\";r:13;}s:17:\\"whatsAppCampaigns\\";O:47:\\"Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\":2:{s:56:\\"\\u0000Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:55:\\"\\u0000Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\u0000client\\";r:13;}s:9:\\"companies\\";O:31:\\"Brevo\\\\Companies\\\\CompaniesClient\\":2:{s:40:\\"\\u0000Brevo\\\\Companies\\\\CompaniesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:39:\\"\\u0000Brevo\\\\Companies\\\\CompaniesClient\\u0000client\\";r:13;}s:5:\\"deals\\";O:23:\\"Brevo\\\\Deals\\\\DealsClient\\":2:{s:32:\\"\\u0000Brevo\\\\Deals\\\\DealsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Deals\\\\DealsClient\\u0000client\\";r:13;}s:5:\\"files\\";O:23:\\"Brevo\\\\Files\\\\FilesClient\\":2:{s:32:\\"\\u0000Brevo\\\\Files\\\\FilesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Files\\\\FilesClient\\u0000client\\";r:13;}s:5:\\"notes\\";O:23:\\"Brevo\\\\Notes\\\\NotesClient\\":2:{s:32:\\"\\u0000Brevo\\\\Notes\\\\NotesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Notes\\\\NotesClient\\u0000client\\";r:13;}s:5:\\"tasks\\";O:23:\\"Brevo\\\\Tasks\\\\TasksClient\\":2:{s:32:\\"\\u0000Brevo\\\\Tasks\\\\TasksClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Tasks\\\\TasksClient\\u0000client\\";r:13;}s:21:\\"transactionalWhatsApp\\";O:55:\\"Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\":2:{s:64:\\"\\u0000Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:63:\\"\\u0000Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\u0000client\\";r:13;}s:19:\\"transactionalEmails\\";O:51:\\"Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\":2:{s:60:\\"\\u0000Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:59:\\"\\u0000Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\u0000client\\";r:13;}s:16:\\"transactionalSms\\";O:45:\\"Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\":2:{s:54:\\"\\u0000Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:53:\\"\\u0000Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\u0000client\\";r:13;}s:12:\\"smsTemplates\\";O:37:\\"Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\":2:{s:46:\\"\\u0000Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:45:\\"\\u0000Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\u0000client\\";r:13;}s:20:\\"\\u0000Brevo\\\\Brevo\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:19:\\"\\u0000Brevo\\\\Brevo\\u0000client\\";r:13;}}s:4:\\"data\\";a:3:{s:4:\\"name\\";s:24:\\"Freddy Pitel & David Fox\\";s:5:\\"email\\";s:16:\\"djwfox@gmail.com\\";s:7:\\"message\\";s:4:\\"Test\\";}}s:8:\\"function\\";s:90:\\"function () use ($brevo, $data) {\\n            $brevo->sendContactMessage($data);\\n        }\\";s:5:\\"scope\\";s:38:\\"App\\\\Http\\\\Controllers\\\\ContactController\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001f30000000000000000\\";}\\";s:4:\\"hash\\";s:44:\\"jA03I5E0qgT5TaoBboNEa63bj6z+wmoSJokgWyjNU44=\\";}}}","batchId":null},"createdAt":1774802751,"delay":null}	0	\N	1774802751	1774802751
3	default	{"uuid":"37ec9551-a1ca-4904-a465-b5b0d2d1fef6","displayName":"Closure (ContactController.php:18)","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"Illuminate\\\\Queue\\\\CallQueuedClosure","command":"O:34:\\"Illuminate\\\\Queue\\\\CallQueuedClosure\\":1:{s:7:\\"closure\\";O:47:\\"Laravel\\\\SerializableClosure\\\\SerializableClosure\\":1:{s:12:\\"serializable\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Signed\\":2:{s:12:\\"serializable\\";s:22577:\\"O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:5:\\"brevo\\";O:38:\\"App\\\\Services\\\\BrevoTransactionalService\\":1:{s:9:\\"\\u0000*\\u0000client\\";O:11:\\"Brevo\\\\Brevo\\":34:{s:7:\\"account\\";O:27:\\"Brevo\\\\Account\\\\AccountClient\\":2:{s:36:\\"\\u0000Brevo\\\\Account\\\\AccountClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Account\\\\AccountClient\\u0000client\\";O:27:\\"Brevo\\\\Core\\\\Client\\\\RawClient\\":6:{s:35:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000client\\";O:39:\\"Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\":4:{s:47:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000client\\";O:17:\\"GuzzleHttp\\\\Client\\":1:{s:25:\\"\\u0000GuzzleHttp\\\\Client\\u0000config\\";a:8:{s:7:\\"handler\\";O:23:\\"GuzzleHttp\\\\HandlerStack\\":3:{s:32:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000handler\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:35:\\"GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\":7:{s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:50;}s:50:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000selectTimeout\\";i:1;s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000active\\";i:0;s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000handles\\";a:0:{}s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000delays\\";a:0:{}s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000options\\";a:0:{}s:40:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000_mh\\";N;}s:4:\\"sync\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlHandler\\":1:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:3;}}}s:8:\\"function\\";s:285:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $sync): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options[\\\\GuzzleHttp\\\\RequestOptions::SYNCHRONOUS]) ? $default($request, $options) : $sync($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001ff0000000000000000\\";}s:9:\\"streaming\\";O:32:\\"GuzzleHttp\\\\Handler\\\\StreamHandler\\":1:{s:45:\\"\\u0000GuzzleHttp\\\\Handler\\\\StreamHandler\\u0000lastHeaders\\";a:0:{}}}s:8:\\"function\\";s:264:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $streaming): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options['stream']) ? $default($request, $options) : $streaming($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002010000000000000000\\";}s:30:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000stack\\";a:4:{i:0;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:1:{s:14:\\"bodySummarizer\\";N;}s:8:\\"function\\";s:839:\\"static function (callable $handler) use ($bodySummarizer): callable {\\n            return static function ($request, array $options) use ($handler, $bodySummarizer) {\\n                if (empty($options['http_errors'])) {\\n                    return $handler($request, $options);\\n                }\\n\\n                return $handler($request, $options)->then(\\n                    static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($request, $bodySummarizer) {\\n                        $code = $response->getStatusCode();\\n                        if ($code < 400) {\\n                            return $response;\\n                        }\\n                        throw \\\\GuzzleHttp\\\\Exception\\\\RequestException::create($request, $response, null, [], $bodySummarizer);\\n                    }\\n                );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002020000000000000000\\";}i:1;s:11:\\"http_errors\\";}i:1;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:144:\\"static function (callable $handler): \\\\GuzzleHttp\\\\RedirectMiddleware {\\n            return new \\\\GuzzleHttp\\\\RedirectMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002030000000000000000\\";}i:1;s:15:\\"allow_redirects\\";}i:2;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:1030:\\"static function (callable $handler): callable {\\n            return static function ($request, array $options) use ($handler) {\\n                if (empty($options['cookies'])) {\\n                    return $handler($request, $options);\\n                } elseif (!($options['cookies'] instanceof \\\\GuzzleHttp\\\\Cookie\\\\CookieJarInterface)) {\\n                    throw new \\\\InvalidArgumentException('cookies must be an instance of GuzzleHttp\\\\Cookie\\\\CookieJarInterface');\\n                }\\n                $cookieJar = $options['cookies'];\\n                $request = $cookieJar->withCookieHeader($request);\\n\\n                return $handler($request, $options)\\n                    ->then(\\n                        static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($cookieJar, $request): \\\\Psr\\\\Http\\\\Message\\\\ResponseInterface {\\n                            $cookieJar->extractCookies($request, $response);\\n\\n                            return $response;\\n                        }\\n                    );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002040000000000000000\\";}i:1;s:7:\\"cookies\\";}i:3;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:150:\\"static function (callable $handler): \\\\GuzzleHttp\\\\PrepareBodyMiddleware {\\n            return new \\\\GuzzleHttp\\\\PrepareBodyMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002050000000000000000\\";}i:1;s:12:\\"prepare_body\\";}}s:31:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000cached\\";N;}s:15:\\"allow_redirects\\";a:5:{s:3:\\"max\\";i:5;s:9:\\"protocols\\";a:2:{i:0;s:4:\\"http\\";i:1;s:5:\\"https\\";}s:6:\\"strict\\";b:0;s:7:\\"referer\\";b:0;s:15:\\"track_redirects\\";b:0;}s:11:\\"http_errors\\";b:1;s:14:\\"decode_content\\";b:1;s:6:\\"verify\\";b:1;s:7:\\"cookies\\";b:0;s:14:\\"idn_conversion\\";b:0;s:7:\\"headers\\";a:1:{s:10:\\"User-Agent\\";s:12:\\"GuzzleHttp\\/7\\";}}}s:51:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000maxRetries\\";i:2;s:50:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000baseDelay\\";i:1000;s:54:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000sleepFunction\\";s:6:\\"usleep\\";}s:43:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000requestFactory\\";O:27:\\"GuzzleHttp\\\\Psr7\\\\HttpFactory\\":0:{}s:42:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000streamFactory\\";O:27:\\"GuzzleHttp\\\\Psr7\\\\HttpFactory\\":0:{}s:36:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}s:43:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000getAuthHeaders\\";N;s:7:\\"options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}}}s:13:\\"masterAccount\\";O:39:\\"Brevo\\\\MasterAccount\\\\MasterAccountClient\\":2:{s:48:\\"\\u0000Brevo\\\\MasterAccount\\\\MasterAccountClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\MasterAccount\\\\MasterAccountClient\\u0000client\\";r:13;}s:4:\\"user\\";O:21:\\"Brevo\\\\User\\\\UserClient\\":2:{s:30:\\"\\u0000Brevo\\\\User\\\\UserClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:29:\\"\\u0000Brevo\\\\User\\\\UserClient\\u0000client\\";r:13;}s:7:\\"process\\";O:27:\\"Brevo\\\\Process\\\\ProcessClient\\":2:{s:36:\\"\\u0000Brevo\\\\Process\\\\ProcessClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Process\\\\ProcessClient\\u0000client\\";r:13;}s:7:\\"senders\\";O:27:\\"Brevo\\\\Senders\\\\SendersClient\\":2:{s:36:\\"\\u0000Brevo\\\\Senders\\\\SendersClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Senders\\\\SendersClient\\u0000client\\";r:13;}s:7:\\"domains\\";O:27:\\"Brevo\\\\Domains\\\\DomainsClient\\":2:{s:36:\\"\\u0000Brevo\\\\Domains\\\\DomainsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Domains\\\\DomainsClient\\u0000client\\";r:13;}s:8:\\"webhooks\\";O:29:\\"Brevo\\\\Webhooks\\\\WebhooksClient\\":2:{s:38:\\"\\u0000Brevo\\\\Webhooks\\\\WebhooksClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Webhooks\\\\WebhooksClient\\u0000client\\";r:13;}s:13:\\"externalFeeds\\";O:39:\\"Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\":2:{s:48:\\"\\u0000Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\u0000client\\";r:13;}s:13:\\"customObjects\\";O:39:\\"Brevo\\\\CustomObjects\\\\CustomObjectsClient\\":2:{s:48:\\"\\u0000Brevo\\\\CustomObjects\\\\CustomObjectsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\CustomObjects\\\\CustomObjectsClient\\u0000client\\";r:13;}s:8:\\"contacts\\";O:29:\\"Brevo\\\\Contacts\\\\ContactsClient\\":2:{s:38:\\"\\u0000Brevo\\\\Contacts\\\\ContactsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Contacts\\\\ContactsClient\\u0000client\\";r:13;}s:13:\\"conversations\\";O:39:\\"Brevo\\\\Conversations\\\\ConversationsClient\\":2:{s:48:\\"\\u0000Brevo\\\\Conversations\\\\ConversationsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\Conversations\\\\ConversationsClient\\u0000client\\";r:13;}s:9:\\"ecommerce\\";O:31:\\"Brevo\\\\Ecommerce\\\\EcommerceClient\\":2:{s:40:\\"\\u0000Brevo\\\\Ecommerce\\\\EcommerceClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:39:\\"\\u0000Brevo\\\\Ecommerce\\\\EcommerceClient\\u0000client\\";r:13;}s:7:\\"coupons\\";O:27:\\"Brevo\\\\Coupons\\\\CouponsClient\\":2:{s:36:\\"\\u0000Brevo\\\\Coupons\\\\CouponsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Coupons\\\\CouponsClient\\u0000client\\";r:13;}s:8:\\"payments\\";O:29:\\"Brevo\\\\Payments\\\\PaymentsClient\\":2:{s:38:\\"\\u0000Brevo\\\\Payments\\\\PaymentsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Payments\\\\PaymentsClient\\u0000client\\";r:13;}s:5:\\"event\\";O:23:\\"Brevo\\\\Event\\\\EventClient\\":2:{s:32:\\"\\u0000Brevo\\\\Event\\\\EventClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Event\\\\EventClient\\u0000client\\";r:13;}s:14:\\"inboundParsing\\";O:41:\\"Brevo\\\\InboundParsing\\\\InboundParsingClient\\":2:{s:50:\\"\\u0000Brevo\\\\InboundParsing\\\\InboundParsingClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:49:\\"\\u0000Brevo\\\\InboundParsing\\\\InboundParsingClient\\u0000client\\";r:13;}s:7:\\"balance\\";O:27:\\"Brevo\\\\Balance\\\\BalanceClient\\":2:{s:36:\\"\\u0000Brevo\\\\Balance\\\\BalanceClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Balance\\\\BalanceClient\\u0000client\\";r:13;}s:7:\\"program\\";O:27:\\"Brevo\\\\Program\\\\ProgramClient\\":2:{s:36:\\"\\u0000Brevo\\\\Program\\\\ProgramClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Program\\\\ProgramClient\\u0000client\\";r:13;}s:6:\\"reward\\";O:25:\\"Brevo\\\\Reward\\\\RewardClient\\":2:{s:34:\\"\\u0000Brevo\\\\Reward\\\\RewardClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:33:\\"\\u0000Brevo\\\\Reward\\\\RewardClient\\u0000client\\";r:13;}s:4:\\"tier\\";O:21:\\"Brevo\\\\Tier\\\\TierClient\\":2:{s:30:\\"\\u0000Brevo\\\\Tier\\\\TierClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:29:\\"\\u0000Brevo\\\\Tier\\\\TierClient\\u0000client\\";r:13;}s:14:\\"emailCampaigns\\";O:41:\\"Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\":2:{s:50:\\"\\u0000Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:49:\\"\\u0000Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\u0000client\\";r:13;}s:12:\\"smsCampaigns\\";O:37:\\"Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\":2:{s:46:\\"\\u0000Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:45:\\"\\u0000Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\u0000client\\";r:13;}s:17:\\"whatsAppCampaigns\\";O:47:\\"Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\":2:{s:56:\\"\\u0000Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:55:\\"\\u0000Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\u0000client\\";r:13;}s:9:\\"companies\\";O:31:\\"Brevo\\\\Companies\\\\CompaniesClient\\":2:{s:40:\\"\\u0000Brevo\\\\Companies\\\\CompaniesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:39:\\"\\u0000Brevo\\\\Companies\\\\CompaniesClient\\u0000client\\";r:13;}s:5:\\"deals\\";O:23:\\"Brevo\\\\Deals\\\\DealsClient\\":2:{s:32:\\"\\u0000Brevo\\\\Deals\\\\DealsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Deals\\\\DealsClient\\u0000client\\";r:13;}s:5:\\"files\\";O:23:\\"Brevo\\\\Files\\\\FilesClient\\":2:{s:32:\\"\\u0000Brevo\\\\Files\\\\FilesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Files\\\\FilesClient\\u0000client\\";r:13;}s:5:\\"notes\\";O:23:\\"Brevo\\\\Notes\\\\NotesClient\\":2:{s:32:\\"\\u0000Brevo\\\\Notes\\\\NotesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Notes\\\\NotesClient\\u0000client\\";r:13;}s:5:\\"tasks\\";O:23:\\"Brevo\\\\Tasks\\\\TasksClient\\":2:{s:32:\\"\\u0000Brevo\\\\Tasks\\\\TasksClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Tasks\\\\TasksClient\\u0000client\\";r:13;}s:21:\\"transactionalWhatsApp\\";O:55:\\"Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\":2:{s:64:\\"\\u0000Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:63:\\"\\u0000Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\u0000client\\";r:13;}s:19:\\"transactionalEmails\\";O:51:\\"Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\":2:{s:60:\\"\\u0000Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:59:\\"\\u0000Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\u0000client\\";r:13;}s:16:\\"transactionalSms\\";O:45:\\"Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\":2:{s:54:\\"\\u0000Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:53:\\"\\u0000Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\u0000client\\";r:13;}s:12:\\"smsTemplates\\";O:37:\\"Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\":2:{s:46:\\"\\u0000Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:45:\\"\\u0000Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\u0000client\\";r:13;}s:20:\\"\\u0000Brevo\\\\Brevo\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:19:\\"\\u0000Brevo\\\\Brevo\\u0000client\\";r:13;}}s:4:\\"data\\";a:3:{s:4:\\"name\\";s:25:\\"Mark Fisher & Sara Fisher\\";s:5:\\"email\\";s:24:\\"thefishers5725@gmail.com\\";s:7:\\"message\\";s:102:\\"There once was a man from Peru,\\r\\nWhose limericks end on line two!\\r\\n\\r\\nThere once was a man from Verdun.\\";}}s:8:\\"function\\";s:90:\\"function () use ($brevo, $data) {\\n            $brevo->sendContactMessage($data);\\n        }\\";s:5:\\"scope\\";s:38:\\"App\\\\Http\\\\Controllers\\\\ContactController\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001f30000000000000000\\";}\\";s:4:\\"hash\\";s:44:\\"zNIoK667vJV2dMAagJXXuxd0zc0tyzQWbPIJlcRoBqw=\\";}}}","batchId":null},"createdAt":1774803182,"delay":null}	0	\N	1774803182	1774803182
4	default	{"uuid":"aacc74eb-8e75-44f5-8095-ed485277a7ed","displayName":"Closure (ContactController.php:18)","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"Illuminate\\\\Queue\\\\CallQueuedClosure","command":"O:34:\\"Illuminate\\\\Queue\\\\CallQueuedClosure\\":1:{s:7:\\"closure\\";O:47:\\"Laravel\\\\SerializableClosure\\\\SerializableClosure\\":1:{s:12:\\"serializable\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Signed\\":2:{s:12:\\"serializable\\";s:22472:\\"O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:5:\\"brevo\\";O:38:\\"App\\\\Services\\\\BrevoTransactionalService\\":1:{s:9:\\"\\u0000*\\u0000client\\";O:11:\\"Brevo\\\\Brevo\\":34:{s:7:\\"account\\";O:27:\\"Brevo\\\\Account\\\\AccountClient\\":2:{s:36:\\"\\u0000Brevo\\\\Account\\\\AccountClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Account\\\\AccountClient\\u0000client\\";O:27:\\"Brevo\\\\Core\\\\Client\\\\RawClient\\":6:{s:35:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000client\\";O:39:\\"Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\":4:{s:47:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000client\\";O:17:\\"GuzzleHttp\\\\Client\\":1:{s:25:\\"\\u0000GuzzleHttp\\\\Client\\u0000config\\";a:8:{s:7:\\"handler\\";O:23:\\"GuzzleHttp\\\\HandlerStack\\":3:{s:32:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000handler\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:35:\\"GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\":7:{s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:50;}s:50:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000selectTimeout\\";i:1;s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000active\\";i:0;s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000handles\\";a:0:{}s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000delays\\";a:0:{}s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000options\\";a:0:{}s:40:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000_mh\\";N;}s:4:\\"sync\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlHandler\\":1:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:3;}}}s:8:\\"function\\";s:285:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $sync): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options[\\\\GuzzleHttp\\\\RequestOptions::SYNCHRONOUS]) ? $default($request, $options) : $sync($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001ff0000000000000000\\";}s:9:\\"streaming\\";O:32:\\"GuzzleHttp\\\\Handler\\\\StreamHandler\\":1:{s:45:\\"\\u0000GuzzleHttp\\\\Handler\\\\StreamHandler\\u0000lastHeaders\\";a:0:{}}}s:8:\\"function\\";s:264:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $streaming): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options['stream']) ? $default($request, $options) : $streaming($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002010000000000000000\\";}s:30:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000stack\\";a:4:{i:0;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:1:{s:14:\\"bodySummarizer\\";N;}s:8:\\"function\\";s:839:\\"static function (callable $handler) use ($bodySummarizer): callable {\\n            return static function ($request, array $options) use ($handler, $bodySummarizer) {\\n                if (empty($options['http_errors'])) {\\n                    return $handler($request, $options);\\n                }\\n\\n                return $handler($request, $options)->then(\\n                    static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($request, $bodySummarizer) {\\n                        $code = $response->getStatusCode();\\n                        if ($code < 400) {\\n                            return $response;\\n                        }\\n                        throw \\\\GuzzleHttp\\\\Exception\\\\RequestException::create($request, $response, null, [], $bodySummarizer);\\n                    }\\n                );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002020000000000000000\\";}i:1;s:11:\\"http_errors\\";}i:1;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:144:\\"static function (callable $handler): \\\\GuzzleHttp\\\\RedirectMiddleware {\\n            return new \\\\GuzzleHttp\\\\RedirectMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002030000000000000000\\";}i:1;s:15:\\"allow_redirects\\";}i:2;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:1030:\\"static function (callable $handler): callable {\\n            return static function ($request, array $options) use ($handler) {\\n                if (empty($options['cookies'])) {\\n                    return $handler($request, $options);\\n                } elseif (!($options['cookies'] instanceof \\\\GuzzleHttp\\\\Cookie\\\\CookieJarInterface)) {\\n                    throw new \\\\InvalidArgumentException('cookies must be an instance of GuzzleHttp\\\\Cookie\\\\CookieJarInterface');\\n                }\\n                $cookieJar = $options['cookies'];\\n                $request = $cookieJar->withCookieHeader($request);\\n\\n                return $handler($request, $options)\\n                    ->then(\\n                        static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($cookieJar, $request): \\\\Psr\\\\Http\\\\Message\\\\ResponseInterface {\\n                            $cookieJar->extractCookies($request, $response);\\n\\n                            return $response;\\n                        }\\n                    );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002040000000000000000\\";}i:1;s:7:\\"cookies\\";}i:3;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:150:\\"static function (callable $handler): \\\\GuzzleHttp\\\\PrepareBodyMiddleware {\\n            return new \\\\GuzzleHttp\\\\PrepareBodyMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002050000000000000000\\";}i:1;s:12:\\"prepare_body\\";}}s:31:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000cached\\";N;}s:15:\\"allow_redirects\\";a:5:{s:3:\\"max\\";i:5;s:9:\\"protocols\\";a:2:{i:0;s:4:\\"http\\";i:1;s:5:\\"https\\";}s:6:\\"strict\\";b:0;s:7:\\"referer\\";b:0;s:15:\\"track_redirects\\";b:0;}s:11:\\"http_errors\\";b:1;s:14:\\"decode_content\\";b:1;s:6:\\"verify\\";b:1;s:7:\\"cookies\\";b:0;s:14:\\"idn_conversion\\";b:0;s:7:\\"headers\\";a:1:{s:10:\\"User-Agent\\";s:12:\\"GuzzleHttp\\/7\\";}}}s:51:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000maxRetries\\";i:2;s:50:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000baseDelay\\";i:1000;s:54:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000sleepFunction\\";s:6:\\"usleep\\";}s:43:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000requestFactory\\";O:27:\\"GuzzleHttp\\\\Psr7\\\\HttpFactory\\":0:{}s:42:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000streamFactory\\";O:27:\\"GuzzleHttp\\\\Psr7\\\\HttpFactory\\":0:{}s:36:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}s:43:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000getAuthHeaders\\";N;s:7:\\"options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}}}s:13:\\"masterAccount\\";O:39:\\"Brevo\\\\MasterAccount\\\\MasterAccountClient\\":2:{s:48:\\"\\u0000Brevo\\\\MasterAccount\\\\MasterAccountClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\MasterAccount\\\\MasterAccountClient\\u0000client\\";r:13;}s:4:\\"user\\";O:21:\\"Brevo\\\\User\\\\UserClient\\":2:{s:30:\\"\\u0000Brevo\\\\User\\\\UserClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:29:\\"\\u0000Brevo\\\\User\\\\UserClient\\u0000client\\";r:13;}s:7:\\"process\\";O:27:\\"Brevo\\\\Process\\\\ProcessClient\\":2:{s:36:\\"\\u0000Brevo\\\\Process\\\\ProcessClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Process\\\\ProcessClient\\u0000client\\";r:13;}s:7:\\"senders\\";O:27:\\"Brevo\\\\Senders\\\\SendersClient\\":2:{s:36:\\"\\u0000Brevo\\\\Senders\\\\SendersClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Senders\\\\SendersClient\\u0000client\\";r:13;}s:7:\\"domains\\";O:27:\\"Brevo\\\\Domains\\\\DomainsClient\\":2:{s:36:\\"\\u0000Brevo\\\\Domains\\\\DomainsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Domains\\\\DomainsClient\\u0000client\\";r:13;}s:8:\\"webhooks\\";O:29:\\"Brevo\\\\Webhooks\\\\WebhooksClient\\":2:{s:38:\\"\\u0000Brevo\\\\Webhooks\\\\WebhooksClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Webhooks\\\\WebhooksClient\\u0000client\\";r:13;}s:13:\\"externalFeeds\\";O:39:\\"Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\":2:{s:48:\\"\\u0000Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\u0000client\\";r:13;}s:13:\\"customObjects\\";O:39:\\"Brevo\\\\CustomObjects\\\\CustomObjectsClient\\":2:{s:48:\\"\\u0000Brevo\\\\CustomObjects\\\\CustomObjectsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\CustomObjects\\\\CustomObjectsClient\\u0000client\\";r:13;}s:8:\\"contacts\\";O:29:\\"Brevo\\\\Contacts\\\\ContactsClient\\":2:{s:38:\\"\\u0000Brevo\\\\Contacts\\\\ContactsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Contacts\\\\ContactsClient\\u0000client\\";r:13;}s:13:\\"conversations\\";O:39:\\"Brevo\\\\Conversations\\\\ConversationsClient\\":2:{s:48:\\"\\u0000Brevo\\\\Conversations\\\\ConversationsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\Conversations\\\\ConversationsClient\\u0000client\\";r:13;}s:9:\\"ecommerce\\";O:31:\\"Brevo\\\\Ecommerce\\\\EcommerceClient\\":2:{s:40:\\"\\u0000Brevo\\\\Ecommerce\\\\EcommerceClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:39:\\"\\u0000Brevo\\\\Ecommerce\\\\EcommerceClient\\u0000client\\";r:13;}s:7:\\"coupons\\";O:27:\\"Brevo\\\\Coupons\\\\CouponsClient\\":2:{s:36:\\"\\u0000Brevo\\\\Coupons\\\\CouponsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Coupons\\\\CouponsClient\\u0000client\\";r:13;}s:8:\\"payments\\";O:29:\\"Brevo\\\\Payments\\\\PaymentsClient\\":2:{s:38:\\"\\u0000Brevo\\\\Payments\\\\PaymentsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Payments\\\\PaymentsClient\\u0000client\\";r:13;}s:5:\\"event\\";O:23:\\"Brevo\\\\Event\\\\EventClient\\":2:{s:32:\\"\\u0000Brevo\\\\Event\\\\EventClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Event\\\\EventClient\\u0000client\\";r:13;}s:14:\\"inboundParsing\\";O:41:\\"Brevo\\\\InboundParsing\\\\InboundParsingClient\\":2:{s:50:\\"\\u0000Brevo\\\\InboundParsing\\\\InboundParsingClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:49:\\"\\u0000Brevo\\\\InboundParsing\\\\InboundParsingClient\\u0000client\\";r:13;}s:7:\\"balance\\";O:27:\\"Brevo\\\\Balance\\\\BalanceClient\\":2:{s:36:\\"\\u0000Brevo\\\\Balance\\\\BalanceClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Balance\\\\BalanceClient\\u0000client\\";r:13;}s:7:\\"program\\";O:27:\\"Brevo\\\\Program\\\\ProgramClient\\":2:{s:36:\\"\\u0000Brevo\\\\Program\\\\ProgramClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Program\\\\ProgramClient\\u0000client\\";r:13;}s:6:\\"reward\\";O:25:\\"Brevo\\\\Reward\\\\RewardClient\\":2:{s:34:\\"\\u0000Brevo\\\\Reward\\\\RewardClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:33:\\"\\u0000Brevo\\\\Reward\\\\RewardClient\\u0000client\\";r:13;}s:4:\\"tier\\";O:21:\\"Brevo\\\\Tier\\\\TierClient\\":2:{s:30:\\"\\u0000Brevo\\\\Tier\\\\TierClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:29:\\"\\u0000Brevo\\\\Tier\\\\TierClient\\u0000client\\";r:13;}s:14:\\"emailCampaigns\\";O:41:\\"Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\":2:{s:50:\\"\\u0000Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:49:\\"\\u0000Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\u0000client\\";r:13;}s:12:\\"smsCampaigns\\";O:37:\\"Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\":2:{s:46:\\"\\u0000Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:45:\\"\\u0000Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\u0000client\\";r:13;}s:17:\\"whatsAppCampaigns\\";O:47:\\"Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\":2:{s:56:\\"\\u0000Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:55:\\"\\u0000Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\u0000client\\";r:13;}s:9:\\"companies\\";O:31:\\"Brevo\\\\Companies\\\\CompaniesClient\\":2:{s:40:\\"\\u0000Brevo\\\\Companies\\\\CompaniesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:39:\\"\\u0000Brevo\\\\Companies\\\\CompaniesClient\\u0000client\\";r:13;}s:5:\\"deals\\";O:23:\\"Brevo\\\\Deals\\\\DealsClient\\":2:{s:32:\\"\\u0000Brevo\\\\Deals\\\\DealsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Deals\\\\DealsClient\\u0000client\\";r:13;}s:5:\\"files\\";O:23:\\"Brevo\\\\Files\\\\FilesClient\\":2:{s:32:\\"\\u0000Brevo\\\\Files\\\\FilesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Files\\\\FilesClient\\u0000client\\";r:13;}s:5:\\"notes\\";O:23:\\"Brevo\\\\Notes\\\\NotesClient\\":2:{s:32:\\"\\u0000Brevo\\\\Notes\\\\NotesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Notes\\\\NotesClient\\u0000client\\";r:13;}s:5:\\"tasks\\";O:23:\\"Brevo\\\\Tasks\\\\TasksClient\\":2:{s:32:\\"\\u0000Brevo\\\\Tasks\\\\TasksClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Tasks\\\\TasksClient\\u0000client\\";r:13;}s:21:\\"transactionalWhatsApp\\";O:55:\\"Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\":2:{s:64:\\"\\u0000Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:63:\\"\\u0000Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\u0000client\\";r:13;}s:19:\\"transactionalEmails\\";O:51:\\"Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\":2:{s:60:\\"\\u0000Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:59:\\"\\u0000Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\u0000client\\";r:13;}s:16:\\"transactionalSms\\";O:45:\\"Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\":2:{s:54:\\"\\u0000Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:53:\\"\\u0000Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\u0000client\\";r:13;}s:12:\\"smsTemplates\\";O:37:\\"Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\":2:{s:46:\\"\\u0000Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:45:\\"\\u0000Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\u0000client\\";r:13;}s:20:\\"\\u0000Brevo\\\\Brevo\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:19:\\"\\u0000Brevo\\\\Brevo\\u0000client\\";r:13;}}s:4:\\"data\\";a:3:{s:4:\\"name\\";s:24:\\"Freddy Pitel & David Fox\\";s:5:\\"email\\";s:16:\\"djwfox@gmail.com\\";s:7:\\"message\\";s:8:\\"Ho there\\";}}s:8:\\"function\\";s:90:\\"function () use ($brevo, $data) {\\n            $brevo->sendContactMessage($data);\\n        }\\";s:5:\\"scope\\";s:38:\\"App\\\\Http\\\\Controllers\\\\ContactController\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001f30000000000000000\\";}\\";s:4:\\"hash\\";s:44:\\"bGVx798lmcrbB5uNKqwgekSIbMnM9D012+3vr3NrsKQ=\\";}}}","batchId":null},"createdAt":1774806096,"delay":null}	0	\N	1774806096	1774806096
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."migrations" ("id", "migration", "batch") FROM stdin;
1	0001_01_01_000000_create_users_table	1
2	0001_01_01_000001_create_cache_table	1
3	0001_01_01_000002_create_jobs_table	1
4	2025_07_01_154723_create_guests_table	1
5	2025_07_01_173029_create_households_table	1
6	2025_12_26_095436_add-to-guests	2
7	2025_12_26_102608_accommodation	2
8	2025_12_26_120051_household_accommodation	2
9	2025_12_26_160339_add-to-guests-orig-name	2
10	2025_12_26_162014_add-to-households-extra-invites	2
11	2025_12_26_163747_add-to-guests-extra-invites	2
12	2025_12_26_215338_create_food_choices	2
13	2026_02_27_175928_add_coach_house_column	3
14	2026_04_04_215429_create_personal_access_tokens_table	4
15	2026_04_04_215748_create_train_configs_table	4
16	2026_04_04_215946_create_train_jokes_table	4
17	2026_04_04_220006_create_train_affirmations_table	4
18	2026_04_04_220012_create_train_events_table	4
19	2026_04_04_220020_create_train_slideshows_table	4
20	2026_04_04_220024_create_train_gifs_table	4
21	2026_04_04_220056_create_train_secrets_table	4
22	2026_08_28_145719_create_train_comments_table	5
23	2026_08_28_150751_add_enabled_column	5
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."password_reset_tokens" ("email", "token", "created_at") FROM stdin;
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."personal_access_tokens" ("id", "tokenable_type", "tokenable_id", "name", "token", "abilities", "last_used_at", "expires_at", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: seating; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."seating" ("id", "table", "position") FROM stdin;
1	1	1
2	1	2
3	1	3
4	1	4
5	1	5
6	1	6
7	1	7
8	1	8
9	1	9
10	1	10
11	1	11
12	1	12
13	2	1
14	2	2
15	2	3
16	2	4
17	2	5
18	2	6
19	2	7
20	2	8
21	2	9
22	2	10
23	2	11
24	2	12
25	3	1
26	3	2
27	3	3
28	3	4
29	3	5
30	3	6
31	3	7
32	3	8
33	3	9
34	3	10
35	3	11
36	3	12
37	4	1
38	4	2
39	4	3
40	4	4
41	4	5
42	4	6
43	4	7
44	4	8
45	4	9
46	4	10
47	4	11
48	4	12
49	5	1
50	5	2
51	5	3
52	5	4
53	5	5
54	5	6
55	5	7
56	5	8
57	5	9
58	5	10
59	5	11
60	5	12
61	6	1
62	6	2
63	6	3
64	6	4
65	6	5
66	6	6
67	6	7
68	6	8
69	6	9
70	6	10
71	6	11
72	6	12
73	7	1
74	7	2
75	7	3
76	7	4
77	7	5
78	7	6
79	7	7
80	7	8
81	7	9
82	7	10
83	7	11
84	7	12
85	8	1
86	8	2
87	8	3
88	8	4
89	8	5
90	8	6
91	8	7
92	8	8
93	8	9
94	8	10
95	8	11
96	8	12
97	9	1
98	9	2
99	9	3
100	9	4
101	9	5
102	9	6
103	9	7
104	9	8
105	9	9
106	9	10
107	9	11
108	9	12
109	10	1
110	10	2
111	10	3
112	10	4
113	10	5
114	10	6
115	10	7
116	10	8
117	10	9
118	10	10
119	10	11
120	10	12
121	11	1
122	11	2
123	11	3
124	11	4
125	11	5
126	11	6
127	11	7
128	11	8
129	11	9
130	11	10
131	11	11
132	11	12
133	12	1
134	12	2
135	12	3
136	12	4
137	12	5
138	12	6
139	12	7
140	12	8
141	12	9
142	12	10
143	12	11
144	12	12
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."sessions" ("id", "user_id", "ip_address", "user_agent", "payload", "last_activity") FROM stdin;
QwSOp48vDUrCnB12BFYHj3x8qQpJCngLuQSzI6I9	\N	185.12.59.118	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ3RIcXNXSVBIT2JjVnNaRUlTTE9WYk1CaEhTVjNiZlZLc3AwbnpHbyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788279718
Wh61eViZlug0bhjaor1TijD8KUpEc6d3FaPbfWGs	\N	172.235.41.203	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoid3RHbVlzaTlTdjlTaWlOTldsOHNJMU51ZlRiYmFkWnc0dDhIS2RXdiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788248799
hAEw2BYUDc4XqNVJyjmcB5P9HNPFDYvIjleq7CJv	\N	146.75.168.60	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6.1 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiU0dnVElhd2VpMWlDcTFzdks2Z1BGcWRIaDVhTUNFM2s1ejZSTlVzQSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788299736
N8KwHNb3EKAyuyWjEaBrFL0vR7peTEn3SAk7vJ9s	\N	208.127.194.118	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiejBxNUp3TWxOd2oyMHhFUlFtdkVtaUxWaGtkQ2d1Z1VDZ2ZtRm16QyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6ImhvdXNlaG9sZCI7czo0OiJSWEVNIjt9	1788275279
OvadsZh6PDzF6a3tXDMBxlgOpXPAPcBe78s4syhf	\N	151.245.151.89	Mozilla/5.0 (compatible; ForestEngine/1.0; +https://forestengine.net/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoicHJKaVI1azQwYUVWOHdBWTB4UFlPdjZ4ZWhzUHVsbUJHWWJVODR6aSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788283883
X31UQaqT7XicqUmdmpdEwvavQTUNPMUsIGdNFlzH	\N	172.235.41.245	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiU3lDd0UxZmxheG85UzdaY1ZjQzNTeGRja01ZV2MwSnhFVExjbzltMiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788253606
oEeuLMAVRvFosRZwiuyioibyFiODm1MBxFHZkahd	\N	152.32.233.36	Mozilla/5.0 (X11; Linux x86_64; rv:1.9.5.20) Gecko/ Firefox/3.6.12	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQkRJNUVSWEpVQnhxTXdGc3pQekJhaEFoVllMa3RWODlkUkd5V1ZlSCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788275933
kx7dRXopDleCP3GzphqdsPrUwN7qR2grw5KzDeS8	\N	43.154.127.188	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoidFp6cXZEbTJva3ZMRWFvTGFIaEhXS0twcWZmdGZJS1UzNFRsZUNrTCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788301559
ksxwJmPapjhHB8VcHKsslCUQZyVvRbqVTHdbpUI2	\N	17.166.153.220	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15 (Applebot/0.1; +http://www.apple.com/go/applebot)	YTozOntzOjY6Il90b2tlbiI7czo0MDoidHUxdEtmWVJlT2JlMVNSb2VUTWtCRkt3eDFHdXVpSXJkVFFFdGJVeiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS90aW1lbGluZSI7czo1OiJyb3V0ZSI7czo4OiJ0aW1lbGluZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1788301600
0Qb4HPR2XZNbyKiInuBpCu72j4OeZClkhdhkxJnV	\N	129.154.239.50	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSEZRd2hPbWJkVWs1dGFVMTZJYW9zZXlIdGVWSlNuTFN0eXlnOXpsWCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788284296
h0GZVmGycw67h5xjA3boQKfgGi4f39CfT3ghvI0V	\N	217.160.202.182	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36 Edg/91.0.864.54	YTozOntzOjY6Il90b2tlbiI7czo0MDoicEQySWtLQnlWNHdZU29sc0ZNYlRqVjZXVk9ieWIydnFPeTJwdmdMciI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788255519
JZ6n2p6DYtmNmDoQWF1fE7edgAE1dcOhUpOtGMA2	\N	165.154.173.204	curl/7.29.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoicUFEMDZRbHZDSGpqc1czRmRZNlZpOHFRdzRRdjVkVzFIUXQ1YlZnbyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788276160
vxnNn4SoJuvQjEGLqAIVYAQE3UiW2AzNFtaWbhDy	\N	172.236.228.218	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoibjUxNmFnMU9XQWhodm1sQmViaEYxRGxhMnBVSnVSd3JmVmdld1dBTCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788302570
TWTe0GzuJ5gDFvYTLidl3ttmS0jmc5zKmmBR9Lc0	\N	172.236.239.55	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoieXA4b1FvOGNabmRJQzYwdkV4MHJESW9idTFMeGpkVU8wdWFjUkNTdiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788285106
V0xsXliyREYYn4qeX6AqgJBNQSUKXAlewDt3wVrB	\N	45.79.181.104	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUXRRVkt5QVFCVGNOVHlBMzdueURPcVp2b0JZOUltOGw0dElIOEVvTCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788255732
uNx6Mhl65PmHofmtEQzIox70yEO9pMeojspVFSrG	\N	86.185.169.154	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZjFOZGZQNVNLS1BIbHFES2dpNlhjcEYydUE3clRoOWc4WE9lY2J6SSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788255732
FzPMYfKKKxUbP5HopcQAurMvFvmhnrObpyRZ6Kwv	\N	170.106.37.134	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQUJtdXp3Yjc2ZzhyZ3dXQTFreUd2T2JETzk3eEllcm1yVTNrdDQzVyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788277011
nW1Ky5IE5esm9ESdWM0ghpyTBDjkQNHkOyk69YKw	\N	172.105.128.13	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVFJHZjdyMVkxMEVON2tqaUt5OFdoRG5UeTJobEJpV09rbTZsVTBqeSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788305955
GnmRiND3mhsIgVC6YKzJXY9zNgK2kI5xA0iYdSG3	\N	86.185.169.154	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMjd1Qlk0enBOTEphSE43cGFhZ3NkaEpoUk5DNlEwVVFVSTI0OFRpdSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788286521
qZvnz9PjTvTjNfuHByTfAuacwCeOhLBzFfpKr3v8	\N	34.80.64.10	crusader-worker/1.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiV2lLU1JWdTNMVVVHQUhPRHBXS0dnTmxsc1ByWUNJY3JweWhIaVdGSyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788257004
ec1UzGLGlkX1ppo87AXX2I1Sj7alATkGb9ZdsiWz	\N	84.32.32.40	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoidGkzTWxaYUx0MTBIdWczOFpxU1I0YjJiQUpYRGVEVnVGZWdtWkFLdCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788277411
ZdLQ4kcTWqYfPeKw9mSFsIvVBVCNISRMu2xqlIeO	\N	45.156.129.132	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.6312.86 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ2U5ODR3bDk0S3lvSWJIMUk1bzhFdUc0aWhCcDF4UEtHNTAwQUMyeCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788308260
TWUmfokAw5ndX8Q6o4wMM8YPiObeJrU7bREMmhYm	\N	86.185.169.154	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_1) AppleWebKit/601.2.4 (KHTML, like Gecko) Version/9.0.1 Safari/601.2.4 facebookexternalhit/1.1 Facebot Twitterbot/1.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVEhnMEc0NFl4YVpUdExyZWpZdmlTRGZPNnhUSVFYNUdhUkE2N2lCSCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788286521
nXw1NdWQFwUfnVaDiNKt0FeRRBKbmXnNSApEmiy0	\N	103.168.95.200	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTVlTYnZ4WHQyS0VzUFhmcFB2Y0VpSklBN3hlcWlXOGk3NEVjZWh6RSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788258655
wxNzK6DvzGQIx9qthbnHthrPp6FjzoVCcF2jAL6c	\N	103.168.95.200	Python/3.14 aiohttp/3.13.5	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVlVzZnBvNVB3eFFDRGRuZzBURGlpb3A5MmdXUGNIVUpDVXhHc0hEMiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788258656
a2Z41NSGl3Fj41pODZdDFZWpHkRVCGBLa8ZoRaPS	\N	20.168.120.124	Mozilla/5.0 zgrab/0.x	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMlllZ3RpSnVjMGoyeTdaa2NOeUhMVlRhSUkzUUNIS2xOZ0FWTnpiNyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1788277987
CRu1muuaHWoWJ32qmIngzmb2ZsFJV74qXO1UsQyn	\N	31.94.72.203	Mozilla/5.0 (iPhone; CPU iPhone OS 26_6_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/435.4.965413651 Mobile/15E148 Safari/604.1	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiZmhucUVxREJTc25pRDhHaGV6MU5zUkhzUjRXVWpkcUlpR2VyZ3J5dyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6ImhvdXNlaG9sZCI7czo0OiJTT0ZGIjt9	1788286626
3tnzAAjHb2iUoCqYzzofTkJ1wON8RyN4Vn9cd8Vr	\N	62.60.130.223	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVTl2Qkl3eHJJaDJpaHlpdERGTW5nQmdBUEtXSmx1RHpkUTd5elpSUSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788309104
U1LXTNAEa6BqtFWg1hfT4cNlnR7x47K5EFUcpXCu	\N	106.54.62.156	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZWFWUVNLR25DcHFQNUVwQkZhMGpzZDNJaUx4NWl5TVJPWDhKYzJoZyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788286791
mGX8OYiMz5DJYuvHe0R3gVbXuvCnyyptZ7nQV1tH	\N	40.77.167.24	Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm) Chrome/116.0.1938.76 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoieXZoM09tb3FmQVYwZzZ6Y0M3dUpXS0hHQmFYNXJNS1dhMWswUm9JMCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3JzdnAiO3M6NToicm91dGUiO3M6OToicnN2cC5sb2NrIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788258846
6KjGimfsNO4gK6FSbuSXs341pXFi1B1DIiUDgvo6	\N	49.128.218.15		YTozOntzOjY6Il90b2tlbiI7czo0MDoidVJqRXhhMGtveU9Pd3NtSlUwMlUwTDhuZ3NJNmtmbHlCcmpEaWVFMiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788278418
r4BIUtI69BsTtcHTfEfTtsIn7z61yOSkFIol7jeM	\N	94.154.43.84	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOHE1aGhTbEtkSk95WmJkdURpQkF4ZXVjaWVBb1BYcEVGM0gwanExdiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788309955
ItDW5jG16AQKQEptXGiroD3K7Feyi7hsV8H3tBSj	\N	69.165.75.192	libredtail-http	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMGxaMGhNNXc2NXJaeE9lVEx3VHI1OEVmclNScHR0VU5UNTdycVVoViI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTQ3OiJodHRwczovLzE3OC42Mi44Ny4yMTkvaW5kZXgucGhwP2Z1bmN0aW9uPWNhbGxfdXNlcl9mdW5jX2FycmF5JnM9JTJGaW5kZXglMkYlNUN0aGluayU1Q2FwcCUyRmludm9rZWZ1bmN0aW9uJnZhcnMlNUIwJTVEPW1kNSZ2YXJzJTVCMSU1RCU1QjAlNUQ9SGVsbG8iO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1788287173
jpxXbRb7VIz8ksMuxnbU98eMgy2RiVSCk5RigpEx	\N	172.234.217.129	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMkxCd3lnSVhTb2tjY1ZXYmRqV0JkTXFFOWNOOFR2NzU3M1dNMXZZbiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788259289
dWkIarmjfGO3K8ZIh7ibF996onYeRl4oaZvxm1CJ	\N	193.8.186.31	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQkN3SDIxc001MElMVXo1VnU0TUlzVE5yQXdQeGM1dFdteHppa2EzWCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788278928
HuM1CNNvQHiuJOuJlfFITALPuOR0bo0U8TE8bXFq	\N	93.152.221.147	Mozilla/5.0 (compatible; osint-scanner/1.0; +research)	YTozOntzOjY6Il90b2tlbiI7czo0MDoibE0yNmxoV1RQVUJVOVFEQ1lNZXpBcVlXZnQwNDNNTVNMWEI2NHlseSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788278929
EaHlUOYimk2e8xscuG0bbPatIJBL6N7lDqMk95Hi	\N	43.135.182.43	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSWlobEtabTdIUzVZNUdBWkExc21KZEkydnJvVEdLQU5BMndjeTBWcCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3RpbWVsaW5lIjtzOjU6InJvdXRlIjtzOjg6InRpbWVsaW5lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788287212
qJ0hbUl4zj4cFjBsm7X6D9PGmRIlh5rEPXroe0nr	\N	85.217.149.8	Mozilla/5.0 (compatible; ModatScanner/1.2; +https://modat.io/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiU3F5ZFY1Tkh5NkYxU0hub3g5b3M1YTBJTkdMbGpIT24zc28xb3p3eCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788310815
9eSgOHcyqo8s1DP6UPTCfGzoD5dsvXwm83X9TdfU	\N	92.40.168.234	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiNExrNWY4aFAyRk5vcWNyRE04T2l4Ykp4aVV6amdrTkNEUWliNjluSyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6ImhvdXNlaG9sZCI7czo0OiJNTllTIjt9	1788279818
GDiuFjj2Fw63ZfNBiox4l2VZW0ZylOMs4JpUSelR	\N	94.231.206.105	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:134.0) Gecko/20100101 Firefox/134.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNXNzY3l0aDlHM091VEFuSFFkeHN2SXNFNE0wSFpLMzJNbUU0bGxYRSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788261802
H34ghBJGp8ej0gY03daDNuNSKaUcfAGgCIQzwDB7	\N	43.164.1.211	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoic09oZUtIYXNKcnV6Rlk2OUZTZzFZMG96Rjh2eDV6YVFKVmMzeFFsQSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788288322
2OGzObTdfqAMVT06vqRGTY8xFUFhMTmIBWLBI6L4	\N	74.125.208.65	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiY0JLOFZJeXpveVZ6MEVOenFMcmd5RDkxakZYeUpCa3FtVG44aGh3aCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788279064
qkGhDAnSFcxMB4xy4UnlfQLXgmdTEyTNKoQuv284	\N	74.125.215.192	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943)	YTozOntzOjY6Il90b2tlbiI7czo0MDoielppUXJJdlR0c25WTDBGdTdpSEo4YVZVTDdnRmpiNzFUVXVaUFp1YyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788279064
m3HS1fi3qTSKGkjf6nKuS6Fjkh5JNNfl9Af7V5xK	\N	45.79.181.223	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVHVUNkRWWm9JMGRjS0VyYWdnUVp0ZmxyWW1wQXM5ZzR6SnJJYzdRYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788314144
1PsDRrvvYUqFTH0vqlaQKT0H6rftImuA5xZe4VOe	\N	172.104.11.51	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUm4xOFEwNmlleW1PTjN0aFkwOUJxSTgySFNEbHJyRFVDM3B4ejVXQiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788288801
zlxmx7vlh4YKqujC4ipmNOfg3MDjrgDLah3o9ZT4	\N	43.153.76.247	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoieDF1c1Z4M1dZSlV2V0RSaFc0MEMyNzhYbVZiUVBhSXdXV0N2bzZ1byI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788262088
bHPu51VuXDBli8RxW4TNSFGD09c0OOnbACpa7AWs	\N	185.177.72.9	curl/8.7.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSlRvSmIyVFFCTUh0Q2Y3VE9nZnF6SDRVRFJNdDdaMmxPVzV5dFJ2QSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788289757
nT53AXhwaZlQTnX45ZGo0F3UdKlcnfbqqA0u9jhb	\N	172.104.11.34	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSEFsVDhaeW4xVzRKU2kzVlJRTmxEOG5wYlN3eW9iRGc5RmE2a2JhTCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788264057
yojlpHtD4AmDuft2ObGcGjXEB4JjkS1HRk1OVs7C	\N	185.177.72.9	curl/8.7.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiM2pFVlQzSkRhUnRET25FNk5nNm1iVVNJUk9zTFRsNnJ4QmNrNVVtbCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9wPWluZm8iO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1788289767
yyGYlWTrFHKBFQ8FRqQmX81bFKXOChR6bYI8G8sr	\N	185.177.72.9	curl/8.7.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiY3UwOG1XNkx2WW90TFRNTXRxeEpvbjZUaW5VcGZxbGt1SG1jRDZ2ViI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9wPXBocCI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788289768
yj9EMgHmHBVbcwYgY1FOfMQ39GRFj5bqAWWYcHOK	\N	185.177.72.9	curl/8.7.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMkFoR0hPS0JkdjRCejRPS2Y1b3pvYTd5S3J5TmhmTjgwcER6UHR1cSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9waHBpbmZvPSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788289768
Krgymo54G0tGZIGaTGoQZurZCbKHRNUIwB9KnSg7	\N	185.177.72.9	curl/8.7.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTDg5d2tXNmh2UGdrMVh2TnpmbWhsZHBjUzVuQmtVeW9zSHYxak5xNiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDA6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9waHBpbmZvLnBocD0iO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1788289768
K1RLmkuF2FDD43Ae3ymq1oHlfw181vAybmU9Fscu	\N	185.177.72.9	curl/8.7.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoidUxENTk1VUZBaUJNeUlPNE5CRWYwb0RabXZMSVpST1VNbzZ6RUZzcSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzc6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9waHBpbmZvPTEiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1788289769
sMso4FtokGI0BES6LBnPBuiI7lKOBgbd1MWtmNx7	\N	185.177.72.9	curl/8.7.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoibHRzV1JqY2ppcDZEeE1rSnpBaWU4ZlQ3cFBvOW1Sem96Q3JIWE9kSCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9xPWluZm8iO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1788289769
lFaQp7nFPLbeKqSZYBPH3I8jQC6IgO2nn7wwEe9F	\N	185.177.72.9	curl/8.7.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVWFzQXNleTJDWnNldG0xZ0UzWEEyZUgwMXMzUW9USnJVc3ZxbFMweCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzg6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL2luZGV4JTJlcGhwIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788289782
W1gpEMaMVvv0XmzWk87iMJ3JpTOfsLHrr84j8zIi	\N	185.177.72.9	curl/8.7.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZlhZRmZNU3VnclpKR1NiblZVc0k4MUNoY0VkZUJJczdMaDV4RDFvTCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzI6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL2xvZ2luIjtzOjU6InJvdXRlIjtzOjU6ImxvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788289785
6klcWueI7WbkFYBoCBToZWudwYmZvXKWLckgqAlg	\N	185.177.72.9	curl/8.7.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUUdUNkt5amN6eXZaSWZ6UnhkUWl6cmVYc3QzOWEzNWo4dGY0ajQ5QSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzI6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL2xvZ2luIjtzOjU6InJvdXRlIjtzOjU6ImxvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788289833
sW31fKCXHGWT1JAC0QdjQR0vqSlaW4wEctPKbAXX	\N	185.177.72.9	curl/8.7.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRHNiU0drQVVPNlJxTzFTNVMwZ1JnbTR5bFEzTTVqQ3dPM2JaaExmSCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3JlZ2lzdGVyIjtzOjU6InJvdXRlIjtzOjg6InJlZ2lzdGVyIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788289833
Pus8CIXXXPYeIpG6vhtxOHKpxNTXsn3ZcePyZfi9	\N	185.177.72.9	curl/8.7.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUERUUzRtcUEybzVTWDhEakZhbVJySzdFSER6dGZtUnJqdHFKNDhQayI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9wcD1lbnYiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1788289837
ydHsvshhh5hhkmMcRPiryvTEP01yFcO5EpnGW0J7	\N	185.177.72.9	curl/8.7.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoieGM2OWk0Z1dLbGhYa05pUXBlNTVOVlRpa3lxcVF5Ylo4N0U2UVZRcCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzk6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL2xvZ2luP3BwPWVudiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1788289843
uCa3t9CYhGOTMo86gS2lJB2o4ycnrHbykNvwXeBr	\N	3.131.220.121	visionheight.com/scan Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/126.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSFFIeEJJNmlQR1RnaGxHYkNOSXIyNUViZzhZNjVlN1BMSFlrNm83QyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788264340
j2K5WKbQYuTZzIcE99MbI27a8auL36D5ZOZGTsRz	\N	86.157.233.237	Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:154.0) Gecko/20100101 Firefox/154.0	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiNE1TUXFDY1lrS1cyajFBcXpBeW9hZXRSZ204VjJnRzFNWUhpd0JOTyI7czo5OiJob3VzZWhvbGQiO3M6NDoiT0RGRSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788290161
CTxUmFwGzBXo8jge08OvKfkmAZSUGsYchdxp2wm4	\N	104.28.40.139	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6.1 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSlA5TDNUaEdMdjRVVGxtMlZmcUlrZlhrcENvMlBpY05BdlE2SnpaZyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788290171
r6VbKBxZ5skANKH7uQllv8s98ELMtwnbnfeF8yO4	\N	66.240.223.214	Mozilla/5.0 zgrab/0.x	YTozOntzOjY6Il90b2tlbiI7czo0MDoiS09YODJnTUV5cEpHVGtua2xhOTJQVFpOYmd2WmV4WU5tSUgyTEtTVyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788290676
l2B9uJNY4ZfFvP5boy6VYcYCkoVYeU4YVOz1wlPj	\N	208.127.194.118	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	YTo0OntzOjY6Il90b2tlbiI7czo0MDoicTJ1YWg3UzlmNGMyYTFHMll4NVpJUXJ1T0xjVVpTQVoxQzlPYW1lciI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6ImhvdXNlaG9sZCI7czo0OiJSWEVNIjt9	1788265988
ab5DHMlw707qVEEpyXrwvDQ0FC4DcGEVFxvtt2wZ	\N	66.228.53.78	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOVUzVVVlZDZHOVdueWF1SzVZVU9FR2VyRTAxVWVLQkR5bTR3WVZPMCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788291977
8OpH95tU7NGKQfxP2K0NpPQlunHEmeHeS2Sjvzue	\N	45.148.10.238	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOUFwMjhkUDB0akFHb0ZhV3FJOVdhTHI0eEpacWdxYjcwTTA1NXVEeSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788265873
1aHO6LkiI0BDrAwAzWfXsqc8HN1PxHNvV3RmML9Q	\N	45.148.10.238	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWnFJQjNCamNkcVV4UEhZYTlqdmhpUG1ZYWtGYzVud0k1ejhmdEVkRiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788265898
LGUISvE83IpAVT4NIAY77il9f96PycffYb5s9htw	\N	45.148.10.238	Mozilla/5.0 (iPhone; CPU iPhone OS 18_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.2 Mobile/15E148 Safari/605.1.15	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMnVkU2VWSGpwTXhOczZLM2pZNFJGTFppMmRPMjVmQmZuZkhpZWZoUSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mzg6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9wcD1waHBpbmZvIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788265899
PcLNce4aKtw1Q8pisGk2jYF0lHOPQAWCA69HFmpV	\N	45.148.10.238	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoibWo3SVU3TXJ6cWZxRmdpR1U4NnVjT2RzUHhxamFYbWlneFozQkRldCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzQ6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9wcD1lbnYiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1788265926
QBhUa1UByHHYsXiTeQ2ijjg3RjTRbJUrE30kug3j	\N	193.8.186.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTEJqTmUzWnVBVzhDMHlPbjV5UVN3dTlidzVUZzM2NHk0Vko1UWViZSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788293611
QkDHGGu2Ca6HQuxZZGQEp7A8wgVF9zkK53hupczR	\N	51.254.49.108	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:134.0) Gecko/20100101 Firefox/134.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNTNzT2VJcEt2S3p4dXFobTBRUTJSeU9wM09hbnEycDVyUjlEREdZMyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788266615
M9SFw4CJmhdaOGN3B9pwQBsHQlk7Z6KfkXIy7hj9	\N	45.132.195.66	Mozilla/5.0 (X11; Linux x86_64; WanscannerBot/1.2; +https://abuse.pend.re) Gecko/20100101 Firefox/10.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiT0c3UmdyR1hoM2dIbkV4a3E2VXlBWDNNeERlc00yU0l1SVVBVjkwRSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788294091
mLP8JlqixW5R2J9lYRIAoRD4r68BDzaUOf2OxtHw	\N	172.239.64.84	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSzkwOFlta243bjFMZDJhSE1yeFRrUUl1RThJMDBsZVVlMVhFWDRNUyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788267553
DMICQhv38g7LDqY2ndqgLCCa1GCksbw83TaEqO9I	\N	45.91.64.8	fasthttp	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSU9SNTd4d201Mk1ib2hMc25zdlhQZTVWSk1KaXhtSG9RMDZzYUdtQiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788294328
eipeCEtoBKILQtxaf4C6MePj8uOT4FZB5Q4C08D3	\N	45.91.64.8	fasthttp	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZHZvNk5yUXZVWnZoZ3dNbDcwRGE4d1pmZHJpRUtRcXFJUDd0aHBHbCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788294328
uzNM0Bbq0k06HcQEqMBY4PXtouOXRdkqB7jTRuqu	\N	109.172.8.83		YTozOntzOjY6Il90b2tlbiI7czo0MDoiU0E3YnFWbjRhMnRFNkxzVHg1bzh6dVZMSHVKUzc3VW45YmVYaDYzMyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788267936
5Hch8ABggfSmOl6UMyQC0sDhyKp9YPvZdvy2emk0	\N	109.172.8.83	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQTN5dm12TU1SNlFwRzdlTTJ1bmxuNXprdEtZa1k1aHc0VnNYbHpFMiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788267940
USP0xr8nrczO5qS1DTjvqGzee6PqcC5hRh2dkcir	\N	45.91.64.8	fasthttp	YTozOntzOjY6Il90b2tlbiI7czo0MDoibmZYNmxRMFBsU1RsWEVyY0hxdWl1aWtHVXRRVGVDTFhPZHp0Qlh2cyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788294329
gb4qQIDURptHLkqXNuKWrRDorYWQtIjfBIdMlBM5	\N	45.91.64.8	fasthttp	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRUhYY1V3eUtJc2RWaFpwWVp5ZElsZm1PUnowVDFQdkVRVWx3dVZHbiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788294329
SHcKP92dEdkYLEOszfh9KQ9wA7zEDKArTGNBO6yp	\N	45.91.64.8	fasthttp	YTozOntzOjY6Il90b2tlbiI7czo0MDoib1Q1SlU5clo0cUg1MjNLUUY2VDRHT3FEc0JCSTBuWXZZOU4zRmd3UyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788294330
ScTkfgsKuXd9rjcQDFsjsnWYfUEpSMBSwIMZ4hEu	\N	152.32.156.136	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiR080YkhqY1hpaGFyZkhUeFNBN2NGb0sxWFZ1NENHZmNJN0ZQQTRxSyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788294441
p0OQOel4Q6uxCDtO9Bo6YyNXg02LFnX6kdeiPlOy	\N	82.36.210.145	Mozilla/5.0 (iPhone; CPU iPhone OS 26_6_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/435.4.965413651 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoidUluRkJlYWp5TnhyMlFKT09BSzRxaFlQdU9rdTI2Qk9ScHkxVTVqWCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788294457
Br4P7RpX0s0jD0md0KJm0PgCMBaxPYGwdBrxR2ga	\N	109.172.8.83	Mozilla/5.0 (Windows NT 10.0; Win64; x64)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiUXQ1TVZaRHd1TG5sS2VKRHIwRXNaeU1RYTJtc2VkbEZMaWRUbmdXRCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788267940
YNRfttScVWUzLsDyLSpeCefWZn83UTEuQrrbBFsQ	\N	159.223.194.104	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoid2d5V2FDOG9ISFpQRzZBek5PUnFyNjIwWmNjYVRkOUszR1o2clZWRiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788294468
PVkhCrUekVtP2hYqEBJNvSmybMCibn2hUdV6Y6r6	\N	91.231.89.39	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:134.0) Gecko/20100101 Firefox/134.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTUNhNnA2bzlLamN5Q21Za0hiUEtsMGxEYU91cUxFTVJQcGxhYW9VRiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788295776
vT6lhgkYN67SvZHPrK4sL5qaFrRRjTa8Ic2XRL4F	\N	109.172.8.83	Mozilla/5.0 (Windows NT 10.0; Win64; x64)	YTozOntzOjY6Il90b2tlbiI7czo0MDoic3Q3Qmt5R1J5eDhlY1dnVzFkbjFWVWJIN0JwWmJmVHBiRTJrTnd2SiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788267940
KldClnCFNfc4m2HJPpyBunqNbbCNJMeTvQ8IlGgw	\N	172.236.228.111	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMnN0d3JvSGd0ZU04N2kxYW9lVzBWQXQ2b2ROSE9QYUlFR0kyOGd6UyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788295863
mBcbGtOCxJG950fQy7KDTcpO7GbUpev38cRyE6Ck	\N	35.255.199.143	libredtail-http	YTozOntzOjY6Il90b2tlbiI7czo0MDoibXZnN0VTeGFiWThTd3NnQmwyRlFFeE1qMWIwMHJMdTNlZ2hIM255UiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MTQ3OiJodHRwczovLzE3OC42Mi44Ny4yMTkvaW5kZXgucGhwP2Z1bmN0aW9uPWNhbGxfdXNlcl9mdW5jX2FycmF5JnM9JTJGaW5kZXglMkYlNUN0aGluayU1Q2FwcCUyRmludm9rZWZ1bmN0aW9uJnZhcnMlNUIwJTVEPW1kNSZ2YXJzJTVCMSU1RCU1QjAlNUQ9SGVsbG8iO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1788296006
15NfsC02I44OZoIoyDfnQ9x0cmNZVsjrhgyNOxGq	\N	172.104.11.46	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ2NURnp2amhBVlNGaWJCc2l3NXhVZ3RVejVWbEpUQTJ4SGt1RlNJZCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788270026
0fzu00N9Qjigd0bgX2kMc9pOcDSHyFvYxb60W1tR	\N	35.255.199.143	libredtail-http	YTozOntzOjY6Il90b2tlbiI7czo0MDoibENvT0JaYzdiQURDS25ITDN2V0k3RjRFME4wMHV5MjVvYTlTTFFpVCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjAwOiJodHRwczovLzE3OC42Mi44Ny4yMTkvaW5kZXgucGhwPyUyRiUzQyUzRmVjaG8lMjhtZDUlMjglMjJoaSUyMiUyOSUyOSUzQiUzRiUzRSUyMCUyRnRtcCUyRmluZGV4MS5waHA9JmNvbmZpZy1jcmVhdGUlMjAlMkY9Jmxhbmc9Li4lMkYuLiUyRi4uJTJGLi4lMkYuLiUyRi4uJTJGLi4lMkYuLiUyRnVzciUyRmxvY2FsJTJGbGliJTJGcGhwJTJGcGVhcmNtZCI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788296007
Q6UAcANI5MBA9Q9TQ6jK44TtZtBf8SFX1mZECMiR	\N	35.255.199.143	libredtail-http	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVnBJU0FwQ251dldnT0Y5WTVqb242S243RlYxeFVXYVUydWVBcFhNQyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6ODk6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS9pbmRleC5waHA/bGFuZz0uLiUyRi4uJTJGLi4lMkYuLiUyRi4uJTJGLi4lMkYuLiUyRi4uJTJGdG1wJTJGaW5kZXgxIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788296008
nvvJYvBOiCyFmeunIex8aKdF0zBGXtgz9sRUBOb3	\N	138.197.20.156	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRHJPM3pIWEJLUVVxN3VNQjNKbDNSclBaNWNWQ1kyZVFVcVdMbWlOcSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788298648
cVfhPK6JJFA9oFlglFeVpc7XobwHrhGlCd7VgiVj	\N	188.166.180.132	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoicXRCb09DNERrT0wxRjR5eHZGanllWW82QXphaTJqQVB6ckwwSnY3YSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788298717
yRFUDSv5bJ2lTVqXqNy9FFMrHfr58AOJ1N7znxY5	\N	172.236.119.165	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSFZiSjR2TzlqZm5Rc2I1ME9mWlQ2a3prS0tPTFgzV1o2QzhGTDhjciI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1788298723
NpeOnTa2nwrYrRaATyx0kpM0Dd8CdbRSk34gNPqg	\N	49.234.192.248	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOVR0VjBrbnM5amw5MGhiSDZvbmgwbjVUUUxSR2NzZFQ1ZThmZDdlWCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788248548
0KcElfs4iFdMEf9QQYVdJQ2kDnZsq9SnfAJnftdo	\N	45.148.10.5	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVGtTRWpLZ2NwZmYwY0lSUERoVjE5VWtkNVM5aTE5SFFDS3Jyc0R6RyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1788273961
\.


--
-- Data for Name: tables; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tables" ("id", "name", "elmore_id") FROM stdin;
8	Star Realms	8
4	Rainbow	1
5	Choir	2
1	Heroes	3
7	Elizabeth	4
9	Number	6
10	Backstage	7
11	DIY	10
2	Train	11
3	Bridge	12
12	Fantasy	5
6	Family	9
\.


--
-- Data for Name: train_affirmations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_affirmations" ("id", "created_at", "updated_at", "message", "enabled") FROM stdin;
1	2026-04-05 15:57:00	2026-04-05 15:57:00	We love you all so much, thank you for celebrating with us today!!	t
2	\N	\N	Thank you all for your wonderful cards, we can't wait to read them!	t
3	\N	\N	A big congratulations to Adam and Shel who are celebrating their 10th wedding anniversary!	t
4	\N	\N	Congratulations to Roman and Julia who are celebrating their 5th anniversary!	t
6	\N	\N	Thank you to all my Ready Singer One friends who've made the journey out from London for us!	t
7	\N	\N	Thank you to all of the Backstage Crew, the most solid group of friends a guy could have!	t
8	\N	\N	Humongous thanks to all those who've travelled from overseas to be here! We have guests from Spain, Germany and Poland!	t
9	\N	\N	A personal thank you to Corinne from David for being in Freddy's corner these past years; your support has meant the world.	t
10	\N	\N	To my Foxguard: You're all incredible and ridiculous and I love you all so much!	t
11	\N	\N	Thank you to all our close friends and family who have helped out so much behind the scenes in preparation for today!	t
12	\N	\N	Thank you to Freddy's mum Helen for growing many of the flowers used today!	t
13	\N	\N	Thank you to all of our wedding party; we're honoured to have you help make our day so special!	t
14	\N	\N	A special thanks to Paul Dunn, who helped make Freddy's engagement ring!	t
17	\N	\N	Thank you Tom and Giada for providing a beautiful backdrop to our engagement! Happy second anniversary!	t
18	\N	\N	Our warmest thanks go out to Helena for making our wedding rings, and for putting up with David at his grumpiest!	t
19	\N	\N	To my wonderful new husband - I love you with all my heart, and I can't wait to share the rest of my life with you. - David	t
20	\N	\N	Thanks to our wonderful Stationmaster Alyssa, who has helped the day flow so smoothly, and who organised David's Fox party!	t
21	\N	\N	Thank you to all our vendors, you've all done a smashing job!	t
22	\N	\N	A massive shout out to Jordan and his band Stroma, who will be playing the ceilidh this evening!	t
5	\N	2026-08-29 15:10:13	Congratulations to Hannah and Kieron who will be celebrating their 10th anniversary next week!	t
15	\N	2026-08-31 11:54:30	Much love goes to Kieron for hand-crafting the engagement ring boxes AND the housing for this train board!	t
16	\N	2026-08-31 11:54:44	The beautiful cake was painstakingly made by Hannah, and it is gluten and dairy-free so everyone can have a slice!	t
\.


--
-- Data for Name: train_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_comments" ("id", "created_at", "updated_at", "message", "enabled") FROM stdin;
5	\N	\N	Cheesecake yeah! - Erika Sojkova	t
7	\N	\N	I tried to follow your spaceship directions and flew into the sun :( - Alyssa Burling	t
44	\N	\N	All looks lovely, looking forward to coming! I have a hat!!! - Debby Fisher	t
45	\N	\N	Looking forward to enjoying the day with you both! - Paul Dunn	t
41	\N	2026-08-31 12:00:11	Please leave off the aubergine jam. Is there a less cheesy alternative to cheesecake for dessert? - Stephen Quinn	f
37	\N	2026-08-31 12:00:31	Dessert, I'll have what Freddy's having :)  Missing a box for "I'm special" - Alex Pritchard	f
35	\N	2026-08-31 12:00:37	Gah, we still haven’t worked out what we’re doing Accommodation wise, sorry! we’ll Make sure to let you know asap. Elliot’s looking forward to it! - Oliver Byford	f
30	\N	2026-08-31 12:00:54	If possible please can we have a highchair - no worries if not possible! - Oliver Nicholson	f
29	\N	2026-08-31 12:02:07	Hi Fred,\r\nApologies for the late reply here.  We were really hoping to make it to Blighty to finally meet you and David in person but a few conflicts with planning the trip arose. - Daniel Calinski	f
28	\N	2026-08-31 12:02:08	More testing - I love you! - David Fox	f
27	\N	2026-08-31 12:02:09	Looking forward to it! :) - Kashish Jaiswal	f
24	\N	2026-08-31 12:02:14	If it's possible to just have strawberries for dessert, that would be my choice. But if too faffy, then just nothing. - John McManus	f
18	\N	2026-08-31 12:09:39	I'm so excited! - Dan Pope	t
25	\N	2026-08-31 12:09:55	Sounds yummy 😋 - SB	t
23	\N	2026-08-31 12:02:26	Congratulations!!! Can't wait. - Nathan Williams	f
22	\N	2026-08-31 12:02:31	Many thanks for the invite, looking forward to it!! - Marianne Baker	f
21	\N	2026-08-31 12:02:36	Apologies. Unless a global lack of jet fuel intervenes, I'm planning to be in the South Pacific. Can I take you out for a celebratory dinner when you're back from the honeymoon? - Edward Sanders	f
20	\N	2026-08-31 12:02:37	Delicious menu, thank you - Helen Pitel	f
19	\N	2026-08-31 12:02:39	Not sure they will have BBQ sauce there, but if they do, will be appreciated :) - Gerry Lovelace	f
26	\N	2026-08-31 12:09:58	Going to be the best wedding with an underground themed wedding invitation I've ever been to 💙 - Daniel Hanvey	t
31	\N	2026-08-31 12:10:03	/* Insert witty comment here. */ - Shaun Zedlewski	t
32	\N	2026-08-31 12:10:06	I also think your invite is excellent, we're both very much looking forward to your big day! - James Lyons	t
33	\N	2026-08-31 12:10:07	Love the website and invite design! - Stephen Briscoe	t
15	\N	2026-08-31 12:02:55	Thanks for the invite and accommodation! - Will Saunders	f
34	\N	2026-08-31 12:10:08	Congratulationssss!! - Nanditha Garge	t
36	\N	2026-08-31 12:10:11	High five (he's learnt it and will insist on it) - Henry Holttum	t
39	\N	2026-08-31 12:10:16	It all looks simply delicious - Sally Pitel	t
38	\N	2026-08-31 12:10:17	I'm so excited!!!! It's going to be a wonderful day. xoxo - Louise O'Young	t
40	\N	2026-08-31 12:10:19	Amazing invitation, amazing website! Can't wait to celebrate the big day with you both 💑 - Evie Fisher	t
42	\N	2026-08-31 12:10:23	This wedding website design is amazing! We love it. And we are both already looking forward to joining you. - Nick Bartley	t
43	\N	2026-08-31 12:10:24	Lots of love from us both XX - Nigel Pitel	t
9	\N	2026-08-31 12:04:50	Yummy yummy yummy I got yummy in my tummy - Ian Ang	t
1	\N	2026-08-31 12:08:38	I am incredibly excited and audibly hungry for this!! Can’t wait xx - Madeline MacLean	t
2	\N	2026-08-31 12:08:50	Looking forward to it. - Ian Barwick	t
3	\N	2026-08-31 12:08:50	So excited!! - Pandora Blair	t
6	\N	2026-08-31 12:08:52	I can't wait! - Todd Francis	t
4	\N	2026-08-31 12:03:48	Your invitation is fantastic! So much love for this! - Alix Lyons	f
8	\N	2026-08-31 12:08:54	I’m so happy for you two. Thank you for inviting me. - Amelia Pritchard	t
10	\N	2026-08-31 12:08:59	Super joyfully yes. Thanks guys 🤗🥳🏳️‍🌈 - Ezra Attwood	t
12	\N	2026-08-31 12:09:05	Happy wedding planning! Nth time is the charm! - Sara Fisher	t
13	\N	2026-08-31 12:09:08	I love the invite and website design - Matthew Burnett	t
14	\N	2026-08-31 12:09:10	Your story on the website was amazing, I’m getting misty eyed already! X - Kirsty Blythe	t
16	\N	2026-08-31 12:09:15	Can't wait to celebrate - Heather Holttum	t
17	\N	2026-08-31 12:09:28	I’d really like to come but mummy and daddy won’t let me. Something about wanting to have a good time! - Harriet Little	t
11	\N	2026-08-31 12:10:37	Wahoo! It's working! - Mark Fisher	f
\.


--
-- Data for Name: train_configs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_configs" ("id", "created_at", "updated_at", "key", "value") FROM stdin;
2	2026-08-28 22:06:02	2026-08-28 22:06:06	secretEnabled	1
1	\N	2026-08-29 15:15:40	importantMessage	I love you
3	2026-08-28 22:06:36	2026-08-29 15:19:35	mode	all_screens
\.


--
-- Data for Name: train_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_events" ("id", "created_at", "updated_at", "destination", "description", "scheduled_time", "estimated_time", "enabled") FROM stdin;
1	2026-04-05 15:57:00	2026-04-05 15:57:00	The Ceremony	Please gather on the East Lawn and find your seats!	2026-09-05 13:30:00	2026-09-05 13:30:00	t
2	2026-04-05 15:57:00	2026-04-05 15:57:00	Drinks Reception	Enjoy a glass of bubbly and a canape (or ten!)	2026-09-05 14:15:00	2026-09-05 14:15:00	t
3	2026-04-05 15:57:00	2026-04-05 15:57:00	Confetti Throw	Grab a handful and get ready to throw!	2026-09-05 14:00:00	2026-09-05 14:00:00	t
15	\N	\N	David's Family Photos	Now calling: Marcus	2026-09-05 15:10:00	2026-09-05 15:10:00	t
16	\N	\N	Freddy's Groomsmen Photos	Now calling: Quinn, Ian, Adam, Alex	2026-09-05 15:15:00	2026-09-05 15:15:00	t
17	\N	\N	David's Foxguard Photos	Now calling: Jon, Mark, Alyssa, Hannah	2026-09-05 15:20:00	2026-09-05 15:20:00	t
18	\N	\N	The Wedding Party Photos	Now calling: Jon, Mark, Alyssa, Hannah, Quinn, Ian, Adam, Alex	2026-09-05 15:25:00	2026-09-05 15:25:00	t
19	\N	\N	Wedding Party and Partners Photos	Now calling: Jon, Mark, Alyssa, Hannah, Quinn, Ian, Adam, Alex, Helena, Sara, Leah, Kieron, Libby, Shreya, Stacey, Rowan, Maggie, Artie, Rae-Rae	2026-09-05 15:30:00	2026-09-05 15:30:00	t
8	\N	\N	Full Group Photo	Gather for a full group photo!	2026-09-05 14:10:00	2026-09-05 14:10:00	t
20	\N	\N	Wedding Breakfast - Starter	Now serving: Spring vegetable & goats cheese tart and dressed leaves; hot smoked salmon fillet, curried fried rice, sesame yoghurt, aubergine jam	2026-09-05 16:15:00	2026-09-05 16:15:00	t
21	\N	\N	Wedding Breakfast	Please head into the Gillyflower and take your seat (if you can find it)!	2026-09-05 15:45:00	2026-09-05 15:45:00	t
22	\N	\N	Wedding Breakfast - Main Course	Now serving: Roast Hereford beef rump; Root vegetable and lentil loaf; all served with roast potatoes, leek gratin, seasonal vegetables, Yorkshire pudding, gravy and condiments.	2026-09-05 16:45:00	2026-09-05 16:45:00	t
4	2026-04-05 15:57:00	2026-04-05 15:57:00	Ready Singer One Photos	Now calling: Liz, Jamie, Ian, Kirsty, Mia, Sam, Gerry, Lawrence, Anthony, Rachel, Dan, Marianne, Nathan, Lucy, Louise, Jordan, Reuben, Madeline	2026-09-05 14:20:00	2026-09-05 14:20:00	t
27	\N	\N	Wedding Breakfast - Dessert	Now serving: Baked vanilla cheesecake, poached strawberries; Triple chocolate brownie; Teas and Coffees	2026-09-05 18:30:00	2026-09-05 18:30:00	t
28	\N	\N	Table Clearing	Some of the tables will be removed to make way for the ceilidh! Please feel free to head outside.	2026-09-05 18:45:00	2026-09-05 18:45:00	t
29	\N	\N	Cutting of the Cake	Please gather in the Gillyflower for the cutting of the cake!	2026-09-05 19:15:00	2026-09-05 19:15:00	t
30	\N	\N	The Ceilidh	Join us on the dancefloor to dance a ceilidh! Remember to slip on your dancing shoes!	2026-09-05 19:30:00	2026-09-05 19:30:00	t
31	\N	\N	Evening Food	Now serving: Tacos!	2026-09-05 20:30:00	2026-09-05 20:30:00	t
32	\N	\N	The Ceilidh	Join us for round 2 of the ceilidh!	2026-09-05 21:30:00	2026-09-05 21:30:00	t
33	\N	\N	Evening Dancing	DJ Spotify until the evening ends!	2026-09-05 22:30:00	2026-09-05 22:30:00	t
34	\N	\N	End of the Line	The Gillyflower shuts at midnight. Guests are welcome to relocate to the Drawing Room.	2026-09-06 00:00:00	2026-09-06 00:00:00	t
5	2026-04-05 15:57:00	2026-04-05 15:57:00	Backstage Photos	Now calling: Alyssa, Mark, Jon, Hannah	2026-09-05 14:25:00	2026-09-05 14:25:00	t
35	\N	\N	Morning Breakfast	Breakfast will be served in the Morning Room.	2026-09-06 08:00:00	2026-09-06 08:00:00	t
6	2026-04-05 15:57:00	2026-04-05 15:57:00	Archway Photos	Now calling: Adam, Stacey, Martin, Amy, Theo, Craig, Sam	2026-09-05 14:30:00	2026-09-05 14:30:00	t
36	\N	\N	Checkout	Please checkout of your rooms at 10am at the latest!	2026-09-06 10:00:00	2026-09-06 10:00:00	t
7	2026-04-05 15:57:00	2026-04-05 15:57:00	Extended Moomin's Crew Photos	Now calling: Jon, Helena, Mark, Sara, Alyssa, Leah, Katie, Alexei, Ian, Ellie, Luca, Enzo, Tom, Giada, Richie, Helen, Oliver, Debby	2026-09-05 14:35:00	2026-09-05 14:35:00	t
9	\N	\N	Moomin's Crew Photos	Now calling: Jon, Mark, Alyssa, Katie, Ian	2026-09-05 14:40:00	2026-09-05 14:40:00	t
10	\N	\N	Freddy's Parents Photos	Now calling: Helen, Nigel	2026-09-05 14:45:00	2026-09-05 14:45:00	t
11	\N	\N	Freddy's Parent's and Dunn Photos	Now calling: Helen, Nigel, Janet, Paul	2026-09-05 14:50:00	2026-09-05 14:50:00	t
12	\N	\N	Freddy's Core Family Photos	Now calling: Helen, Nigel, Bea, Dermot, Laura, John, Maggie, Rowan, Sally	2026-09-05 14:55:00	2026-09-05 14:55:00	t
13	\N	\N	Freddy's Full Family Photos	Now calling: Helen, Nigel, Bea, Dermot, Laura, John, Maggie, Rowan, Charlie, Evie, Katie, Tom, Sinead, Sally	2026-09-05 15:00:00	2026-09-05 15:00:00	t
14	\N	\N	Freddy and Cousins Photos	Now calling: Laura, Bea, Charlie, Evie, Katie, Tom, Sally	2026-09-05 15:05:00	2026-09-05 15:05:00	t
37	\N	\N	Leave the Venue	Please depart from the venue.	2026-09-06 10:20:00	2026-09-06 10:20:00	t
38	\N	\N	Leave	Seriously, hurry up and leave.	2026-09-06 10:25:00	2026-09-06 10:25:00	t
25	\N	2026-08-28 22:02:53	Speech #3	Now speaking: Alyssa Burling	2026-09-05 18:00:00	2026-09-05 18:00:00	t
39	\N	2026-08-29 14:23:34	Get Out	GET OUT. GET OUT. GET OUT. GET OUT. GET OUT. GET OUT. GET OUT. GET OUT. GET OUT. GET OUT. GET OUT. GET OUT.	2026-09-06 10:30:00	2026-09-06 10:30:00	t
24	\N	2026-08-29 14:24:52	Speech #2	Now speaking: Adam, Quinn, Ian, Alex	2026-09-05 17:50:00	2026-09-05 17:50:00	t
23	\N	2026-08-28 22:12:50	Speech #1	Hold on to your hats!	2026-09-05 17:45:00	2026-09-05 17:45:00	t
26	\N	2026-08-29 14:25:02	Speech #4	This is the last one!	2026-09-05 18:10:00	2026-09-05 18:10:00	t
\.


--
-- Data for Name: train_gifs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_gifs" ("id", "created_at", "updated_at", "link") FROM stdin;
\.


--
-- Data for Name: train_jokes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_jokes" ("id", "created_at", "updated_at", "message", "enabled") FROM stdin;
1	2026-04-05 15:57:00	2026-04-05 15:57:00	Why can't a steam locomotive sit down? It has a tender behind!	t
2	2026-04-05 15:57:00	2026-04-05 15:57:00	What do you get when you cross a railway engine with bubblegum? A chew-chew train!	t
3	2026-04-05 15:57:00	2026-04-05 15:57:00	How does a train avoid detection? It covers its tracks.	t
4	2026-04-05 15:57:00	2026-04-05 15:57:00	How do locomotives hear? Through their engineers.	t
5	2026-04-05 15:57:00	2026-04-05 15:57:00	What’s a train’s favourite type of shoes? Platforms.	t
6	\N	\N	What's another word for a late train? A slowcomotive.\n	t
7	\N	\N	Where can you buy train buffers? At an end of line sale.\n	t
8	\N	\N	I wanted to drive a train for ages, but I kept getting sidetracked.\n	t
9	\N	\N	It's hard to find anyone with more focus than a conductor because they have complete tunnel vision.\n	t
11	\N	\N	Why were the rail workers digging up a graveyard? They needed more underground sleepers!	t
12	\N	\N	Why did the train run smoothly? Superconductors. 	t
13	\N	\N	What's the difference between a teacher and a railway security guard? One trains the mind, the other minds the trains.	t
14	\N	\N	A friend of mine quit his job as a reporter and left town by railway. It was an ex-press train.	t
15	\N	\N	A friend got to the final of the local model railway competition. He lost on points.	t
16	\N	\N	The conductor has never missed a day of work in over 20 years on the job. He was there come train or shine.	t
17	\N	\N	I tried to get a job as a railway conductor, but they didn’t think I had enough training.	t
18	\N	\N	You can always tell when a train driver is stressed because they bite their rails.	t
19	\N	\N	Train conductors are clever and known for their engine-uity.	t
10	\N	2026-08-31 12:08:12	They finally caught that Spanish railway murderer. Police say he had loco motives.	t
\.


--
-- Data for Name: train_secrets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_secrets" ("id", "created_at", "updated_at", "message", "enabled") FROM stdin;
1	\N	\N	SECRET: ABCDE	t
2	2026-08-28 22:11:18	2026-08-28 22:11:18	SECRET: CHECK THE CHAIRS	t
\.


--
-- Data for Name: train_slideshows; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_slideshows" ("id", "created_at", "updated_at", "link") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."users" ("id", "name", "email", "email_verified_at", "password", "remember_token", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type", "versioning_status") FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_analytics" ("name", "type", "format", "created_at", "updated_at", "id", "deleted_at") FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_vectors" ("id", "type", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."objects" ("id", "bucket_id", "name", "owner", "created_at", "updated_at", "last_accessed_at", "metadata", "version", "owner_id", "user_metadata", "archived_at", "is_delete_marker", "is_versioned") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads" ("id", "in_progress_size", "upload_signature", "bucket_id", "key", "version", "owner_id", "created_at", "user_metadata", "metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads_parts" ("id", "upload_id", "size", "part_number", "bucket_id", "key", "etag", "owner_id", "version", "created_at") FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."vector_indexes" ("id", "name", "bucket_id", "data_type", "dimension", "distance_metric", "metadata_configuration", "created_at", "updated_at") FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 1, false);


--
-- Name: accommodation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."accommodation_id_seq"', 1, false);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."failed_jobs_id_seq"', 1, false);


--
-- Name: food_choices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."food_choices_id_seq"', 3, true);


--
-- Name: guests_duplicate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."guests_duplicate_id_seq"', 1, false);


--
-- Name: guests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."guests_id_seq"', 4, true);


--
-- Name: households_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."households_id_seq"', 3, true);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."jobs_id_seq"', 4, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."migrations_id_seq"', 23, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."personal_access_tokens_id_seq"', 1, false);


--
-- Name: seating_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."seating_id_seq"', 144, true);


--
-- Name: tables_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."tables_id_seq"', 12, true);


--
-- Name: train_affirmations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_affirmations_id_seq"', 1, false);


--
-- Name: train_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_comments_id_seq"', 45, true);


--
-- Name: train_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_configs_id_seq"', 3, true);


--
-- Name: train_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_events_id_seq"', 6, true);


--
-- Name: train_gifs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_gifs_id_seq"', 1, false);


--
-- Name: train_jokes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_jokes_id_seq"', 3, true);


--
-- Name: train_secrets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_secrets_id_seq"', 2, true);


--
-- Name: train_slideshows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_slideshows_id_seq"', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."users_id_seq"', 1, false);


--
-- PostgreSQL database dump complete
--

-- \unrestrict DKKKrfxh1Php0o9vTdfT0O1YKWyhwTIOq6C5Mi06WY3Mf0dtNkxZgqFUbMhBKDB

RESET ALL;
