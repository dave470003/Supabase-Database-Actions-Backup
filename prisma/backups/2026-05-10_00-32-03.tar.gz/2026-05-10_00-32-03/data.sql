SET session_replication_role = replica;

--
-- PostgreSQL database dump
--

-- \restrict gelOcidtyVkkkvLuHBKkNt6CeKdq1itIBdGLNP9gPP4wX9ISVqUG8JH8Akqh3aX

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."audit_log_entries" ("instance_id", "id", "payload", "created_at", "ip_address") FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."custom_oauth_providers" ("id", "provider_type", "identifier", "name", "client_id", "client_secret", "acceptable_client_ids", "scopes", "pkce_enabled", "attribute_mapping", "authorization_params", "enabled", "email_optional", "issuer", "discovery_url", "skip_nonce_check", "cached_discovery", "discovery_cached_at", "authorization_url", "token_url", "userinfo_url", "jwks_uri", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."flow_state" ("id", "user_id", "auth_code", "code_challenge_method", "code_challenge", "provider_type", "provider_access_token", "provider_refresh_token", "created_at", "updated_at", "authentication_method", "auth_code_issued_at", "invite_token", "referrer", "oauth_client_state_id", "linking_target_id", "email_optional") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."users" ("instance_id", "id", "aud", "role", "email", "encrypted_password", "email_confirmed_at", "invited_at", "confirmation_token", "confirmation_sent_at", "recovery_token", "recovery_sent_at", "email_change_token_new", "email_change", "email_change_sent_at", "last_sign_in_at", "raw_app_meta_data", "raw_user_meta_data", "is_super_admin", "created_at", "updated_at", "phone", "phone_confirmed_at", "phone_change", "phone_change_token", "phone_change_sent_at", "email_change_token_current", "email_change_confirm_status", "banned_until", "reauthentication_token", "reauthentication_sent_at", "is_sso_user", "deleted_at", "is_anonymous") FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."identities" ("provider_id", "user_id", "identity_data", "provider", "last_sign_in_at", "created_at", "updated_at", "id") FROM stdin;
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."instances" ("id", "uuid", "raw_base_config", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_clients" ("id", "client_secret_hash", "registration_type", "redirect_uris", "grant_types", "client_name", "client_uri", "logo_uri", "created_at", "updated_at", "deleted_at", "client_type", "token_endpoint_auth_method") FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sessions" ("id", "user_id", "created_at", "updated_at", "factor_id", "aal", "not_after", "refreshed_at", "user_agent", "ip", "tag", "oauth_client_id", "refresh_token_hmac_key", "refresh_token_counter", "scopes") FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_amr_claims" ("session_id", "created_at", "updated_at", "authentication_method", "id") FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_factors" ("id", "user_id", "friendly_name", "factor_type", "status", "created_at", "updated_at", "secret", "phone", "last_challenged_at", "web_authn_credential", "web_authn_aaguid", "last_webauthn_challenge_data") FROM stdin;
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_challenges" ("id", "factor_id", "created_at", "verified_at", "ip_address", "otp_code", "web_authn_session_data") FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_authorizations" ("id", "authorization_id", "client_id", "user_id", "redirect_uri", "scope", "state", "resource", "code_challenge", "code_challenge_method", "response_type", "status", "authorization_code", "created_at", "expires_at", "approved_at", "nonce") FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_client_states" ("id", "provider_type", "code_verifier", "created_at") FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_consents" ("id", "user_id", "client_id", "scopes", "granted_at", "revoked_at") FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."one_time_tokens" ("id", "user_id", "token_type", "token_hash", "relates_to", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."refresh_tokens" ("instance_id", "id", "token", "user_id", "revoked", "created_at", "updated_at", "parent", "session_id") FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_providers" ("id", "resource_id", "created_at", "updated_at", "disabled") FROM stdin;
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_providers" ("id", "sso_provider_id", "entity_id", "metadata_xml", "metadata_url", "attribute_mapping", "created_at", "updated_at", "name_id_format") FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_relay_states" ("id", "sso_provider_id", "request_id", "for_email", "redirect_to", "created_at", "updated_at", "flow_state_id") FROM stdin;
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_domains" ("id", "sso_provider_id", "domain", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_challenges" ("id", "user_id", "challenge_type", "session_data", "created_at", "expires_at") FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_credentials" ("id", "user_id", "credential_id", "public_key", "attestation_type", "aaguid", "sign_count", "transports", "backup_eligible", "backed_up", "friendly_name", "created_at", "updated_at", "last_used_at") FROM stdin;
\.


--
-- Data for Name: accommodation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."accommodation" ("id", "is_at_venue", "is_treehouse", "name", "slug", "is_paid_for", "price", "suggested_donation", "description", "link", "check_in", "check_out", "model") FROM stdin;
1	t	f	The Map Room	the-map-room	\N	\N	100.00	The Map Room celebrates James Augustus Grant, Anselm’s great-great-grandfather and famed explorer of the Nile. With a nod to adventure and discovery, the room is filled with character and provides an inspiring retreat for guests seeking both comfort and storytelling.	https://www.elmorecourt.com/house/	2026-09-05 14:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=35&sr=-2.98,-1.08
2	t	f	The Master Suite	the-master-suite	\N	\N	100.00	For centuries, the Master Suite has been the main bedroom of Elmore Court. With elegant wooden panelled walls, sweeping views over the estate and a generously sized bed, it exudes historic charm and contemporary comfort.	https://www.elmorecourt.com/house/	2026-09-05 12:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=220&sr=-.49,.83
3	t	f	The Dressing Room	the-dressing-room	\N	\N	100.00	Located next to the Master Suite, the Dressing Room is a beautiful room in it's own right, and comes complete with elegant wooden panelled walls, sweeping views over the estate and a generously sized bed.	https://www.elmorecourt.com/house/	2026-09-05 12:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=213&sr=-2.67,.62
22	t	t	Kite	kite	\N	\N	100.00	Swaddled by evergreen Laurels, the L-shaped pod is perched on the eastern edge of the woodlands. High on style, comfort and coziness, it has a properly awesome sheltered outdoor kitchen and copper bath on the deck alongside an outside fire pit. 	https://www.rewildthings.com/treehouses/kite/	2026-09-04 15:00:00	2026-09-06 11:00:00	\N
24	t	t	Adder	adder	\N	\N	100.00	Slithered among the foliage around the western edge of the woodlands, the L-shaped cabin has floor-to-ceiling windows washing natural light over the mellow timbers. 	https://www.rewildthings.com/treehouses/adder/	2026-09-05 15:00:00	2026-09-06 11:00:00	\N
4	t	f	The Smoking Room	the-smoking-room	\N	\N	100.00	Originally a place to relax after lively days, the Smoking Room carries its historic name while offering contemporary luxury. It boasts an Emperor-sized bed, elegant painted panelling and a deep, indulgent bath, perfect for unwinding in style after a busy day at the house or wedding festivities.	https://www.elmorecourt.com/house/	2026-09-05 12:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=194&sr=-2.98,.45
21	t	t	Sky	sky	\N	\N	0.00	Positioned high up in the canopy of Laurels to the east, Sky has cracking views over our rewilding wetlands and is of course built using sustainable materials in a way that caused minimal damage to the woodlands. The design is contemporary, energy efficient, comfortable and super cool.	https://www.rewildthings.com/treehouses/sky/	2026-09-04 15:00:00	2026-09-06 11:00:00	\N
18	t	f	The Coach House	the-coach-house	\N	\N	0.00	Though close to the main property feels very contained. It’s comfy, private and includes 2 double bedrooms and a sitting room with a sofa bed.	https://www.elmorecourt.com/stay/#coach	2026-09-04 16:00:00	2026-09-05 12:00:00	\N
9	t	f	The General's Room	the-generals-room	\N	\N	100.00	The General’s Room once housed a high-ranking military officer and is perfect for families. It includes a twin bed (or double bed, depending on how close you want to get) and a bunk bed, offering a fun and comfortable space for guests of all ages.	https://www.elmorecourt.com/house/	2026-09-05 14:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=102&sr=-2.87,-.3
5	t	f	The Oak Room	the-oak-room	\N	\N	100.00	The Oak Room is a bold and characterful retreat, featuring a 1636 four-poster bed, captivating artwork of serpents and unicorns and a decadent deep wooden bath. A striking blend of drama and comfort makes it one of the most memorable rooms in the house.	https://www.elmorecourt.com/house/	2026-09-05 14:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=29&sr=-2.77,-1.53
19	t	t	Wildcat	wildcat	\N	\N	100.00	A fabulous (sheltered) outdoor kitchen lives on the deck, along with a copper bath, fire pit and snooze chairs. While indoors there’s a wood burner, handmade super king bed with an organic mattress, soft linen and a bunch of cushions. Wildcat also has indoor cooking, tea and coffee facilities and a bathroom with a walk-in shower, sumptuous robes and top-notch bath products created from natural oils and healing plant extracts. 	https://www.rewildthings.com/treehouses/wildcat/	2026-09-05 15:00:00	2026-09-06 11:00:00	\N
20	t	t	Wren	wren	\N	\N	100.00	Wren is, like her namesake, small and perfectly formed. She rests lightly among the branches and leaves of the evergreen laurels, slap-bang in the middle of the woodlands with belting views. 	https://www.rewildthings.com/treehouses/wren/	2026-09-05 15:00:00	2026-09-06 11:00:00	\N
23	t	t	Earth	earth	\N	\N	100.00	Rooted in a particularly fine spot in the canopy, L-shaped Earth enjoys almost safari views from her deck and panoramic windows, along with cool contemporary, energy efficient design. 	https://www.rewildthings.com/treehouses/earth/	2026-09-05 15:00:00	2026-09-06 11:00:00	\N
6	t	f	The Porch Room	the-porch-room	\N	\N	100.00	The Porch Room is a flexible, dormitory-style space designed for families or groups. With four single beds that can be linked in multiple configurations and a charming Armoire reminiscent of a storybook wardrobe, it’s a playful and practical choice for guests seeking comfort with a hint of whimsy.	https://www.elmorecourt.com/house/	2026-09-05 14:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=49&sr=-.34,-.59
7	t	f	The Nursery	the-nursery	\N	\N	100.00	Traditionally the nursery, this spacious room features a double bed, an optional single bed and a marble-tiled bathroom. Its generous proportions make it ideal for families, combining practicality with timeless elegance and comfort.	https://www.elmorecourt.com/house/	2026-09-05 12:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=182&sr=-2.77,1.04
8	t	f	The Time Room	the-time-room	\N	\N	100.00	Light, airy, and full of character, the Time Room is named for “Old Father Time,” a reminder to savour life’s moments. The room features quirky 1920s graffiti and is celebrated for its brightness and charm, making it one of the most popular guest rooms in the house.	https://www.elmorecourt.com/house/	2026-09-05 14:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=1&sr=-2.31,-1.15
10	t	f	The North Room	the-north-room	\N	\N	100.00	Step back in time in the North Room, a classic wood-panelled bedroom with timeless elegance. Guests enjoy tranquil views of a majestic cedar tree and the Gillyflower, creating a serene and restorative stay.	https://www.elmorecourt.com/house/	2026-09-05 14:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=17&sr=-2.92,-.09
11	t	f	The Butler's Room	the-butlers-room	\N	\N	100.00	On the second floor, the Butler’s Room offers a double bed, sweeping views over the Gillyflower and Cedar Lawn and a beautifully appointed bathroom. A calm and refined space for restful nights.	https://www.elmorecourt.com/house/	2026-09-05 14:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=76&sr=-.4,-.42
12	t	f	The Hole In The Wall	the-hole-in-the-wall	\N	\N	100.00	Accessible via its own private staircase, the Hole in the Wall feels almost like a suite. This charming and secluded double bedroom includes a well-designed bathroom, offering privacy, comfort and a whimsical twist on traditional accommodation.	https://www.elmorecourt.com/house/	2026-09-05 14:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=243&sr=-.31,.05
13	t	f	The Private's Room	the-privates-room	\N	\N	100.00	Located beside the General’s Room, Privates is a cosy double bedroom with a grand bathroom just steps away. Its charm is amplified by a set of standout curtains, providing both elegance and a touch of humour.	https://www.elmorecourt.com/house/	2026-09-05 14:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=98&sr=-2.32,-1.1
14	t	f	The Cook's Room	the-cooks-room	\N	\N	100.00	Tucked away on the upper floor, the Cook’s Room features bold, vibrant colours and a sleek shower room. With views over the walled garden, it is a cheerful, lively space that combines practicality with flair.	https://www.elmorecourt.com/house/	2026-09-05 14:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=84&sr=-2.77,.35
17	t	f	The Footman's Room	the-footmans-room	\N	\N	100.00	On the second floor, the Footman’s Room shares a bathroom with the Governess’ Room. Light, comfortable and full of character, it’s an ideal choice for guests who appreciate historic charm with contemporary amenities.	https://www.elmorecourt.com/house/	2026-09-05 14:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=78&sr=-2.29,-.9
15	t	f	The Bachelor's Room	the-bachelors-room	\N	\N	100.00	Once home to the young masters after leaving the nursery, the Bachelor’s Room is a simple and comfortable double bedroom with a private shower room, offering a restful and historically resonant stay.	https://www.elmorecourt.com/house/	2026-09-05 14:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=42&sr=-2.58,-1.02
16	t	f	The Governesses Room	the-governesses-room	\N	\N	0.00	On the second floor, the Governess’ Room shares a bathroom with the adjacent Footman’s Room. This cosy, inviting space balances traditional charm with modern comfort, making it perfect for guests seeking a warm, communal feel.	https://www.elmorecourt.com/house/	2026-09-05 14:00:00	2026-09-06 10:00:00	https://my.matterport.com/show/?m=aDkHYbU7FyE&ss=66&sr=-.88,-1
\.


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."cache" ("key", "value", "expiration") FROM stdin;
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."cache_locks" ("key", "owner", "expiration") FROM stdin;
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."failed_jobs" ("id", "uuid", "connection", "queue", "payload", "exception", "failed_at") FROM stdin;
\.


--
-- Data for Name: food_choices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."food_choices" ("id", "name", "description", "allergens", "course_number", "is_child_food", "options", "cost") FROM stdin;
0	No Meal	No Meal	0	0	f	0	0.00
1	Tart	Spring vegetable & goats cheese tart, dressed leaves	0	1	f	0	0.00
2	Salmon	Hot smoked salmon fillet, curried fried rice, sesame yoghurt, aubergine jam	0	1	f	0	0.00
5	Cheesecake	Baked vanilla cheesecake, poached strawberries	0	3	f	0	0.00
7	Beef Roast	Roast Hereford beef rump	0	2	f	0	0.00
8	Veggie Roast	Root vegetable and lentil loaf	0	2	f	0	0.00
14	Pizza	Mini pitta pizza	0	1	t	0	0.00
15	Spaghetti	Spaghetti, tomato sauce	0	2	t	0	0.00
16	Brownie	Triple chocolate brownie & vanilla ice cream	0	3	t	0	0.00
\.


--
-- Data for Name: guests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."guests" ("id", "reference_name", "name", "email", "rsvp", "household", "role", "requires_childcare_data", "requires_childrens_menu", "requires_childcare", "dietary_requirements", "comments", "favourite_board_game", "invited_day_after", "invited_evening_before", "evening_only", "partner_invited", "is_child", "day_before_rsvp", "day_after_rsvp", "course_1_id", "course_2_id", "course_3_id") FROM stdin;
28	Marcus Fox	Marcus Fox	\N	\N	14	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
38	Paul Dunn	Paul Dunn	\N	\N	19	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
39	Janet Dunn	Janet Dunn	\N	\N	19	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
67	Daniel Hanvey	Daniel Hanvey	\N	\N	32	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
74	Oliver Byford	Oliver Byford	\N	\N	37	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
75	Emily Byford	Emily Byford	\N	\N	37	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
76	Elliot Byford	Elliot Byford	\N	\N	37	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
77	Sian Ebsworth	Sian Ebsworth	\N	\N	38	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
3	Alyssa Burling	Alyssa Burling	alyssa.burlton@gmail.com	t	2	Wedding Party	f	f	f	\N	I tried to follow your spaceship directions and flew into the sun :(	\N	t	\N	\N	\N	\N	\N	yes	1	8	0
27	Astraea Capocci-Hunt	Astraea Capocci-Hunt	\N	t	13	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	14	15	16
1	Freddy Pitel	Freddy Pitel	fwbpitel@gmail.com	t	1	Groom	f	f	f	Gluten and dairy intollerance	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5
25	Kieron Capocci-Hunt	Kieron Capocci-Hunt	\N	t	13	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5
32	Laura Pitel	Laura Pitel	\N	t	17	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	no	1	8	5
26	Artemis Capocci-Hunt	Artemis Capocci-Hunt	\N	t	13	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	14	15	16
31	Sally Pitel	Sally Pitel	sallypitel@gmail.com	t	16	Day Guest	f	f	f	\N	It all looks simply delicious	\N	t	\N	\N	\N	\N	\N	no	1	7	5
62	Adam Dunnicliffe	Adam Dunnicliffe	\N	t	31	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
64	Joel Dunnicliffe	Joel Dunnicliffe	\N	t	31	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	14	15	16
65	Georgia Dunnicliffe	Georgia Dunnicliffe	\N	t	31	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	14	15	16
68	David Holtum	David Holttum	David@Holttum.co.uk	t	33	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
70	Henry Holtum	Henry Holttum	\N	t	33	Day Guest	t	t	t	\N	High five (he's learnt it and will insist on it)	\N	f	\N	\N	\N	\N	\N	\N	14	7	16
15	Ian Barwick	Ian Barwick	Ianbarwick1@gmail.com	t	10	Day Guest	f	f	f	\N	Looking forward to it.	\N	f	\N	\N	\N	\N	\N	\N	1	7	5
58	Tanya Burnett	Tanya Burnett	tanyamarieknox@gmail.com	t	28	Day Guest	f	f	f	Vegetarian	\N	\N	f	\N	\N	\N	\N	\N	\N	1	8	5
16	Ellie Barwick	Ellie Barwick	ejbarwick250@gmail.com	t	10	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
17	Enzo Barwick	Enzo Barwick	\N	t	10	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	14	15	16
5	Jon Masson	Jon Masson	jmasson91@googlemail.com	t	4	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5
12	Helena Chan	Helena Chan	helena002@gmail.com	t	4	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5
36	Beatrix Pitel	Beatrix Pitel	Bea.pitel@googlemail.com	t	18	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	1	7	5
13	Katie Hannaford	Katie Hannaford	kjhannaford92@gmail.com	t	9	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
14	Alexei Barnes	Alexei Barnes	alexei.barnes@live.co.uk	t	9	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
45	Pandora Blair	Pandora Blair	\N	t	22	Day Guest	f	f	f	\N	So excited!!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
46	Harriet Blair	Harriet Blair	\N	t	22	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
47	Stacey Chodera	Stacey Chodera	\N	t	7	Day Guest	f	f	f	Vegetarian, no mushrooms	\N	\N	t	\N	\N	\N	\N	\N	no	1	8	5
8	Adam Chodera	Adam Chodera	chodera.adam@gmail.com	t	7	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	no	1	8	5
72	Matthew Nutt	Matthew Nutt	\N	t	35	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
20	Reem Khurshid	Reem Khurshid	reem.khurshid@gmail.com	t	11	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5
19	Todd Francis	Todd Francis	toddish.f@gmail.com	t	11	Day Guest	f	f	f	\N	I can't wait!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
66	Shreya Garge	Shreya Garge	shreyagarge@gmail.com	t	8	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	yes	2	8	5
53	Alix Lyons	Alix Lyons	chidz1612@gmail.com	t	25	Day Guest	f	f	f	\N	Your invitation is fantastic! So much love for this!	\N	f	\N	\N	\N	\N	\N	\N	2	8	0
51	Craig Sargent	Craig Sargent	craigsargent@hotmail.co.uk	t	24	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5
52	Sam Sargent	Sam Sargent	samuelsargent89@icloud.com	t	24	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5
40	Louise Wooldridge	Louise Wooldridge	\N	t	20	Day Guest	f	f	f	Mushroom Intolerance (although doesn’t look like that will be an issue)	\N	\N	t	\N	\N	\N	\N	\N	\N	0	7	5
41	Jon Wooldridge	Jon Wooldridge	jonlou16@gmail.com	t	20	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	1	7	5
49	Amy Paul	Amy Paul	martinjpaul@me.com	t	23	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
50	Theodore Paul	Theo Paul	\N	t	23	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	14	7	16
22	Cilla Price-Dahlgren	Cilla Price-Dahlgren	Cillasilvia@hotmail.com	t	12	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
21	Christopher Price-Dahlgren	Christopher Price-Dahlgren	Chriskillik@gmail.com	t	12	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
30	Nigel Pitel	Nigel Pitel	nigelpitel@gmail.com	t	15	Day Guest	f	f	f	Very Stroud, like my clothing	Lots of love from us both XX	\N	t	\N	\N	\N	\N	\N	yes	1	7	5
34	Margot McTel	Margot McTel	\N	t	17	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	14	15	16
35	Rowan McTel	Rowan McTel	\N	t	17	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	no	14	15	16
42	Libby Dunn	Libby Dunn	Libbyrosestephen@gmail.com	t	5	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5
56	Jonathan Vooght	Jon Vooght	\N	t	27	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5
55	Colin Paxton	Colin Paxton	FandD@colinpaxton.com	t	26	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5
80	Erika Sojkova	Erika Sojkova	\N	t	40	Day Guest	f	f	f	\N	Cheesecake yeah!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
73	Matthew Wyles	Matthew Wyles	matthewwyles@gmail.com	t	36	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
90	Timothy Finlay	Timothy Finlay	\N	\N	46	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
91	Eileen Finlay	Eileen Finlay	\N	\N	46	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
99	Daniel Calinski	Daniel Calinski	\N	\N	50	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
100	Angela Calinski	Angela Calinski	\N	\N	50	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
101	Ana Lu Calinksi	Ana Lu Calinksi	\N	\N	50	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
102	Adrian Gralak	Adrian Gralak	\N	\N	51	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
103	Michal Leczycki	Michal Leczycki	\N	\N	52	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
114	Katie Styles	Katie Styles	\N	\N	59	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
116	George Styles	George Styles	\N	\N	59	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
117	Wilf Styles	Wilf Styles	\N	\N	59	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
171	Jordan Murray	Jordan Murray	\N	\N	90	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
11	Sara Fisher	Sara Fisher	thefishers5725@gmail.com	t	3	Day Guest	f	f	f	\N	Happy wedding planning! Nth time is the charm!	\N	t	\N	\N	\N	\N	\N	yes	1	7	5
4	Mark Fisher	Mark Fisher	thefishers5725@gmail.com	t	3	Wedding Party	f	f	f	\N	Wahoo! It's working!	\N	t	\N	\N	\N	\N	\N	yes	1	7	5
170	Reuben Goldmark	Reuben Goldmark	reubengoldmark@gmail.com	t	89	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
172	Madeline MacLean	Madeline MacLean	madelinemaclean9@gmail.com	t	91	Day Guest	f	f	f	\N	I am incredibly excited and audibly hungry for this!! Can’t wait xx	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
10	Leah Burling	Leah Burling	leah.ann.king93@gmail.com	t	2	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	0	8	0
188	Ian Ang	Ian Ang	ianang1993@gmail.com	t	104	Day Guest	f	f	f	\N	Yummy yummy yummy I got yummy in my tummy	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
175	Kirsty Blythe	Kirsty Blythe	kirsty.blythe@hotmail.co.uk	t	94	Day Guest	f	f	f	\N	Your story on the website was amazing, I’m getting misty eyed already! X	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
71	Ezra Attwood	Ezra Attwood	\N	t	34	Day Guest	f	f	f	\N	Super joyfully yes. Thanks guys 🤗🥳🏳️‍🌈	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
2	David Fox	David Fox	djwfox@gmail.com	t	1	Groom	f	f	f	no pork/shellfish	More testing - I love you!	\N	t	\N	\N	\N	\N	\N	yes	1	7	5
24	Hannah Capocci-Hunt	Hannah Capocci-Hunt	khunt500@gmail.com	t	13	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	1	7	5
63	Michel Dunnicliffe	Michel Dunnicliffe-Ward	shelward999@googlemail.com	t	31	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5
69	Heather Holtum	Heather Holttum	heather@holttum.co.uk	t	33	Day Guest	f	f	f	\N	Can't wait to celebrate	\N	f	\N	\N	\N	\N	\N	\N	0	7	5
57	Matthew Burnett	Matthew Burnett	Foxtel@mattburnett.co.uk	t	28	Day Guest	f	f	f	\N	I love the invite and website design	\N	f	\N	\N	\N	\N	\N	\N	1	7	5
81	Will Saunders	Will Saunders	wrs@wrsaunders.co.uk	t	41	Day Guest	f	f	f	N/a	Thanks for the invite and accommodation!	\N	f	\N	\N	\N	\N	\N	\N	1	7	5
18	Luca Barwick	Luca Barwick	\N	t	10	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	8	16
85	Chris Bradley	Chris Bradley	chris4794@hotmail.co.uk	t	43	Day Guest	f	f	f	None	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
84	Lawrance Bailes	Lawrance Bailes	lawrance.bailes21@googlemail.com	t	43	Day Guest	f	f	f	No gravy, salad dressings or condiments please	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5
185	Louise O'Young	Louise O'Young	ms.louise.oyoung@gmail.com	t	101	Day Guest	f	f	f	I would like to know how the leaves are dressed so I can coordinate my outfit accordingly.	I'm so excited!!!! It's going to be a wonderful day. xoxo	\N	f	\N	\N	\N	\N	\N	\N	1	7	5
82	Tom Jordan	Tom Jordan	Tma.jordan@outlook.com	t	42	Day Guest	f	f	f	None	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
105	Beth Little	Beth Little	Jolly_rodgers7@hotmail.com	t	54	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	8	5
106	Martin Little	Martin Little	martinlittle90@gmail.com	t	54	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
187	Mia Violentano	Mia Violentano	maria.violentano@gmail.com	t	103	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5
86	Richard Nicholson	Richard Nicholson	\N	t	44	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
87	Helen Nicholson	Helen Nicholson	\N	t	44	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
93	Ameila Pritchard	Amelia Pritchard	amelia.pritchard10@gmail.com	t	47	Day Guest	f	f	f	Vegetarian	I’m so happy for you two. Thank you for inviting me.	\N	t	\N	\N	\N	\N	\N	\N	0	8	5
88	Cherie Fox	Cherie Fox	\N	f	45	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
89	John Fox	John Fox	\N	f	45	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
109	Debbie Fisher	Debby Fisher	debbyfisher6873@gmail.com	t	56	Day Guest	f	f	f	\N	All looks lovely, looking forward to coming! I have a hat!!!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
96	Roman Marych	Roman Marych	marych.roman@gmail.com	t	49	Day Guest	f	f	f	N/A	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5
97	Julia Marych	Julia Marych	julia.kub.mar@gmail.com	t	49	Day Guest	f	f	f	N/A	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5
98	Julian Marych	Julian Marych	\N	f	49	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
195	Corrine O'Connor	Corinne O'Connor	Corinne.oconnor@hotmail.com	t	110	Day Guest	f	f	f	None :-)	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
191	Lawrence Bishop	Lawrence Bishop	banjoses@gmail.com	t	107	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
189	Rachel Dowse	Rachel Dowse	r.e.dowse@hotmail.co.uk	t	105	Day Guest	f	f	f	None	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5
167	Sam Kenny	Sam Kenny	samuel_j_kenny@hotmail.co.uk	t	86	Day Guest	f	f	f	N/A	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
168	Anthony Whelan	Anthony Whelan	Anthony.tux@gmail.com	t	87	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	1	7	5
112	Charlie Fisher	Charles Fisher	cfisher1993267@gmail.com	t	58	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	no	1	7	5
169	Elisabeth Swedlund	Elisabeth Swedlund	elisabeth.swedlund@gmail.com	t	88	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
115	James Styles	James Styles	\N	\N	59	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
192	Jamie Jones	Jamie Jones	jones.j15@gmail.com	t	108	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
119	Sinead	Sinead Geraghty	tomdanderson27@gmail.com	t	60	Day Guest	f	f	f	None	\N	\N	t	\N	\N	\N	\N	\N	unsure	1	7	5
83	Giada Jordan	Giada Jordan	Giada.piero@gmail.com	t	42	Day Guest	f	f	f	None	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
107	Harriet Little	Harriet Little	\N	f	54	Day Guest	t	t	t	\N	I’d really like to come but mummy and daddy won’t let me. Something about wanting to have a good time!	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
37	Dermot Colton	Dermot Colton	Dermotcolton@gmail.com	t	18	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5
173	Marianne Baker	Marianne Baker	marianne.baker@outlook.com	t	92	Day Guest	f	f	f	Veggie (with some fish allowed)!	Many thanks for the invite, looking forward to it!!	\N	f	\N	\N	\N	\N	\N	\N	2	8	0
59	Nick Bartly	Nick Bartley	freddyanddavidwedding@nb221.com	t	29	Day Guest	f	f	f	\N	This wedding website design is amazing! We love it. And we are both already looking forward to joining you.	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
60	Jana Bartly	Jana Bartley	jana@nickandjana.co.uk	t	29	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
92	Oliver Nicholson	Oliver Nicholson	\N	t	44	Day Guest	t	t	t	\N	If possible please can we have a highchair - no worries if not possible!	\N	f	\N	\N	\N	\N	\N	\N	14	15	0
44	Edward Sanders	Edward Sanders	\N	f	21	Day Guest	f	f	f	\N	Apologies. Unless a global lack of jet fuel intervenes, I'm planning to be in the South Pacific. Can I take you out for a celebratory dinner when you're back from the honeymoon?	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
166	Gerry Lovelace	Gerry Lovelace	gerrelou@gmail.com	t	85	Day Guest	f	f	f	Lactose intolerance	Not sure they will have BBQ sauce there, but if they do, will be appreciated :)	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
61	Shaun Zedlewski	Shaun Zedlewski	sir.shaih+freddyanddavid@gmail.com	t	30	Day Guest	f	f	f	Food should be edible	/* Insert witty comment here. */	\N	f	\N	\N	\N	\N	\N	\N	1	7	5
7	Alex Prichard	Alex Prichard	alexdpritchard@hotmail.com	t	6	Wedding Party	f	f	f	Dairy free, specifically A1 beta-casein, Goats milk therefore is fine:)	Dessert, I'll have what Freddy's having :)  Missing a box for "I'm special"	\N	t	\N	\N	\N	\N	\N	yes	1	7	0
194	Lucy Williams	Lucy Williams	lucy@thehenhouse.co.uk	t	106	Day Guest	f	f	f	Vegetarian (yes to eggs and cheese etc, no thanks to meat/fish)	\N	\N	f	\N	\N	\N	\N	\N	\N	1	8	5
186	Dan Pope	Dan Pope	djpope2365@gmail.com	t	102	Day Guest	f	f	f	\N	I'm so excited!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
9	Stephen Quinn	Stephen Quinn	sckrikor@gmail.com	t	8	Wedding Party	f	f	f	Lactose intolerance, allergy to aubergines (eggplants)	Please leave off the aubergine jam. Is there a less cheesy alternative to cheesecake for dessert?	\N	t	\N	\N	\N	\N	\N	yes	2	7	5
196	Matt O'Connor	Matt O'Connor	\N	t	110	Day Guest	f	f	f	Matt O’Connor has a rather severe intolerance to onion (including leeks, shallots, chives etc). Garlic is fine, and he’s fine for his meal to be cooked in an environment where there are onions- just no onions on the plate please!	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
54	James Lyons	James Lyons	\N	t	25	Day Guest	f	f	f	\N	I also think your invite is excellent, we're both very much looking forward to your big day!	\N	f	\N	\N	\N	\N	\N	\N	1	7	5
78	Stephen Briscoe	Stephen Briscoe	freddydavid@stephenbriscoe.co..uk	t	39	Day Guest	f	f	f	\N	Love the website and invite design!	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
193	Nanditha Garge	Nanditha Garge	nanditagarge1123@gmail.com	t	109	Day Guest	f	f	f	No specific requirements	Congratulationssss!!	\N	f	\N	\N	\N	\N	\N	\N	2	8	5
48	Martin Paul	Martin Paul	martinjpaul@me.com	t	23	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
23	Saphi Price-Dahlgren	Saphi Price-Dahlgren	\N	t	12	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	0	15	0
190	Nathan Williams	Nathan Williams	nathan@thehenhouse.co.uk	t	106	Day Guest	f	f	f	vegetarian (cheese and eggs OK)	Congratulations!!! Can't wait.	\N	f	\N	\N	\N	\N	\N	\N	1	8	5
29	Helen Pitel	Helen Pitel	helenpitel1@gmail.com	t	15	Day Guest	f	f	f	\N	Delicious menu, thank you	\N	t	\N	\N	\N	\N	\N	yes	1	7	5
33	John McManus	John McManus	\N	t	17	Day Guest	f	f	f	\N	If it's possible to just have strawberries for dessert, that would be my choice. But if too faffy, then just nothing.	\N	t	\N	\N	\N	\N	\N	no	2	7	0
110	Evie Fisher	Evie Fisher	evie.fisher96@gmail.com	t	57	Day Guest	f	f	f	\N	Amazing invitation, amazing website! Can't wait to celebrate the big day with you both 💑	\N	t	\N	\N	\N	\N	\N	no	1	7	5
6	Ian Dunn	Ian Dunn	Dunny118@gmail.com	t	5	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	1	7	5
43	Millie Dunn	Millie Dunn	\N	t	5	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	14	8	5
118	Tom Anderson	Tom Anderson	tomdanderson27@gmail.com	t	60	Day Guest	f	f	f	None	\N	\N	t	\N	\N	\N	\N	\N	unsure	1	7	5
79	SB	SB	\N	t	40	Day Guest	f	f	f	Gluten Free	Sounds yummy 😋	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
\.


--
-- Data for Name: guests_duplicate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."guests_duplicate" ("id", "reference_name", "name", "email", "rsvp", "household", "role", "requires_childcare_data", "requires_childrens_menu", "requires_childcare", "dietary_requirements", "comments", "favourite_board_game", "invited_day_after", "invited_evening_before", "evening_only", "partner_invited", "is_child", "day_before_rsvp", "day_after_rsvp", "course_1_id", "course_2_id", "course_3_id") FROM stdin;
5	Jon Masson	Jon Masson	\N	\N	4	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
6	Ian Dunn	Ian Dunn	\N	\N	5	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
7	Alex Prichard	Alex Prichard	\N	\N	6	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
8	Adam Chodera	Adam Chodera	\N	\N	7	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
9	Stephen Quinn	Stephen Quinn	\N	\N	8	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
12	Helena Chan	Helena Chan	\N	\N	4	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
13	Katie Hannaford	Katie Hannaford	\N	\N	9	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
14	Alexei Barnes	Alexei Barnes	\N	\N	9	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
15	Ian Barwick	Ian Barwick	\N	\N	10	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
16	Ellie Barwick	Ellie Barwick	\N	\N	10	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
17	Enzo Barwick	Enzo Barwick	\N	\N	10	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
18	Luca Barwick	Luca Barwick	\N	\N	10	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
19	Todd Francis	Todd Francis	\N	\N	11	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
20	Reem Khurshid	Reem Khurshid	\N	\N	11	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
21	Christopher Price-Dahlgren	Christopher Price-Dahlgren	\N	\N	12	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
22	Cilla Price-Dahlgren	Cilla Price-Dahlgren	\N	\N	12	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
23	Saphi Price-Dahlgren	Saphi Price-Dahlgren	\N	\N	12	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
24	Hannah Capocci-Hunt	Hannah Capocci-Hunt	\N	\N	13	Wedding Party	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
26	Artemis Capocci-Hunt	Artemis Capocci-Hunt	\N	\N	13	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
27	Astraea Capocci-Hunt	Astraea Capocci-Hunt	\N	\N	13	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
28	Marcus Fox	Marcus Fox	\N	\N	14	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
29	Helen Pitel	Helen Pitel	\N	\N	15	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
31	Sally Pitel	Sally Pitel	\N	\N	16	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
32	Laura Pitel	Laura Pitel	\N	\N	17	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
33	John McManus	John McManus	\N	\N	17	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
34	Margot McTel	Margot McTel	\N	\N	17	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
35	Rowan McTel	Rowan McTel	\N	\N	17	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
36	Beatrix Pitel	Beatrix Pitel	\N	\N	18	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
37	Dermot Colton	Dermot Colton	\N	\N	18	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
38	Paul Dunn	Paul Dunn	\N	\N	19	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
39	Janet Dunn	Janet Dunn	\N	\N	19	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
40	Louise Wooldridge	Louise Wooldridge	\N	\N	20	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
41	Jon Wooldridge	Jon Wooldridge	\N	\N	20	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
42	Libby Dunn	Libby Dunn	\N	\N	5	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
43	Millie Dunn	Millie Dunn	\N	\N	5	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
44	Edward Sanders	Edward Sanders	\N	\N	21	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
45	Pandora Blair	Pandora Blair	\N	\N	22	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
46	Harriet Blair	Harriet Blair	\N	\N	22	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
47	Stacey Chodera	Stacey Chodera	\N	\N	7	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
48	Martin Paul	Martin Paul	\N	\N	23	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
49	Amy Paul	Amy Paul	\N	\N	23	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
50	Theodore Paul	Theodore Paul	\N	\N	23	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
51	Craig Sargent	Craig Sargent	\N	\N	24	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
52	Sam Sargent	Sam Sargent	\N	\N	24	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
53	Alix Lyons	Alix Lyons	\N	\N	25	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
54	James Lyons	James Lyons	\N	\N	25	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
55	Colin Paxton	Colin Paxton	\N	\N	26	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
56	Jonathan Vooght	Jonathan Vooght	\N	\N	27	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
57	Matthew Burnett	Matthew Burnett	\N	\N	28	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
58	Tanya Burnett	Tanya Burnett	\N	\N	28	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
59	Nick Bartly	Nick Bartly	\N	\N	29	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
60	Jana Bartly	Jana Bartly	\N	\N	29	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
61	Shaun Zedlewski	Shaun Zedlewski	\N	\N	30	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
62	Adam Dunnicliffe	Adam Dunnicliffe	\N	\N	31	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
63	Michel Dunnicliffe	Michel Dunnicliffe	\N	\N	31	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
64	Joel Dunnicliffe	Joel Dunnicliffe	\N	\N	31	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
65	Georgia Dunnicliffe	Georgia Dunnicliffe	\N	\N	31	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
66	Shreya Garge	Shreya Garge	\N	\N	8	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
67	Daniel Hanvey	Daniel Hanvey	\N	\N	32	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
68	David Holtum	David Holtum	\N	\N	33	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
69	Heather Holtum	Heather Holtum	\N	\N	33	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
70	Henry Holtum	Henry Holtum	\N	\N	33	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
71	Ezra Attwood	Ezra Attwood	\N	\N	34	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
72	Matthew Nutt	Matthew Nutt	\N	\N	35	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
73	Matthew Wyles	Matthew Wyles	\N	\N	36	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
74	Oliver Byford	Oliver Byford	\N	\N	37	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
75	Emily Byford	Emily Byford	\N	\N	37	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
76	Elliot Byford	Elliot Byford	\N	\N	37	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
77	Sian Ebsworth	Sian Ebsworth	\N	\N	38	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
78	Stephen Briscoe	Stephen Briscoe	\N	\N	39	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
79	SB	SB	\N	\N	40	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
80	Erika Sojkova	Erika Sojkova	\N	\N	40	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
81	Will Saunders	Will Saunders	\N	\N	41	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
82	Tom Jordan	Tom Jordan	\N	\N	42	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
3	Alyssa Burling	Alyssa Burling	alyssa.burlton@gmail.com	t	2	Wedding Party	f	f	f	\N	I tried to follow your spaceship directions and flew into the sun :(	\N	t	\N	\N	\N	\N	\N	yes	1	8	0
25	Kieron Capocci-Hunt	Kieron Capocci-Hunt	\N	\N	13	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
1	Freddy Pitel	Freddy Pitel	fwbpitel@gmail.com	t	1	Groom	f	f	f	Gluten and dairy intollerance	\N	\N	t	\N	\N	\N	\N	\N	yes	2	7	5
30	Nigel Pitel	Nigel Pitel	\N	\N	15	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
83	Giada Jordan	Giada Jordan	\N	\N	42	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
84	Lawrance Bailes	Lawrance Bailes	\N	\N	43	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
85	Chris Bradley	Chris Bradley	\N	\N	43	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
86	Richard Nicholson	Richard Nicholson	\N	\N	44	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
87	Helen Nicholson	Helen Nicholson	\N	\N	44	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
88	Cherie Fox	Cherie Fox	\N	\N	45	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
89	John Fox	John Fox	\N	\N	45	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
90	Timothy Finlay	Timothy Finlay	\N	\N	46	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
91	Eileen Finlay	Eileen Finlay	\N	\N	46	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
92	Oliver Nicholson	Oliver Nicholson	\N	\N	44	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
93	Ameila Pritchard	Ameila Pritchard	\N	\N	47	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
96	Roman Marych	Roman Marych	\N	\N	49	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
97	Julia Marych	Julia Marych	\N	\N	49	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
98	Julian Marych	Julian Marych	\N	\N	49	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
99	Daniel Calinski	Daniel Calinski	\N	\N	50	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
100	Angela Calinski	Angela Calinski	\N	\N	50	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
101	Ana Lu Calinksi	Ana Lu Calinksi	\N	\N	50	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
102	Adrian Gralak	Adrian Gralak	\N	\N	51	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
103	Michal Leczycki	Michal Leczycki	\N	\N	52	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
105	Beth Little	Beth Little	\N	\N	54	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
106	Martin Little	Martin Little	\N	\N	54	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
107	Harriet Little	Harriet Little	\N	\N	54	Day Guest	t	t	t	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
109	Debbie Fisher	Debbie Fisher	\N	\N	56	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
110	Evie Fisher	Evie Fisher	\N	\N	57	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
112	Charlie Fisher	Charlie Fisher	\N	\N	58	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
114	Katie Styles	Katie Styles	\N	\N	59	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
115	Tom Anderson	Tom Anderson	\N	\N	59	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
116	George Styles	George Styles	\N	\N	59	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
117	Wilf Styles	Wilf Styles	\N	\N	59	Day Guest	t	t	t	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
118	Tom Anderson	Tom Anderson	\N	\N	60	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
119	Sinead	Sinead	\N	\N	60	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	\N
166	Gerry Lovelace	Gerry Lovelace	\N	\N	85	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
167	Sam Kenny	Sam Kenny	\N	\N	86	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
168	Anthony Whelan	Anthony Whelan	\N	\N	87	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
169	Elisabeth Swedlund	Elisabeth Swedlund	\N	\N	88	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
171	Jordan Murray	Jordan Murray	\N	\N	90	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
173	Marianne Baker	Marianne Baker	\N	\N	92	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
175	Kirsty Blythe	Kirsty Blythe	\N	\N	94	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
185	Louise O'Young	Louise O'Young	\N	\N	101	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
186	Dan Pope	Dan Pope	\N	\N	102	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
187	Mia Violentano	Mia Violentano	\N	\N	103	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
189	Rachel Dowse	Rachel Dowse	\N	\N	105	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
190	Nathan Williams	Nathan Williams	\N	\N	106	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
191	Lawrence Bishop	Lawrence Bishop	\N	\N	107	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
192	Jamie Jones	Jamie Jones	\N	\N	108	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
193	Nanditha Garge	Nanditha Garge	\N	\N	109	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
194	Lucy Williams	Lucy Williams	\N	\N	106	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
195	Corrine O'Connor	Corrine O'Connor	\N	\N	110	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
196	Matt O'Connor	Matt O'Connor	\N	\N	110	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N
11	Sara Fisher	Sara Fisher	thefishers5725@gmail.com	t	3	Day Guest	f	f	f	\N	Happy wedding planning! Nth time is the charm!	\N	t	\N	\N	\N	\N	\N	yes	1	7	5
4	Mark Fisher	Mark Fisher	thefishers5725@gmail.com	t	3	Wedding Party	f	f	f	\N	Wahoo! It's working!	\N	t	\N	\N	\N	\N	\N	yes	1	7	5
170	Reuben Goldmark	Reuben Goldmark	reubengoldmark@gmail.com	t	89	Day Guest	f	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
172	Madeline MacLean	Madeline MacLean	madelinemaclean9@gmail.com	t	91	Day Guest	f	f	f	\N	I am incredibly excited and audibly hungry for this!! Can’t wait xx	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
10	Leah Burling	Leah Burling	leah.ann.king93@gmail.com	t	2	Day Guest	f	f	f	\N	\N	\N	t	\N	\N	\N	\N	\N	yes	0	8	0
188	Ian Ang	Ian Ang	ianang1993@gmail.com	t	104	Day Guest	f	f	f	\N	Yummy yummy yummy I got yummy in my tummy	\N	f	\N	\N	\N	\N	\N	\N	2	7	5
2	David Fox	David Fox	djwfox@gmail.com	t	1	Groom	f	f	f	no pork/shellfish	I love you!	\N	t	\N	\N	\N	\N	\N	yes	1	7	5
\.


--
-- Data for Name: households; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."households" ("id", "name", "code", "rsvp_sent", "accommodation_id", "invited_day_after", "invited_evening_before", "day_before_response", "day_after_response", "in_coach_house") FROM stdin;
107	Bishop	ALEL	t	\N	f	f	\N	\N	f
105	Dowse	ARKB	t	\N	f	f	\N	\N	f
91	MacLean	BBZM	t	\N	f	f	\N	\N	f
40	SB	BHUP	t	1	f	f	\N	\N	f
85	Lovelace	BLOX	t	\N	f	f	\N	\N	f
94	Blythe	BOLW	t	\N	f	f	\N	\N	f
30	Zedlewski	CCCM	t	6	f	f	\N	\N	f
25	Lyons	EKQE	t	23	f	f	\N	\N	f
37	Byford	DALP	t	8	f	f	\N	\N	f
104	Ang	DEND	t	\N	f	f	\N	\N	f
24	Sargent	FIVD	t	\N	f	f	\N	\N	f
103	Violentano	EICM	t	\N	f	f	\N	\N	f
101	O'Young	CSHH	t	\N	f	f	\N	\N	f
22	Blair	GWII	t	\N	f	f	\N	\N	f
7	Chodera	GXZU	t	\N	t	f	\N	\N	f
16	Pitel	HDDI	t	\N	t	f	\N	\N	f
33	Holtum	JATR	t	15	f	f	\N	\N	f
89	Goldmark	JRCU	t	\N	f	f	\N	\N	f
32	Hanvey	KCHT	t	9	f	f	\N	\N	f
35	Nutt	IRYU	t	6	f	f	\N	\N	f
38	Ebsworth	KPNH	t	9	f	f	\N	\N	f
56	Fisher	LNZX	t	\N	f	f	\N	\N	f
23	Paul	MNYS	t	\N	f	f	\N	\N	f
26	Paxton	NXDQ	t	6	f	f	\N	\N	f
29	Bartly	NCWV	t	24	f	f	\N	\N	f
59	Styles	ODFE	t	\N	t	f	\N	\N	f
39	Briscoe	OECP	t	\N	f	f	\N	\N	f
90	Murray	OJPB	t	\N	f	f	\N	\N	f
9	Hannaford	OYAW	t	19	f	f	\N	\N	f
11	Francis	OJBO	t	5	f	f	\N	\N	f
27	Vooght	PAJW	t	\N	f	f	\N	\N	f
87	Whelan	PCUN	t	\N	f	f	\N	\N	f
88	Swedlund	PQSM	t	\N	f	f	\N	\N	f
102	Pope	QGIU	t	\N	f	f	\N	\N	f
8	Quinn	PPLN	t	22	t	f	\N	\N	f
31	Dunnicliff	REZT	t	13	f	f	\N	\N	f
2	Burling	STCX	t	3	t	f	\N	\N	t
10	Barwick	QTNN	t	7	f	f	\N	\N	f
28	Burnett	RXEM	t	20	f	f	\N	\N	f
108	Jones	TMEH	t	\N	f	f	\N	\N	f
92	Baker	UMGQ	t	\N	f	f	\N	\N	f
18	Pitel	TCVD	t	\N	t	f	\N	\N	f
43	Bailes	UZYQ	t	\N	f	f	\N	\N	f
21	Sanders	VNNR	t	\N	f	f	\N	\N	f
106	Williams	WIWN	t	\N	f	f	\N	\N	f
6	Prichard	XOVG	t	17	t	f	\N	\N	f
3	Fisher	XLVR	t	2	t	f	\N	\N	f
109	Garge	XWMW	t	22	f	f	\N	\N	f
60	Anderson	XSKW	t	\N	t	f	\N	\N	f
86	Kenny	ZHXK	t	\N	f	f	\N	\N	f
15	Pitel	YSRN	t	\N	t	f	\N	\N	f
1	Pitel	MBWG	t	4	t	f	\N	\N	t
58	Fisher	CFJH	t	\N	t	f	\N	\N	f
57	Fisher	RTOE	t	\N	t	f	\N	\N	f
50	Calinski	XNNX	t	\N	t	f	\N	\N	f
49	Marych	XFKG	t	\N	t	f	\N	\N	f
17	Pitel	JVFF	t	\N	t	f	\N	\N	f
47	Pritchard	FGOZ	t	17	f	f	\N	\N	f
36	Wyles	BCQD	t	6	f	f	\N	\N	f
41	Saunders	YQVC	t	9	f	f	\N	\N	f
110	O'Connor	SOFF	t	\N	f	f	\N	\N	f
51	Gralak	FZBU	t	\N	t	f	\N	\N	f
34	Attwood	NISB	t	9	f	f	\N	\N	f
54	Little	ABKA	t	\N	f	f	\N	\N	f
52	Leczycki	IGBH	t	\N	t	f	\N	\N	f
13	Capocci-Hunt	FRGO	t	21	t	f	\N	\N	f
4	Masson	BMTD	t	14	t	f	\N	\N	f
12	Price-Dahlgren	HPLQ	t	11	f	f	\N	\N	f
14	Fox	BTLL	t	16	t	f	\N	\N	f
45	Fox	XQTY	t	\N	t	f	\N	\N	f
46	Finlay	MJRY	t	\N	t	f	\N	\N	f
44	Nicholson	CNJE	t	\N	f	f	\N	\N	f
42	Jordan	AKGN	t	10	f	f	\N	\N	f
5	Dunn	GNRA	t	12	t	f	\N	\N	f
20	Woolridge	CHNE	t	\N	f	f	\N	\N	f
19	Dunn	ULEM	t	\N	f	f	\N	\N	f
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."job_batches" ("id", "name", "total_jobs", "pending_jobs", "failed_jobs", "failed_job_ids", "options", "cancelled_at", "created_at", "finished_at") FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."jobs" ("id", "queue", "payload", "attempts", "reserved_at", "available_at", "created_at") FROM stdin;
1	default	{"uuid":"7b26b83f-e324-4fbb-943a-074570c5a085","displayName":"Closure (ContactController.php:18)","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"Illuminate\\\\Queue\\\\CallQueuedClosure","command":"O:34:\\"Illuminate\\\\Queue\\\\CallQueuedClosure\\":1:{s:7:\\"closure\\";O:47:\\"Laravel\\\\SerializableClosure\\\\SerializableClosure\\":1:{s:12:\\"serializable\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Signed\\":2:{s:12:\\"serializable\\";s:6840:\\"O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:5:\\"brevo\\";O:38:\\"App\\\\Services\\\\BrevoTransactionalService\\":1:{s:6:\\"\\u0000*\\u0000api\\";O:44:\\"SendinBlue\\\\Client\\\\Api\\\\TransactionalEmailsApi\\":3:{s:9:\\"\\u0000*\\u0000client\\";O:17:\\"GuzzleHttp\\\\Client\\":1:{s:25:\\"\\u0000GuzzleHttp\\\\Client\\u0000config\\";a:8:{s:7:\\"handler\\";O:23:\\"GuzzleHttp\\\\HandlerStack\\":3:{s:32:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000handler\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:35:\\"GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\":7:{s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:50;}s:50:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000selectTimeout\\";i:1;s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000active\\";i:0;s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000handles\\";a:0:{}s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000delays\\";a:0:{}s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000options\\";a:0:{}s:40:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000_mh\\";N;}s:4:\\"sync\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlHandler\\":1:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:3;}}}s:8:\\"function\\";s:285:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $sync): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options[\\\\GuzzleHttp\\\\RequestOptions::SYNCHRONOUS]) ? $default($request, $options) : $sync($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001ff0000000000000000\\";}s:9:\\"streaming\\";O:32:\\"GuzzleHttp\\\\Handler\\\\StreamHandler\\":1:{s:45:\\"\\u0000GuzzleHttp\\\\Handler\\\\StreamHandler\\u0000lastHeaders\\";a:0:{}}}s:8:\\"function\\";s:264:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $streaming): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options['stream']) ? $default($request, $options) : $streaming($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002010000000000000000\\";}s:30:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000stack\\";a:4:{i:0;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:1:{s:14:\\"bodySummarizer\\";N;}s:8:\\"function\\";s:839:\\"static function (callable $handler) use ($bodySummarizer): callable {\\n            return static function ($request, array $options) use ($handler, $bodySummarizer) {\\n                if (empty($options['http_errors'])) {\\n                    return $handler($request, $options);\\n                }\\n\\n                return $handler($request, $options)->then(\\n                    static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($request, $bodySummarizer) {\\n                        $code = $response->getStatusCode();\\n                        if ($code < 400) {\\n                            return $response;\\n                        }\\n                        throw \\\\GuzzleHttp\\\\Exception\\\\RequestException::create($request, $response, null, [], $bodySummarizer);\\n                    }\\n                );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002020000000000000000\\";}i:1;s:11:\\"http_errors\\";}i:1;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:144:\\"static function (callable $handler): \\\\GuzzleHttp\\\\RedirectMiddleware {\\n            return new \\\\GuzzleHttp\\\\RedirectMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002030000000000000000\\";}i:1;s:15:\\"allow_redirects\\";}i:2;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:1030:\\"static function (callable $handler): callable {\\n            return static function ($request, array $options) use ($handler) {\\n                if (empty($options['cookies'])) {\\n                    return $handler($request, $options);\\n                } elseif (!($options['cookies'] instanceof \\\\GuzzleHttp\\\\Cookie\\\\CookieJarInterface)) {\\n                    throw new \\\\InvalidArgumentException('cookies must be an instance of GuzzleHttp\\\\Cookie\\\\CookieJarInterface');\\n                }\\n                $cookieJar = $options['cookies'];\\n                $request = $cookieJar->withCookieHeader($request);\\n\\n                return $handler($request, $options)\\n                    ->then(\\n                        static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($cookieJar, $request): \\\\Psr\\\\Http\\\\Message\\\\ResponseInterface {\\n                            $cookieJar->extractCookies($request, $response);\\n\\n                            return $response;\\n                        }\\n                    );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002040000000000000000\\";}i:1;s:7:\\"cookies\\";}i:3;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:150:\\"static function (callable $handler): \\\\GuzzleHttp\\\\PrepareBodyMiddleware {\\n            return new \\\\GuzzleHttp\\\\PrepareBodyMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002050000000000000000\\";}i:1;s:12:\\"prepare_body\\";}}s:31:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000cached\\";N;}s:15:\\"allow_redirects\\";a:5:{s:3:\\"max\\";i:5;s:9:\\"protocols\\";a:2:{i:0;s:4:\\"http\\";i:1;s:5:\\"https\\";}s:6:\\"strict\\";b:0;s:7:\\"referer\\";b:0;s:15:\\"track_redirects\\";b:0;}s:11:\\"http_errors\\";b:1;s:14:\\"decode_content\\";b:1;s:6:\\"verify\\";b:1;s:7:\\"cookies\\";b:0;s:14:\\"idn_conversion\\";b:0;s:7:\\"headers\\";a:1:{s:10:\\"User-Agent\\";s:12:\\"GuzzleHttp\\/7\\";}}}s:9:\\"\\u0000*\\u0000config\\";O:31:\\"SendinBlue\\\\Client\\\\Configuration\\":10:{s:10:\\"\\u0000*\\u0000apiKeys\\";a:1:{s:7:\\"api-key\\";s:89:\\"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\\";}s:17:\\"\\u0000*\\u0000apiKeyPrefixes\\";a:0:{}s:14:\\"\\u0000*\\u0000accessToken\\";s:0:\\"\\";s:11:\\"\\u0000*\\u0000username\\";s:0:\\"\\";s:11:\\"\\u0000*\\u0000password\\";s:0:\\"\\";s:7:\\"\\u0000*\\u0000host\\";s:29:\\"https:\\/\\/api.sendinblue.com\\/v3\\";s:12:\\"\\u0000*\\u0000userAgent\\";s:31:\\"sendinblue_clientAPI\\/v8.4.2\\/php\\";s:8:\\"\\u0000*\\u0000debug\\";b:0;s:12:\\"\\u0000*\\u0000debugFile\\";s:12:\\"php:\\/\\/output\\";s:17:\\"\\u0000*\\u0000tempFolderPath\\";s:4:\\"\\/tmp\\";}s:17:\\"\\u0000*\\u0000headerSelector\\";O:32:\\"SendinBlue\\\\Client\\\\HeaderSelector\\":0:{}}}s:4:\\"data\\";a:3:{s:4:\\"name\\";s:24:\\"Freddy Pitel & David Fox\\";s:5:\\"email\\";s:13:\\"test@test.com\\";s:7:\\"message\\";s:26:\\"Main website comment test!\\";}}s:8:\\"function\\";s:90:\\"function () use ($brevo, $data) {\\n            $brevo->sendContactMessage($data);\\n        }\\";s:5:\\"scope\\";s:38:\\"App\\\\Http\\\\Controllers\\\\ContactController\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001f30000000000000000\\";}\\";s:4:\\"hash\\";s:44:\\"L0GSJZBx+ZPYobKzik3DcTBFcYKXzVgCE0JakSMeGik=\\";}}}","batchId":null},"createdAt":1774791002,"delay":null}	0	\N	1774791002	1774791002
2	default	{"uuid":"b8bd3c3b-475b-406e-aae5-d2890fa2a76d","displayName":"Closure (ContactController.php:18)","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"Illuminate\\\\Queue\\\\CallQueuedClosure","command":"O:34:\\"Illuminate\\\\Queue\\\\CallQueuedClosure\\":1:{s:7:\\"closure\\";O:47:\\"Laravel\\\\SerializableClosure\\\\SerializableClosure\\":1:{s:12:\\"serializable\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Signed\\":2:{s:12:\\"serializable\\";s:22468:\\"O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:5:\\"brevo\\";O:38:\\"App\\\\Services\\\\BrevoTransactionalService\\":1:{s:9:\\"\\u0000*\\u0000client\\";O:11:\\"Brevo\\\\Brevo\\":34:{s:7:\\"account\\";O:27:\\"Brevo\\\\Account\\\\AccountClient\\":2:{s:36:\\"\\u0000Brevo\\\\Account\\\\AccountClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Account\\\\AccountClient\\u0000client\\";O:27:\\"Brevo\\\\Core\\\\Client\\\\RawClient\\":6:{s:35:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000client\\";O:39:\\"Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\":4:{s:47:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000client\\";O:17:\\"GuzzleHttp\\\\Client\\":1:{s:25:\\"\\u0000GuzzleHttp\\\\Client\\u0000config\\";a:8:{s:7:\\"handler\\";O:23:\\"GuzzleHttp\\\\HandlerStack\\":3:{s:32:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000handler\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:35:\\"GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\":7:{s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:50;}s:50:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000selectTimeout\\";i:1;s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000active\\";i:0;s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000handles\\";a:0:{}s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000delays\\";a:0:{}s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000options\\";a:0:{}s:40:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000_mh\\";N;}s:4:\\"sync\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlHandler\\":1:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:3;}}}s:8:\\"function\\";s:285:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $sync): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options[\\\\GuzzleHttp\\\\RequestOptions::SYNCHRONOUS]) ? $default($request, $options) : $sync($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001ff0000000000000000\\";}s:9:\\"streaming\\";O:32:\\"GuzzleHttp\\\\Handler\\\\StreamHandler\\":1:{s:45:\\"\\u0000GuzzleHttp\\\\Handler\\\\StreamHandler\\u0000lastHeaders\\";a:0:{}}}s:8:\\"function\\";s:264:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $streaming): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options['stream']) ? $default($request, $options) : $streaming($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002010000000000000000\\";}s:30:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000stack\\";a:4:{i:0;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:1:{s:14:\\"bodySummarizer\\";N;}s:8:\\"function\\";s:839:\\"static function (callable $handler) use ($bodySummarizer): callable {\\n            return static function ($request, array $options) use ($handler, $bodySummarizer) {\\n                if (empty($options['http_errors'])) {\\n                    return $handler($request, $options);\\n                }\\n\\n                return $handler($request, $options)->then(\\n                    static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($request, $bodySummarizer) {\\n                        $code = $response->getStatusCode();\\n                        if ($code < 400) {\\n                            return $response;\\n                        }\\n                        throw \\\\GuzzleHttp\\\\Exception\\\\RequestException::create($request, $response, null, [], $bodySummarizer);\\n                    }\\n                );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002020000000000000000\\";}i:1;s:11:\\"http_errors\\";}i:1;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:144:\\"static function (callable $handler): \\\\GuzzleHttp\\\\RedirectMiddleware {\\n            return new \\\\GuzzleHttp\\\\RedirectMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002030000000000000000\\";}i:1;s:15:\\"allow_redirects\\";}i:2;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:1030:\\"static function (callable $handler): callable {\\n            return static function ($request, array $options) use ($handler) {\\n                if (empty($options['cookies'])) {\\n                    return $handler($request, $options);\\n                } elseif (!($options['cookies'] instanceof \\\\GuzzleHttp\\\\Cookie\\\\CookieJarInterface)) {\\n                    throw new \\\\InvalidArgumentException('cookies must be an instance of GuzzleHttp\\\\Cookie\\\\CookieJarInterface');\\n                }\\n                $cookieJar = $options['cookies'];\\n                $request = $cookieJar->withCookieHeader($request);\\n\\n                return $handler($request, $options)\\n                    ->then(\\n                        static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($cookieJar, $request): \\\\Psr\\\\Http\\\\Message\\\\ResponseInterface {\\n                            $cookieJar->extractCookies($request, $response);\\n\\n                            return $response;\\n                        }\\n                    );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002040000000000000000\\";}i:1;s:7:\\"cookies\\";}i:3;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:150:\\"static function (callable $handler): \\\\GuzzleHttp\\\\PrepareBodyMiddleware {\\n            return new \\\\GuzzleHttp\\\\PrepareBodyMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002050000000000000000\\";}i:1;s:12:\\"prepare_body\\";}}s:31:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000cached\\";N;}s:15:\\"allow_redirects\\";a:5:{s:3:\\"max\\";i:5;s:9:\\"protocols\\";a:2:{i:0;s:4:\\"http\\";i:1;s:5:\\"https\\";}s:6:\\"strict\\";b:0;s:7:\\"referer\\";b:0;s:15:\\"track_redirects\\";b:0;}s:11:\\"http_errors\\";b:1;s:14:\\"decode_content\\";b:1;s:6:\\"verify\\";b:1;s:7:\\"cookies\\";b:0;s:14:\\"idn_conversion\\";b:0;s:7:\\"headers\\";a:1:{s:10:\\"User-Agent\\";s:12:\\"GuzzleHttp\\/7\\";}}}s:51:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000maxRetries\\";i:2;s:50:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000baseDelay\\";i:1000;s:54:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000sleepFunction\\";s:6:\\"usleep\\";}s:43:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000requestFactory\\";O:27:\\"GuzzleHttp\\\\Psr7\\\\HttpFactory\\":0:{}s:42:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000streamFactory\\";O:27:\\"GuzzleHttp\\\\Psr7\\\\HttpFactory\\":0:{}s:36:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}s:43:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000getAuthHeaders\\";N;s:7:\\"options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}}}s:13:\\"masterAccount\\";O:39:\\"Brevo\\\\MasterAccount\\\\MasterAccountClient\\":2:{s:48:\\"\\u0000Brevo\\\\MasterAccount\\\\MasterAccountClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\MasterAccount\\\\MasterAccountClient\\u0000client\\";r:13;}s:4:\\"user\\";O:21:\\"Brevo\\\\User\\\\UserClient\\":2:{s:30:\\"\\u0000Brevo\\\\User\\\\UserClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:29:\\"\\u0000Brevo\\\\User\\\\UserClient\\u0000client\\";r:13;}s:7:\\"process\\";O:27:\\"Brevo\\\\Process\\\\ProcessClient\\":2:{s:36:\\"\\u0000Brevo\\\\Process\\\\ProcessClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Process\\\\ProcessClient\\u0000client\\";r:13;}s:7:\\"senders\\";O:27:\\"Brevo\\\\Senders\\\\SendersClient\\":2:{s:36:\\"\\u0000Brevo\\\\Senders\\\\SendersClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Senders\\\\SendersClient\\u0000client\\";r:13;}s:7:\\"domains\\";O:27:\\"Brevo\\\\Domains\\\\DomainsClient\\":2:{s:36:\\"\\u0000Brevo\\\\Domains\\\\DomainsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Domains\\\\DomainsClient\\u0000client\\";r:13;}s:8:\\"webhooks\\";O:29:\\"Brevo\\\\Webhooks\\\\WebhooksClient\\":2:{s:38:\\"\\u0000Brevo\\\\Webhooks\\\\WebhooksClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Webhooks\\\\WebhooksClient\\u0000client\\";r:13;}s:13:\\"externalFeeds\\";O:39:\\"Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\":2:{s:48:\\"\\u0000Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\u0000client\\";r:13;}s:13:\\"customObjects\\";O:39:\\"Brevo\\\\CustomObjects\\\\CustomObjectsClient\\":2:{s:48:\\"\\u0000Brevo\\\\CustomObjects\\\\CustomObjectsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\CustomObjects\\\\CustomObjectsClient\\u0000client\\";r:13;}s:8:\\"contacts\\";O:29:\\"Brevo\\\\Contacts\\\\ContactsClient\\":2:{s:38:\\"\\u0000Brevo\\\\Contacts\\\\ContactsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Contacts\\\\ContactsClient\\u0000client\\";r:13;}s:13:\\"conversations\\";O:39:\\"Brevo\\\\Conversations\\\\ConversationsClient\\":2:{s:48:\\"\\u0000Brevo\\\\Conversations\\\\ConversationsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\Conversations\\\\ConversationsClient\\u0000client\\";r:13;}s:9:\\"ecommerce\\";O:31:\\"Brevo\\\\Ecommerce\\\\EcommerceClient\\":2:{s:40:\\"\\u0000Brevo\\\\Ecommerce\\\\EcommerceClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:39:\\"\\u0000Brevo\\\\Ecommerce\\\\EcommerceClient\\u0000client\\";r:13;}s:7:\\"coupons\\";O:27:\\"Brevo\\\\Coupons\\\\CouponsClient\\":2:{s:36:\\"\\u0000Brevo\\\\Coupons\\\\CouponsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Coupons\\\\CouponsClient\\u0000client\\";r:13;}s:8:\\"payments\\";O:29:\\"Brevo\\\\Payments\\\\PaymentsClient\\":2:{s:38:\\"\\u0000Brevo\\\\Payments\\\\PaymentsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Payments\\\\PaymentsClient\\u0000client\\";r:13;}s:5:\\"event\\";O:23:\\"Brevo\\\\Event\\\\EventClient\\":2:{s:32:\\"\\u0000Brevo\\\\Event\\\\EventClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Event\\\\EventClient\\u0000client\\";r:13;}s:14:\\"inboundParsing\\";O:41:\\"Brevo\\\\InboundParsing\\\\InboundParsingClient\\":2:{s:50:\\"\\u0000Brevo\\\\InboundParsing\\\\InboundParsingClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:49:\\"\\u0000Brevo\\\\InboundParsing\\\\InboundParsingClient\\u0000client\\";r:13;}s:7:\\"balance\\";O:27:\\"Brevo\\\\Balance\\\\BalanceClient\\":2:{s:36:\\"\\u0000Brevo\\\\Balance\\\\BalanceClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Balance\\\\BalanceClient\\u0000client\\";r:13;}s:7:\\"program\\";O:27:\\"Brevo\\\\Program\\\\ProgramClient\\":2:{s:36:\\"\\u0000Brevo\\\\Program\\\\ProgramClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Program\\\\ProgramClient\\u0000client\\";r:13;}s:6:\\"reward\\";O:25:\\"Brevo\\\\Reward\\\\RewardClient\\":2:{s:34:\\"\\u0000Brevo\\\\Reward\\\\RewardClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:33:\\"\\u0000Brevo\\\\Reward\\\\RewardClient\\u0000client\\";r:13;}s:4:\\"tier\\";O:21:\\"Brevo\\\\Tier\\\\TierClient\\":2:{s:30:\\"\\u0000Brevo\\\\Tier\\\\TierClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:29:\\"\\u0000Brevo\\\\Tier\\\\TierClient\\u0000client\\";r:13;}s:14:\\"emailCampaigns\\";O:41:\\"Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\":2:{s:50:\\"\\u0000Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:49:\\"\\u0000Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\u0000client\\";r:13;}s:12:\\"smsCampaigns\\";O:37:\\"Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\":2:{s:46:\\"\\u0000Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:45:\\"\\u0000Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\u0000client\\";r:13;}s:17:\\"whatsAppCampaigns\\";O:47:\\"Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\":2:{s:56:\\"\\u0000Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:55:\\"\\u0000Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\u0000client\\";r:13;}s:9:\\"companies\\";O:31:\\"Brevo\\\\Companies\\\\CompaniesClient\\":2:{s:40:\\"\\u0000Brevo\\\\Companies\\\\CompaniesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:39:\\"\\u0000Brevo\\\\Companies\\\\CompaniesClient\\u0000client\\";r:13;}s:5:\\"deals\\";O:23:\\"Brevo\\\\Deals\\\\DealsClient\\":2:{s:32:\\"\\u0000Brevo\\\\Deals\\\\DealsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Deals\\\\DealsClient\\u0000client\\";r:13;}s:5:\\"files\\";O:23:\\"Brevo\\\\Files\\\\FilesClient\\":2:{s:32:\\"\\u0000Brevo\\\\Files\\\\FilesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Files\\\\FilesClient\\u0000client\\";r:13;}s:5:\\"notes\\";O:23:\\"Brevo\\\\Notes\\\\NotesClient\\":2:{s:32:\\"\\u0000Brevo\\\\Notes\\\\NotesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Notes\\\\NotesClient\\u0000client\\";r:13;}s:5:\\"tasks\\";O:23:\\"Brevo\\\\Tasks\\\\TasksClient\\":2:{s:32:\\"\\u0000Brevo\\\\Tasks\\\\TasksClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Tasks\\\\TasksClient\\u0000client\\";r:13;}s:21:\\"transactionalWhatsApp\\";O:55:\\"Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\":2:{s:64:\\"\\u0000Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:63:\\"\\u0000Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\u0000client\\";r:13;}s:19:\\"transactionalEmails\\";O:51:\\"Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\":2:{s:60:\\"\\u0000Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:59:\\"\\u0000Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\u0000client\\";r:13;}s:16:\\"transactionalSms\\";O:45:\\"Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\":2:{s:54:\\"\\u0000Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:53:\\"\\u0000Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\u0000client\\";r:13;}s:12:\\"smsTemplates\\";O:37:\\"Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\":2:{s:46:\\"\\u0000Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:45:\\"\\u0000Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\u0000client\\";r:13;}s:20:\\"\\u0000Brevo\\\\Brevo\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:19:\\"\\u0000Brevo\\\\Brevo\\u0000client\\";r:13;}}s:4:\\"data\\";a:3:{s:4:\\"name\\";s:24:\\"Freddy Pitel & David Fox\\";s:5:\\"email\\";s:16:\\"djwfox@gmail.com\\";s:7:\\"message\\";s:4:\\"Test\\";}}s:8:\\"function\\";s:90:\\"function () use ($brevo, $data) {\\n            $brevo->sendContactMessage($data);\\n        }\\";s:5:\\"scope\\";s:38:\\"App\\\\Http\\\\Controllers\\\\ContactController\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001f30000000000000000\\";}\\";s:4:\\"hash\\";s:44:\\"jA03I5E0qgT5TaoBboNEa63bj6z+wmoSJokgWyjNU44=\\";}}}","batchId":null},"createdAt":1774802751,"delay":null}	0	\N	1774802751	1774802751
3	default	{"uuid":"37ec9551-a1ca-4904-a465-b5b0d2d1fef6","displayName":"Closure (ContactController.php:18)","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"Illuminate\\\\Queue\\\\CallQueuedClosure","command":"O:34:\\"Illuminate\\\\Queue\\\\CallQueuedClosure\\":1:{s:7:\\"closure\\";O:47:\\"Laravel\\\\SerializableClosure\\\\SerializableClosure\\":1:{s:12:\\"serializable\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Signed\\":2:{s:12:\\"serializable\\";s:22577:\\"O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:5:\\"brevo\\";O:38:\\"App\\\\Services\\\\BrevoTransactionalService\\":1:{s:9:\\"\\u0000*\\u0000client\\";O:11:\\"Brevo\\\\Brevo\\":34:{s:7:\\"account\\";O:27:\\"Brevo\\\\Account\\\\AccountClient\\":2:{s:36:\\"\\u0000Brevo\\\\Account\\\\AccountClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Account\\\\AccountClient\\u0000client\\";O:27:\\"Brevo\\\\Core\\\\Client\\\\RawClient\\":6:{s:35:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000client\\";O:39:\\"Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\":4:{s:47:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000client\\";O:17:\\"GuzzleHttp\\\\Client\\":1:{s:25:\\"\\u0000GuzzleHttp\\\\Client\\u0000config\\";a:8:{s:7:\\"handler\\";O:23:\\"GuzzleHttp\\\\HandlerStack\\":3:{s:32:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000handler\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:35:\\"GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\":7:{s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:50;}s:50:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000selectTimeout\\";i:1;s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000active\\";i:0;s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000handles\\";a:0:{}s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000delays\\";a:0:{}s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000options\\";a:0:{}s:40:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000_mh\\";N;}s:4:\\"sync\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlHandler\\":1:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:3;}}}s:8:\\"function\\";s:285:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $sync): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options[\\\\GuzzleHttp\\\\RequestOptions::SYNCHRONOUS]) ? $default($request, $options) : $sync($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001ff0000000000000000\\";}s:9:\\"streaming\\";O:32:\\"GuzzleHttp\\\\Handler\\\\StreamHandler\\":1:{s:45:\\"\\u0000GuzzleHttp\\\\Handler\\\\StreamHandler\\u0000lastHeaders\\";a:0:{}}}s:8:\\"function\\";s:264:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $streaming): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options['stream']) ? $default($request, $options) : $streaming($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002010000000000000000\\";}s:30:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000stack\\";a:4:{i:0;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:1:{s:14:\\"bodySummarizer\\";N;}s:8:\\"function\\";s:839:\\"static function (callable $handler) use ($bodySummarizer): callable {\\n            return static function ($request, array $options) use ($handler, $bodySummarizer) {\\n                if (empty($options['http_errors'])) {\\n                    return $handler($request, $options);\\n                }\\n\\n                return $handler($request, $options)->then(\\n                    static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($request, $bodySummarizer) {\\n                        $code = $response->getStatusCode();\\n                        if ($code < 400) {\\n                            return $response;\\n                        }\\n                        throw \\\\GuzzleHttp\\\\Exception\\\\RequestException::create($request, $response, null, [], $bodySummarizer);\\n                    }\\n                );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002020000000000000000\\";}i:1;s:11:\\"http_errors\\";}i:1;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:144:\\"static function (callable $handler): \\\\GuzzleHttp\\\\RedirectMiddleware {\\n            return new \\\\GuzzleHttp\\\\RedirectMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002030000000000000000\\";}i:1;s:15:\\"allow_redirects\\";}i:2;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:1030:\\"static function (callable $handler): callable {\\n            return static function ($request, array $options) use ($handler) {\\n                if (empty($options['cookies'])) {\\n                    return $handler($request, $options);\\n                } elseif (!($options['cookies'] instanceof \\\\GuzzleHttp\\\\Cookie\\\\CookieJarInterface)) {\\n                    throw new \\\\InvalidArgumentException('cookies must be an instance of GuzzleHttp\\\\Cookie\\\\CookieJarInterface');\\n                }\\n                $cookieJar = $options['cookies'];\\n                $request = $cookieJar->withCookieHeader($request);\\n\\n                return $handler($request, $options)\\n                    ->then(\\n                        static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($cookieJar, $request): \\\\Psr\\\\Http\\\\Message\\\\ResponseInterface {\\n                            $cookieJar->extractCookies($request, $response);\\n\\n                            return $response;\\n                        }\\n                    );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002040000000000000000\\";}i:1;s:7:\\"cookies\\";}i:3;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:150:\\"static function (callable $handler): \\\\GuzzleHttp\\\\PrepareBodyMiddleware {\\n            return new \\\\GuzzleHttp\\\\PrepareBodyMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002050000000000000000\\";}i:1;s:12:\\"prepare_body\\";}}s:31:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000cached\\";N;}s:15:\\"allow_redirects\\";a:5:{s:3:\\"max\\";i:5;s:9:\\"protocols\\";a:2:{i:0;s:4:\\"http\\";i:1;s:5:\\"https\\";}s:6:\\"strict\\";b:0;s:7:\\"referer\\";b:0;s:15:\\"track_redirects\\";b:0;}s:11:\\"http_errors\\";b:1;s:14:\\"decode_content\\";b:1;s:6:\\"verify\\";b:1;s:7:\\"cookies\\";b:0;s:14:\\"idn_conversion\\";b:0;s:7:\\"headers\\";a:1:{s:10:\\"User-Agent\\";s:12:\\"GuzzleHttp\\/7\\";}}}s:51:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000maxRetries\\";i:2;s:50:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000baseDelay\\";i:1000;s:54:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000sleepFunction\\";s:6:\\"usleep\\";}s:43:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000requestFactory\\";O:27:\\"GuzzleHttp\\\\Psr7\\\\HttpFactory\\":0:{}s:42:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000streamFactory\\";O:27:\\"GuzzleHttp\\\\Psr7\\\\HttpFactory\\":0:{}s:36:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}s:43:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000getAuthHeaders\\";N;s:7:\\"options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}}}s:13:\\"masterAccount\\";O:39:\\"Brevo\\\\MasterAccount\\\\MasterAccountClient\\":2:{s:48:\\"\\u0000Brevo\\\\MasterAccount\\\\MasterAccountClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\MasterAccount\\\\MasterAccountClient\\u0000client\\";r:13;}s:4:\\"user\\";O:21:\\"Brevo\\\\User\\\\UserClient\\":2:{s:30:\\"\\u0000Brevo\\\\User\\\\UserClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:29:\\"\\u0000Brevo\\\\User\\\\UserClient\\u0000client\\";r:13;}s:7:\\"process\\";O:27:\\"Brevo\\\\Process\\\\ProcessClient\\":2:{s:36:\\"\\u0000Brevo\\\\Process\\\\ProcessClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Process\\\\ProcessClient\\u0000client\\";r:13;}s:7:\\"senders\\";O:27:\\"Brevo\\\\Senders\\\\SendersClient\\":2:{s:36:\\"\\u0000Brevo\\\\Senders\\\\SendersClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Senders\\\\SendersClient\\u0000client\\";r:13;}s:7:\\"domains\\";O:27:\\"Brevo\\\\Domains\\\\DomainsClient\\":2:{s:36:\\"\\u0000Brevo\\\\Domains\\\\DomainsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Domains\\\\DomainsClient\\u0000client\\";r:13;}s:8:\\"webhooks\\";O:29:\\"Brevo\\\\Webhooks\\\\WebhooksClient\\":2:{s:38:\\"\\u0000Brevo\\\\Webhooks\\\\WebhooksClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Webhooks\\\\WebhooksClient\\u0000client\\";r:13;}s:13:\\"externalFeeds\\";O:39:\\"Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\":2:{s:48:\\"\\u0000Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\u0000client\\";r:13;}s:13:\\"customObjects\\";O:39:\\"Brevo\\\\CustomObjects\\\\CustomObjectsClient\\":2:{s:48:\\"\\u0000Brevo\\\\CustomObjects\\\\CustomObjectsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\CustomObjects\\\\CustomObjectsClient\\u0000client\\";r:13;}s:8:\\"contacts\\";O:29:\\"Brevo\\\\Contacts\\\\ContactsClient\\":2:{s:38:\\"\\u0000Brevo\\\\Contacts\\\\ContactsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Contacts\\\\ContactsClient\\u0000client\\";r:13;}s:13:\\"conversations\\";O:39:\\"Brevo\\\\Conversations\\\\ConversationsClient\\":2:{s:48:\\"\\u0000Brevo\\\\Conversations\\\\ConversationsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\Conversations\\\\ConversationsClient\\u0000client\\";r:13;}s:9:\\"ecommerce\\";O:31:\\"Brevo\\\\Ecommerce\\\\EcommerceClient\\":2:{s:40:\\"\\u0000Brevo\\\\Ecommerce\\\\EcommerceClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:39:\\"\\u0000Brevo\\\\Ecommerce\\\\EcommerceClient\\u0000client\\";r:13;}s:7:\\"coupons\\";O:27:\\"Brevo\\\\Coupons\\\\CouponsClient\\":2:{s:36:\\"\\u0000Brevo\\\\Coupons\\\\CouponsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Coupons\\\\CouponsClient\\u0000client\\";r:13;}s:8:\\"payments\\";O:29:\\"Brevo\\\\Payments\\\\PaymentsClient\\":2:{s:38:\\"\\u0000Brevo\\\\Payments\\\\PaymentsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Payments\\\\PaymentsClient\\u0000client\\";r:13;}s:5:\\"event\\";O:23:\\"Brevo\\\\Event\\\\EventClient\\":2:{s:32:\\"\\u0000Brevo\\\\Event\\\\EventClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Event\\\\EventClient\\u0000client\\";r:13;}s:14:\\"inboundParsing\\";O:41:\\"Brevo\\\\InboundParsing\\\\InboundParsingClient\\":2:{s:50:\\"\\u0000Brevo\\\\InboundParsing\\\\InboundParsingClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:49:\\"\\u0000Brevo\\\\InboundParsing\\\\InboundParsingClient\\u0000client\\";r:13;}s:7:\\"balance\\";O:27:\\"Brevo\\\\Balance\\\\BalanceClient\\":2:{s:36:\\"\\u0000Brevo\\\\Balance\\\\BalanceClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Balance\\\\BalanceClient\\u0000client\\";r:13;}s:7:\\"program\\";O:27:\\"Brevo\\\\Program\\\\ProgramClient\\":2:{s:36:\\"\\u0000Brevo\\\\Program\\\\ProgramClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Program\\\\ProgramClient\\u0000client\\";r:13;}s:6:\\"reward\\";O:25:\\"Brevo\\\\Reward\\\\RewardClient\\":2:{s:34:\\"\\u0000Brevo\\\\Reward\\\\RewardClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:33:\\"\\u0000Brevo\\\\Reward\\\\RewardClient\\u0000client\\";r:13;}s:4:\\"tier\\";O:21:\\"Brevo\\\\Tier\\\\TierClient\\":2:{s:30:\\"\\u0000Brevo\\\\Tier\\\\TierClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:29:\\"\\u0000Brevo\\\\Tier\\\\TierClient\\u0000client\\";r:13;}s:14:\\"emailCampaigns\\";O:41:\\"Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\":2:{s:50:\\"\\u0000Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:49:\\"\\u0000Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\u0000client\\";r:13;}s:12:\\"smsCampaigns\\";O:37:\\"Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\":2:{s:46:\\"\\u0000Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:45:\\"\\u0000Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\u0000client\\";r:13;}s:17:\\"whatsAppCampaigns\\";O:47:\\"Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\":2:{s:56:\\"\\u0000Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:55:\\"\\u0000Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\u0000client\\";r:13;}s:9:\\"companies\\";O:31:\\"Brevo\\\\Companies\\\\CompaniesClient\\":2:{s:40:\\"\\u0000Brevo\\\\Companies\\\\CompaniesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:39:\\"\\u0000Brevo\\\\Companies\\\\CompaniesClient\\u0000client\\";r:13;}s:5:\\"deals\\";O:23:\\"Brevo\\\\Deals\\\\DealsClient\\":2:{s:32:\\"\\u0000Brevo\\\\Deals\\\\DealsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Deals\\\\DealsClient\\u0000client\\";r:13;}s:5:\\"files\\";O:23:\\"Brevo\\\\Files\\\\FilesClient\\":2:{s:32:\\"\\u0000Brevo\\\\Files\\\\FilesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Files\\\\FilesClient\\u0000client\\";r:13;}s:5:\\"notes\\";O:23:\\"Brevo\\\\Notes\\\\NotesClient\\":2:{s:32:\\"\\u0000Brevo\\\\Notes\\\\NotesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Notes\\\\NotesClient\\u0000client\\";r:13;}s:5:\\"tasks\\";O:23:\\"Brevo\\\\Tasks\\\\TasksClient\\":2:{s:32:\\"\\u0000Brevo\\\\Tasks\\\\TasksClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Tasks\\\\TasksClient\\u0000client\\";r:13;}s:21:\\"transactionalWhatsApp\\";O:55:\\"Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\":2:{s:64:\\"\\u0000Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:63:\\"\\u0000Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\u0000client\\";r:13;}s:19:\\"transactionalEmails\\";O:51:\\"Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\":2:{s:60:\\"\\u0000Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:59:\\"\\u0000Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\u0000client\\";r:13;}s:16:\\"transactionalSms\\";O:45:\\"Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\":2:{s:54:\\"\\u0000Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:53:\\"\\u0000Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\u0000client\\";r:13;}s:12:\\"smsTemplates\\";O:37:\\"Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\":2:{s:46:\\"\\u0000Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:45:\\"\\u0000Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\u0000client\\";r:13;}s:20:\\"\\u0000Brevo\\\\Brevo\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:19:\\"\\u0000Brevo\\\\Brevo\\u0000client\\";r:13;}}s:4:\\"data\\";a:3:{s:4:\\"name\\";s:25:\\"Mark Fisher & Sara Fisher\\";s:5:\\"email\\";s:24:\\"thefishers5725@gmail.com\\";s:7:\\"message\\";s:102:\\"There once was a man from Peru,\\r\\nWhose limericks end on line two!\\r\\n\\r\\nThere once was a man from Verdun.\\";}}s:8:\\"function\\";s:90:\\"function () use ($brevo, $data) {\\n            $brevo->sendContactMessage($data);\\n        }\\";s:5:\\"scope\\";s:38:\\"App\\\\Http\\\\Controllers\\\\ContactController\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001f30000000000000000\\";}\\";s:4:\\"hash\\";s:44:\\"zNIoK667vJV2dMAagJXXuxd0zc0tyzQWbPIJlcRoBqw=\\";}}}","batchId":null},"createdAt":1774803182,"delay":null}	0	\N	1774803182	1774803182
4	default	{"uuid":"aacc74eb-8e75-44f5-8095-ed485277a7ed","displayName":"Closure (ContactController.php:18)","job":"Illuminate\\\\Queue\\\\CallQueuedHandler@call","maxTries":null,"maxExceptions":null,"failOnTimeout":false,"backoff":null,"timeout":null,"retryUntil":null,"data":{"commandName":"Illuminate\\\\Queue\\\\CallQueuedClosure","command":"O:34:\\"Illuminate\\\\Queue\\\\CallQueuedClosure\\":1:{s:7:\\"closure\\";O:47:\\"Laravel\\\\SerializableClosure\\\\SerializableClosure\\":1:{s:12:\\"serializable\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Signed\\":2:{s:12:\\"serializable\\";s:22472:\\"O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:5:\\"brevo\\";O:38:\\"App\\\\Services\\\\BrevoTransactionalService\\":1:{s:9:\\"\\u0000*\\u0000client\\";O:11:\\"Brevo\\\\Brevo\\":34:{s:7:\\"account\\";O:27:\\"Brevo\\\\Account\\\\AccountClient\\":2:{s:36:\\"\\u0000Brevo\\\\Account\\\\AccountClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Account\\\\AccountClient\\u0000client\\";O:27:\\"Brevo\\\\Core\\\\Client\\\\RawClient\\":6:{s:35:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000client\\";O:39:\\"Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\":4:{s:47:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000client\\";O:17:\\"GuzzleHttp\\\\Client\\":1:{s:25:\\"\\u0000GuzzleHttp\\\\Client\\u0000config\\";a:8:{s:7:\\"handler\\";O:23:\\"GuzzleHttp\\\\HandlerStack\\":3:{s:32:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000handler\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:2:{s:7:\\"default\\";O:35:\\"GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\":7:{s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:50;}s:50:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000selectTimeout\\";i:1;s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000active\\";i:0;s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000handles\\";a:0:{}s:43:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000delays\\";a:0:{}s:44:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000options\\";a:0:{}s:40:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlMultiHandler\\u0000_mh\\";N;}s:4:\\"sync\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlHandler\\":1:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlHandler\\u0000factory\\";O:30:\\"GuzzleHttp\\\\Handler\\\\CurlFactory\\":2:{s:39:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000handles\\";a:0:{}s:42:\\"\\u0000GuzzleHttp\\\\Handler\\\\CurlFactory\\u0000maxHandles\\";i:3;}}}s:8:\\"function\\";s:285:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $sync): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options[\\\\GuzzleHttp\\\\RequestOptions::SYNCHRONOUS]) ? $default($request, $options) : $sync($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001ff0000000000000000\\";}s:9:\\"streaming\\";O:32:\\"GuzzleHttp\\\\Handler\\\\StreamHandler\\":1:{s:45:\\"\\u0000GuzzleHttp\\\\Handler\\\\StreamHandler\\u0000lastHeaders\\";a:0:{}}}s:8:\\"function\\";s:264:\\"static function (\\\\Psr\\\\Http\\\\Message\\\\RequestInterface $request, array $options) use ($default, $streaming): \\\\GuzzleHttp\\\\Promise\\\\PromiseInterface {\\n            return empty($options['stream']) ? $default($request, $options) : $streaming($request, $options);\\n        }\\";s:5:\\"scope\\";s:24:\\"GuzzleHttp\\\\Handler\\\\Proxy\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002010000000000000000\\";}s:30:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000stack\\";a:4:{i:0;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:1:{s:14:\\"bodySummarizer\\";N;}s:8:\\"function\\";s:839:\\"static function (callable $handler) use ($bodySummarizer): callable {\\n            return static function ($request, array $options) use ($handler, $bodySummarizer) {\\n                if (empty($options['http_errors'])) {\\n                    return $handler($request, $options);\\n                }\\n\\n                return $handler($request, $options)->then(\\n                    static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($request, $bodySummarizer) {\\n                        $code = $response->getStatusCode();\\n                        if ($code < 400) {\\n                            return $response;\\n                        }\\n                        throw \\\\GuzzleHttp\\\\Exception\\\\RequestException::create($request, $response, null, [], $bodySummarizer);\\n                    }\\n                );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002020000000000000000\\";}i:1;s:11:\\"http_errors\\";}i:1;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:144:\\"static function (callable $handler): \\\\GuzzleHttp\\\\RedirectMiddleware {\\n            return new \\\\GuzzleHttp\\\\RedirectMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002030000000000000000\\";}i:1;s:15:\\"allow_redirects\\";}i:2;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:1030:\\"static function (callable $handler): callable {\\n            return static function ($request, array $options) use ($handler) {\\n                if (empty($options['cookies'])) {\\n                    return $handler($request, $options);\\n                } elseif (!($options['cookies'] instanceof \\\\GuzzleHttp\\\\Cookie\\\\CookieJarInterface)) {\\n                    throw new \\\\InvalidArgumentException('cookies must be an instance of GuzzleHttp\\\\Cookie\\\\CookieJarInterface');\\n                }\\n                $cookieJar = $options['cookies'];\\n                $request = $cookieJar->withCookieHeader($request);\\n\\n                return $handler($request, $options)\\n                    ->then(\\n                        static function (\\\\Psr\\\\Http\\\\Message\\\\ResponseInterface $response) use ($cookieJar, $request): \\\\Psr\\\\Http\\\\Message\\\\ResponseInterface {\\n                            $cookieJar->extractCookies($request, $response);\\n\\n                            return $response;\\n                        }\\n                    );\\n            };\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002040000000000000000\\";}i:1;s:7:\\"cookies\\";}i:3;a:2:{i:0;O:46:\\"Laravel\\\\SerializableClosure\\\\Serializers\\\\Native\\":5:{s:3:\\"use\\";a:0:{}s:8:\\"function\\";s:150:\\"static function (callable $handler): \\\\GuzzleHttp\\\\PrepareBodyMiddleware {\\n            return new \\\\GuzzleHttp\\\\PrepareBodyMiddleware($handler);\\n        }\\";s:5:\\"scope\\";s:21:\\"GuzzleHttp\\\\Middleware\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000002050000000000000000\\";}i:1;s:12:\\"prepare_body\\";}}s:31:\\"\\u0000GuzzleHttp\\\\HandlerStack\\u0000cached\\";N;}s:15:\\"allow_redirects\\";a:5:{s:3:\\"max\\";i:5;s:9:\\"protocols\\";a:2:{i:0;s:4:\\"http\\";i:1;s:5:\\"https\\";}s:6:\\"strict\\";b:0;s:7:\\"referer\\";b:0;s:15:\\"track_redirects\\";b:0;}s:11:\\"http_errors\\";b:1;s:14:\\"decode_content\\";b:1;s:6:\\"verify\\";b:1;s:7:\\"cookies\\";b:0;s:14:\\"idn_conversion\\";b:0;s:7:\\"headers\\";a:1:{s:10:\\"User-Agent\\";s:12:\\"GuzzleHttp\\/7\\";}}}s:51:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000maxRetries\\";i:2;s:50:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000baseDelay\\";i:1000;s:54:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RetryDecoratingClient\\u0000sleepFunction\\";s:6:\\"usleep\\";}s:43:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000requestFactory\\";O:27:\\"GuzzleHttp\\\\Psr7\\\\HttpFactory\\":0:{}s:42:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000streamFactory\\";O:27:\\"GuzzleHttp\\\\Psr7\\\\HttpFactory\\":0:{}s:36:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}s:43:\\"\\u0000Brevo\\\\Core\\\\Client\\\\RawClient\\u0000getAuthHeaders\\";N;s:7:\\"options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}}}s:13:\\"masterAccount\\";O:39:\\"Brevo\\\\MasterAccount\\\\MasterAccountClient\\":2:{s:48:\\"\\u0000Brevo\\\\MasterAccount\\\\MasterAccountClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\MasterAccount\\\\MasterAccountClient\\u0000client\\";r:13;}s:4:\\"user\\";O:21:\\"Brevo\\\\User\\\\UserClient\\":2:{s:30:\\"\\u0000Brevo\\\\User\\\\UserClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:29:\\"\\u0000Brevo\\\\User\\\\UserClient\\u0000client\\";r:13;}s:7:\\"process\\";O:27:\\"Brevo\\\\Process\\\\ProcessClient\\":2:{s:36:\\"\\u0000Brevo\\\\Process\\\\ProcessClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Process\\\\ProcessClient\\u0000client\\";r:13;}s:7:\\"senders\\";O:27:\\"Brevo\\\\Senders\\\\SendersClient\\":2:{s:36:\\"\\u0000Brevo\\\\Senders\\\\SendersClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Senders\\\\SendersClient\\u0000client\\";r:13;}s:7:\\"domains\\";O:27:\\"Brevo\\\\Domains\\\\DomainsClient\\":2:{s:36:\\"\\u0000Brevo\\\\Domains\\\\DomainsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Domains\\\\DomainsClient\\u0000client\\";r:13;}s:8:\\"webhooks\\";O:29:\\"Brevo\\\\Webhooks\\\\WebhooksClient\\":2:{s:38:\\"\\u0000Brevo\\\\Webhooks\\\\WebhooksClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Webhooks\\\\WebhooksClient\\u0000client\\";r:13;}s:13:\\"externalFeeds\\";O:39:\\"Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\":2:{s:48:\\"\\u0000Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\ExternalFeeds\\\\ExternalFeedsClient\\u0000client\\";r:13;}s:13:\\"customObjects\\";O:39:\\"Brevo\\\\CustomObjects\\\\CustomObjectsClient\\":2:{s:48:\\"\\u0000Brevo\\\\CustomObjects\\\\CustomObjectsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\CustomObjects\\\\CustomObjectsClient\\u0000client\\";r:13;}s:8:\\"contacts\\";O:29:\\"Brevo\\\\Contacts\\\\ContactsClient\\":2:{s:38:\\"\\u0000Brevo\\\\Contacts\\\\ContactsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Contacts\\\\ContactsClient\\u0000client\\";r:13;}s:13:\\"conversations\\";O:39:\\"Brevo\\\\Conversations\\\\ConversationsClient\\":2:{s:48:\\"\\u0000Brevo\\\\Conversations\\\\ConversationsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:47:\\"\\u0000Brevo\\\\Conversations\\\\ConversationsClient\\u0000client\\";r:13;}s:9:\\"ecommerce\\";O:31:\\"Brevo\\\\Ecommerce\\\\EcommerceClient\\":2:{s:40:\\"\\u0000Brevo\\\\Ecommerce\\\\EcommerceClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:39:\\"\\u0000Brevo\\\\Ecommerce\\\\EcommerceClient\\u0000client\\";r:13;}s:7:\\"coupons\\";O:27:\\"Brevo\\\\Coupons\\\\CouponsClient\\":2:{s:36:\\"\\u0000Brevo\\\\Coupons\\\\CouponsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Coupons\\\\CouponsClient\\u0000client\\";r:13;}s:8:\\"payments\\";O:29:\\"Brevo\\\\Payments\\\\PaymentsClient\\":2:{s:38:\\"\\u0000Brevo\\\\Payments\\\\PaymentsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:37:\\"\\u0000Brevo\\\\Payments\\\\PaymentsClient\\u0000client\\";r:13;}s:5:\\"event\\";O:23:\\"Brevo\\\\Event\\\\EventClient\\":2:{s:32:\\"\\u0000Brevo\\\\Event\\\\EventClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Event\\\\EventClient\\u0000client\\";r:13;}s:14:\\"inboundParsing\\";O:41:\\"Brevo\\\\InboundParsing\\\\InboundParsingClient\\":2:{s:50:\\"\\u0000Brevo\\\\InboundParsing\\\\InboundParsingClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:49:\\"\\u0000Brevo\\\\InboundParsing\\\\InboundParsingClient\\u0000client\\";r:13;}s:7:\\"balance\\";O:27:\\"Brevo\\\\Balance\\\\BalanceClient\\":2:{s:36:\\"\\u0000Brevo\\\\Balance\\\\BalanceClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Balance\\\\BalanceClient\\u0000client\\";r:13;}s:7:\\"program\\";O:27:\\"Brevo\\\\Program\\\\ProgramClient\\":2:{s:36:\\"\\u0000Brevo\\\\Program\\\\ProgramClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:35:\\"\\u0000Brevo\\\\Program\\\\ProgramClient\\u0000client\\";r:13;}s:6:\\"reward\\";O:25:\\"Brevo\\\\Reward\\\\RewardClient\\":2:{s:34:\\"\\u0000Brevo\\\\Reward\\\\RewardClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:33:\\"\\u0000Brevo\\\\Reward\\\\RewardClient\\u0000client\\";r:13;}s:4:\\"tier\\";O:21:\\"Brevo\\\\Tier\\\\TierClient\\":2:{s:30:\\"\\u0000Brevo\\\\Tier\\\\TierClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:29:\\"\\u0000Brevo\\\\Tier\\\\TierClient\\u0000client\\";r:13;}s:14:\\"emailCampaigns\\";O:41:\\"Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\":2:{s:50:\\"\\u0000Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:49:\\"\\u0000Brevo\\\\EmailCampaigns\\\\EmailCampaignsClient\\u0000client\\";r:13;}s:12:\\"smsCampaigns\\";O:37:\\"Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\":2:{s:46:\\"\\u0000Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:45:\\"\\u0000Brevo\\\\SmsCampaigns\\\\SmsCampaignsClient\\u0000client\\";r:13;}s:17:\\"whatsAppCampaigns\\";O:47:\\"Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\":2:{s:56:\\"\\u0000Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:55:\\"\\u0000Brevo\\\\WhatsAppCampaigns\\\\WhatsAppCampaignsClient\\u0000client\\";r:13;}s:9:\\"companies\\";O:31:\\"Brevo\\\\Companies\\\\CompaniesClient\\":2:{s:40:\\"\\u0000Brevo\\\\Companies\\\\CompaniesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:39:\\"\\u0000Brevo\\\\Companies\\\\CompaniesClient\\u0000client\\";r:13;}s:5:\\"deals\\";O:23:\\"Brevo\\\\Deals\\\\DealsClient\\":2:{s:32:\\"\\u0000Brevo\\\\Deals\\\\DealsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Deals\\\\DealsClient\\u0000client\\";r:13;}s:5:\\"files\\";O:23:\\"Brevo\\\\Files\\\\FilesClient\\":2:{s:32:\\"\\u0000Brevo\\\\Files\\\\FilesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Files\\\\FilesClient\\u0000client\\";r:13;}s:5:\\"notes\\";O:23:\\"Brevo\\\\Notes\\\\NotesClient\\":2:{s:32:\\"\\u0000Brevo\\\\Notes\\\\NotesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Notes\\\\NotesClient\\u0000client\\";r:13;}s:5:\\"tasks\\";O:23:\\"Brevo\\\\Tasks\\\\TasksClient\\":2:{s:32:\\"\\u0000Brevo\\\\Tasks\\\\TasksClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:31:\\"\\u0000Brevo\\\\Tasks\\\\TasksClient\\u0000client\\";r:13;}s:21:\\"transactionalWhatsApp\\";O:55:\\"Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\":2:{s:64:\\"\\u0000Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:63:\\"\\u0000Brevo\\\\TransactionalWhatsApp\\\\TransactionalWhatsAppClient\\u0000client\\";r:13;}s:19:\\"transactionalEmails\\";O:51:\\"Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\":2:{s:60:\\"\\u0000Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:59:\\"\\u0000Brevo\\\\TransactionalEmails\\\\TransactionalEmailsClient\\u0000client\\";r:13;}s:16:\\"transactionalSms\\";O:45:\\"Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\":2:{s:54:\\"\\u0000Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:53:\\"\\u0000Brevo\\\\TransactionalSms\\\\TransactionalSmsClient\\u0000client\\";r:13;}s:12:\\"smsTemplates\\";O:37:\\"Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\":2:{s:46:\\"\\u0000Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:45:\\"\\u0000Brevo\\\\SmsTemplates\\\\SmsTemplatesClient\\u0000client\\";r:13;}s:20:\\"\\u0000Brevo\\\\Brevo\\u0000options\\";a:1:{s:7:\\"headers\\";a:5:{s:7:\\"api-key\\";s:89:\\"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\\";s:15:\\"X-Fern-Language\\";s:3:\\"PHP\\";s:15:\\"X-Fern-SDK-Name\\";s:5:\\"Brevo\\";s:18:\\"X-Fern-SDK-Version\\";s:6:\\"4.0.12\\";s:10:\\"User-Agent\\";s:25:\\"getbrevo\\/brevo-php\\/4.0.12\\";}}s:19:\\"\\u0000Brevo\\\\Brevo\\u0000client\\";r:13;}}s:4:\\"data\\";a:3:{s:4:\\"name\\";s:24:\\"Freddy Pitel & David Fox\\";s:5:\\"email\\";s:16:\\"djwfox@gmail.com\\";s:7:\\"message\\";s:8:\\"Ho there\\";}}s:8:\\"function\\";s:90:\\"function () use ($brevo, $data) {\\n            $brevo->sendContactMessage($data);\\n        }\\";s:5:\\"scope\\";s:38:\\"App\\\\Http\\\\Controllers\\\\ContactController\\";s:4:\\"this\\";N;s:4:\\"self\\";s:32:\\"00000000000001f30000000000000000\\";}\\";s:4:\\"hash\\";s:44:\\"bGVx798lmcrbB5uNKqwgekSIbMnM9D012+3vr3NrsKQ=\\";}}}","batchId":null},"createdAt":1774806096,"delay":null}	0	\N	1774806096	1774806096
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."migrations" ("id", "migration", "batch") FROM stdin;
1	0001_01_01_000000_create_users_table	1
2	0001_01_01_000001_create_cache_table	1
3	0001_01_01_000002_create_jobs_table	1
4	2025_07_01_154723_create_guests_table	1
5	2025_07_01_173029_create_households_table	1
6	2025_12_26_095436_add-to-guests	2
7	2025_12_26_102608_accommodation	2
8	2025_12_26_120051_household_accommodation	2
9	2025_12_26_160339_add-to-guests-orig-name	2
10	2025_12_26_162014_add-to-households-extra-invites	2
11	2025_12_26_163747_add-to-guests-extra-invites	2
12	2025_12_26_215338_create_food_choices	2
13	2026_02_27_175928_add_coach_house_column	3
14	2026_04_04_215429_create_personal_access_tokens_table	4
15	2026_04_04_215748_create_train_configs_table	4
16	2026_04_04_215946_create_train_jokes_table	4
17	2026_04_04_220006_create_train_affirmations_table	4
18	2026_04_04_220012_create_train_events_table	4
19	2026_04_04_220020_create_train_slideshows_table	4
20	2026_04_04_220024_create_train_gifs_table	4
21	2026_04_04_220056_create_train_secrets_table	4
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."password_reset_tokens" ("email", "token", "created_at") FROM stdin;
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."personal_access_tokens" ("id", "tokenable_type", "tokenable_id", "name", "token", "abilities", "last_used_at", "expires_at", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."sessions" ("id", "user_id", "ip_address", "user_agent", "payload", "last_activity") FROM stdin;
3PfX1MpSTx9Jlr529bdeSv0MeKpruz2GNnIwIvGa	\N	192.253.248.169	Mozilla/5.0 (Linux; U; Android 4.2.2; es-es; Micromax A47 Build/JDQ39) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSWZtTVcyZ3NrV1NNS3p0YTd0MXBveERRQkpUT1RkMXZWcFR5b3FhTCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS8/cGhwaW5mbz0tMSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778292144
vUfu0XcDxtq5UO2E24LvIqfp94aOtqEim444lSgD	\N	8.216.14.239	curl/7.64.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiR1VLTGhqSnROMU5JeTlTNm4zVXlmbFA2cnllM3ViZGZrd2hkSHNGcSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778303880
h4prsD2hB81tHFb0IeSfkB5y4KJi63pqm3nbPF0R	\N	8.216.14.239	curl/7.74.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWkZkY0JpU2J0MkRhdGpBTndJTlFPOEloWWtMRm5odVNGU0xzcU5xYiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778303882
OmTRZuX1XPXEY8WT8twUanJNHht7d7YFhW5d22OX	\N	20.65.194.117	Mozilla/5.0 zgrab/0.x	YTozOntzOjY6Il90b2tlbiI7czo0MDoibU1yVmIwWW42NXB0V2hMU0E5ckhyb1kwaGJGNWM5RFRta1BGcE9mUCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778312577
thbxqVo6Zanedwy7UP9Ckwvhg2YIw5Dl0Lw9Rhb5	\N	207.154.228.110	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/118.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiYTFnb0wwQ1Rkc0lZQmlOd3NaUmxNUHlEZ1JTOERROEFOTTVnYmpKdCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778285972
8EDpktoD8DRT5aOSiqF1Fg3DRItaGKE2htcta2Sn	\N	82.132.245.28	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiZng3STAyN0lydXFBaURkNzBvUW5pWkRyUHlITGpBemJCaGtKRGVIZCI7czo5OiJob3VzZWhvbGQiO3M6NDoiWFNLVyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778317452
tX4QpENGB8wt4zmiN6wIoPT2RIqSqw77ea2TgXfQ	\N	34.77.217.12	python-requests/2.32.5	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVzVkcGJEWjJRWm1kNUp5MWZleEdUU2w5dzBLbXByd0NVbWl5UUc3MSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778326436
DK3kNIENUQxz0wza9xIzHzd88mEBznXaEGgBZzjy	\N	92.40.179.227	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiMkVNbDVYbFBYa2dnaTd1Y0NUZUtsUXEwOTEyZkNJdVF3ZWY3VG9yMCI7czo5OiJob3VzZWhvbGQiO3M6NDoiTlhEUSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778339847
7TksJZFXl6ZBLxtXjKPOvMplofA7UNtheOEEaLbv	\N	91.236.239.9	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMnhnWDZvTktWNTB4cXNHUHZRb0N2VHBuTnpSUmxTRGRRS20wbHFyZSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778348265
YS2yINuXmkiriW4uDM2msjsU39vmdXMqbt7LAhyb	\N	198.235.24.209	Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSUVwWGJOTWZ1cFdJMHlmNzNlU0tWbzFiaWk3UzR5U0J0a043ZHBzaSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778348284
KFUA0b9PGxSVjvCzQVMqd252Pb0PA7iyfH2JZKeW	\N	45.142.193.212	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiU3c3NWdJYUR0RFZwakhhN0dBUnJWSUdxQVBENHFyMzBOOWM5MXB6RyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778360561
vnx2jx1bza6V2R56NicPrvJXoA33D578ovRE7V8b	\N	216.226.76.20	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ1NaSVN6WjFqbWM0YzJmd2ZoZGlRSFFHZ3d5bEY5dmJmbDF0MzZRcSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778372687
W4YfGvbJxLipBMjLfb40H0aFygXS5uPUyO0VUmzS	\N	184.105.247.195	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36 Edg/125.0.0.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoicjhTSHpjTFJ5bXNnclIwU2s1Rm1IVHFROEZhdkx4aUo1bjBmclFVVCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778294114
tBCHEMTndRn9gEjmoEc3viKbRBm2gylaxVWuQdHR	\N	172.234.217.129	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoidGR6MlNZOTNkYllDMDBURGRFRk1UUzZKVEdmVzdFOWVwdEo3bTNVbSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778305083
n9D5gjg2C6Etr24tNltziHtIAd33sZRlEKKyA6RJ	\N	64.82.228.45	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVDZQSnFpOWx5SmlrSktIN2tlMFhJMndCTGJYQlNjZlBOTVdTU284RyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778314642
MGmtaaVLRr1ogmBdScD1EdMznYT4zPNKnByagLEK	\N	51.15.59.15	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMEI2bG1XUDNFTE4xTG44U2VlQkJEUkxjY0NsUVJwdlVxUEZnc2dKVSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778286711
n9s39ys26JUwMZTSFQINn1XEBMUgjD1aADXRhPgb	\N	195.187.58.216	Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:150.0) Gecko/20100101 Firefox/150.0	YTo0OntzOjY6Il90b2tlbiI7czo0MDoic21nRER4SzlNYm13QVQzZXFnMGY4ZnZ1ekpXd0U4amNsNmtqTjZpeiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjk6ImhvdXNlaG9sZCI7czo0OiJYU0tXIjt9	1778315729
FvpTYLrjd5dR3tiIdAazaykJvBoPXSdxaK71Dn4Q	\N	54.244.14.158	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.51 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiV1JRM0pRR1ZzT2dLMVFRb1ExVjVNRVVtUEJrSUx0aWtSVWpiTjJPbyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778317944
BBzYOyke1u21plGY80UVkLnToicBPHvz7qmWmNoe	\N	192.253.248.169	Mozilla/5.0 (Windows NT 6.1; rv:18.0) Gecko/20100101 Firefox/18.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiaWs3UEhQRnBXV2RMc0ZyN0hSUDJPbmM4NjNBd2tvWllwcTBzbnlMSiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS8/cGhwaW5mbz0tMSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778326622
kxamhgyb0NNehplKliZLPvWX1N0dUVBODlDos8Um	\N	79.124.40.174	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoicERTbVhrWk8wU3lRWDdWNXhuUzYxWjlzbVNFZ2phazE4OGtybmdVMCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTI6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS8/WERFQlVHX1NFU1NJT05fU1RBUlQ9cGhwc3Rvcm0iO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1778340085
A0bNti5lnEImbY3yBqt7NkJxjcDiUXXFICowjbm3	\N	93.158.91.241	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNER3b0dBWWE1Y3BEMFpCMURXd241QjZubkhMOE91MFRLTnNXQlRiVCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778348987
C3ML9ZLIvPJLSISYThymgSVUnHsAU4qamTMiHlR0	\N	198.235.24.156	Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity	YTozOntzOjY6Il90b2tlbiI7czo0MDoidjR3UUVQb2Rla000eVlEOE1NVHJpQ0Nmd21KbW9NVlFSb1k4OTJkQiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778360858
gDMtZt7poGS6GRcTXw8UEEbD0UmQZHxCgww726I8	\N	184.105.247.195	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36 Edg/125.0.0.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMWxPeGRpaDk5QVNOTlg0M1BtdENFTFhTRjdkWEN1NkowaWU4U1lFUiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778294638
CW8fHtsHCP3xx9oKIPaOlatHwcfiAJmMcviH3WHC	\N	195.154.37.24	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSW1tNURJR3JVa3BPVG1NbVU0ckRjUmlVeXdVNE1CbEJaQjMwblN4MiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778308105
kvLRgdvdLMFznfbXWIRjRJjBdPRU8wiYQvjMPAjR	\N	195.187.58.216	WhatsApp/2.23.20.0	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiVGpjcVluZk9XeGRoYkszZHRCY1kwa2FvNmhyM1p0YnNaZXZVcHpOTiI7czo5OiJob3VzZWhvbGQiO3M6NDoiQkNRRCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3JzdnAvQkNRRCI7czo1OiJyb3V0ZSI7czo5OiJyc3ZwLnNob3ciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778314800
NwtQwyiXn4BDN0n4DzqsQ8DMDqMTewSmdE2EgYnE	\N	195.187.58.216	WhatsApp/2.23.20.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWll3RFV0Sk9oOFhFN0pVZ0M5bnZoZzRuRFV3V3paSnZybnF2V1BVSyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778314801
FIHJDBFz2e4CvnNWMo4zH22UXtjTwyxNkaJze0s2	\N	155.133.17.236	Go-http-client/1.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoidjBqb05CV1locDd3SklRS3ZKMVJJaG1GaDVLZFpHSXRjdzA5Z21VNCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778318559
mQwLthP0X0HZOYtmeyxtYNIjUZsngJSvhLEdJEgn	\N	172.234.217.192	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiamVFUW10RzBqNEUxR0ZUbjJKVk5mZTFMZTdxRUw5TW9qMEJQaEF0MSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778287307
2s5EOLwqeeDKnnZSQLt4j5eL5ju4FuREwEJpZwE4	\N	148.252.129.33	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiVnVPN040aXU4alUxTEhhbXV4ZEZLWHBOaWg2UTJoRGFnOGpuYVFJMSI7czo5OiJob3VzZWhvbGQiO3M6NDoiQkhVUCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778330852
YThPjKeeVQkA6M8q9wNd7JLiIpdUGDP2RxrAdD0L	\N	147.185.132.159	Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRkxGem1aNkx5bXRleURqYzl1bFAxempoVlRKZFNkU0lUbENYMllKRyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778340584
9LZ1vVxQYz9YNa3JADgwCj0JVKU6EhwSoWVdV7Cb	\N	92.40.179.18	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_1) AppleWebKit/601.2.4 (KHTML, like Gecko) Version/9.0.1 Safari/601.2.4 facebookexternalhit/1.1 Facebot Twitterbot/1.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoibmx4cDdDVmRZZ3VPSWowamIzU2ZyUjVSbm93NDJNYXRKTDZ0RjEwVyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778349383
EV6v78XMkKoDKR96GHt3YLl3luAE2klxjlCL5qTS	\N	92.40.179.18	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMFduS0hEaWpFd3h1WEtsQklxcmg5V1VBQmlLVmU4ZGFlTFNxSWF4WiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778349384
0tw56sO7w9XveFwXSNvzcVZv3zraRyXOWo4bnirV	\N	192.253.248.169	Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; Touch; MASMJS; rv:11.0) like Gecko	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVFN4anl4OWNJa1JqM0dqaFNJbXZvSUdOMGl4WmE4S2ttSHd3S1dBViI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS8/cGhwaW5mbz0tMSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778363094
pI64GBf1fnJAjKpT344Lfs2yPurYyhWx8pKQubIe	\N	172.236.228.208	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoicUs4UTBnYldNNExGTThES1hFOGRDajdUWlR5VHdrbXNHMUZsdWx0bSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778295892
hGrpa1AqvX1o0RuRndS3hae7QubCTtNvfJyMsV2D	\N	172.104.11.46	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNlZOeXhnTUZPdkl4azhxYnNOc3MxTzRtWEQxaVBZeUhGbDQ4ek1WcyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778309455
eiWOnZpkYRQrkSETaXTnc9Ifq1dmfLlfDGi10QG9	\N	92.40.172.70	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1	YTo0OntzOjY6Il90b2tlbiI7czo0MDoieUh5Y0JPMkFyQjVGSlVpWUk2YmxONkJrTkhpS0RlWU5LNU02UnlxTiI7czo5OiJob3VzZWhvbGQiO3M6NDoiTlhEUSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778315032
RNA6ZZVAhvPHoKsh0yGS8X5L1ncJUW1kOgH7YMgx	\N	4.240.90.147	Go-http-client/1.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiVzBDQjV0SmY1MVYzZXNCTEZnT2VTeUZtQWtlcjBjTUxmU2JyaExkZSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778319998
TD0KibelgNqMVMFEbxtzc70AqZJImwkVe6ZZMSvq	\N	43.165.170.119	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoibEZseXNlZ1U0MVVPVlp0SDRoanRTNEh1TWx0OWhDMXpPa3VKNE1keCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778336339
kg7iiZHyLbFQUOGvaM02JsNxB1XydMi6oLSwNFvz	\N	104.28.224.67	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSWRwdWFCamZKU0Z2Q2x4akM5bmpES3VyWTE1SXdPQU1nNXk5dlVKaSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778344745
caPWRUNu8Wk0NHzO17YIzY00prasplAza65HdeAk	\N	104.28.224.67	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoic3R0bG1vUzdYZzRmZG9IQmF3UlpqeldvTmpEQUNRbE11cWhnRmppMiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778344746
S1fiRnRkjbcEuVvOjK35mFLSNr2xSIQuqXdcinZ7	\N	34.53.252.202	python-requests/2.32.5	YTozOntzOjY6Il90b2tlbiI7czo0MDoibnJlWmdrR0dCcXpvV3BPNXkxdHNzcU5aM0ZuOTMyS2pZT3JDdFBZbyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778354793
D2OLuQQRl4CrodXojXP9O0e8o1f1N11jt3wthJ1o	\N	192.42.116.51	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZERMMTQ1N2dQcE1qeEtxZ05ENkY3aWZIeW9IMGRNU0xJV1A3TTZsYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778287605
LfUp7h3aTN5N2N7w371ZnVcv0R1qVk2VhiGe1Pij	\N	78.30.106.236	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Mobile Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTWFVcXlTRzhsa1REMjQyZ0RMVFhMaFk3cnpZWEtlUUlsNjZaNm5ucCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6OTc6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tLz9nYWRfY2FtcGFpZ25pZD03MDE4Mzg1NTQmZ2FkX3NvdXJjZT0wJmdjbGlkPUNqdzVnRmlxTzNMR0E3VFJsaGtRNW1lUTUiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1778365346
z4rcMsNGIO1NVZRzerKYGfFEnETIYwdLpqHejvyU	\N	94.231.206.7	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:134.0) Gecko/20100101 Firefox/134.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRnZzMzk1Z0xyV29BOVVKZUp2QzZqcHIyOXltSFFQTkpQdk1KWmJsMSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778297061
n8Jb7TglLnByinfWDtkKmU4FheEc4fbTUSWxUcVq	\N	45.33.80.243	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTUtveURtR3k4YUo2cnpHQ2ZXSlJoT1BzeWZjc0lrZFU0ckFodVVNbiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778297175
FCOYSzTd9gpI8hLdmzsI6O0nDjLnsr8tdcokczJ4	\N	167.94.146.57	Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoidlUyb0daeDF6T1R1QTNUdERlSzZGUDhLZUhNRUVIRFhIZ0lzelNuaiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778310541
aAH4NMgCCk42ulVeaitnQcTS3CO82ehXYx2MkwpG	\N	167.94.146.57	Mozilla/5.0 (compatible; CensysInspect/1.1; +https://about.censys.io/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiOTlBeG5Sa3NQazNWVzNMcFE3dmc4VkFnOEV2UE8wZmh6WTgxZzBUdSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOS9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=	1778310562
EkgajSpx3LbkfQCsnTnIIZUH8MXmUnMSqPTa4MOg	\N	92.40.173.190	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiZkc4RGt2WG1rSjY1SjBzREh4MFhEbkFHTm9vVUlFQkU1VDAxQ3hqdyI7czo5OiJob3VzZWhvbGQiO3M6NDoiUEFKVyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778314972
MRSqZ0Bm0pypbjX1wgCgGLR3Z1XQZcKlJzH1YynZ	\N	172.105.128.11	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRzJPWWtPS0Z0WFkwU3I3NUZJSmg1eGJwSFpMN2o5cTdHQnlkaHF2WiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778281194
lpaPwZDI29J2XIPTa5PZqpqMBamsL8iTpn045y8c	\N	144.172.92.249	Mozilla/5.0 (Windows NT 10.0; Win64; x64; WOW64; rv:41.0) Gecko/20100101 Firefox/140.0 (x64 de)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiem5yejV6cGZGQVFseTRLdW42NmN5eDJ2N2ZTYll3SE1Ec1duRlVMZCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778291001
9snDkmZFetvkYKDedXSVBVQdPUberlAQfgjA3IQX	\N	195.187.58.216	WhatsApp/2.23.20.0	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiZ2hHa3FLT1Z6eHJKbzlFbURrVFFOdjhOdnNaaEIzZGtRbFZIbFVrNSI7czo5OiJob3VzZWhvbGQiO3M6NDoiS0NIVCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3JzdnAvS0NIVCI7czo1OiJyb3V0ZSI7czo5OiJyc3ZwLnNob3ciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778315005
GuugPLDQWLoDjziMZhbiif9MPk7jQo9J89xWReNT	\N	195.187.58.216	WhatsApp/2.23.20.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSTZRWXJTTVJzdUx2OFV6RVloM3lsN2RHRkN6dmVJR09ZWGhabVRVbCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778315005
SQ4pmafzxsCojU1gyvAdQWj3JjwhWOYC2AYjmNym	\N	103.120.189.68	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiclRxTUQxcERzQkJvdjdacG9OWE1ja091RTZWTEVzVjdLOWNwRjZCdiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778320459
L7xelDEtM2bWLngbieM2GoYseqUfsMENb0vEtwsh	\N	172.236.228.111	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiSm1wS2NudnRtZG9MeTVRU2pwODQ3aE85eldMaUh2V2k0QnZqdDFNeiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778338242
YZ6xLJ4ySSf8MaNaPsswtvQ8bWB5qc6lQQqmprbF	\N	185.12.59.118	Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoidmY0VlYxaGR6R2o1S2FnOFozUTNZNkhYNVRMT2c0aUhZa0RjYjNNQiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778345562
xGjJuqmK658jsDUL34amfUbsJOZRVNOZ1ZRdyMLl	\N	185.247.137.194	Mozilla/5.0 (compatible; InternetMeasurement/1.0; +https://internet-measurement.com/)	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWDQzQWpEWjAyUmVZNzdxT2JFOENYdEhtUkMzN0VZNmdoSXpIN29xaiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778354984
NggfSYGVHeueTHOtE2Q3TDco4nh1ggPUYjPKTDfe	\N	45.79.181.251	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMmk1aVNEc3kyR1UzNVpOOUpqS2xneVlUMlZtMktEWm1EblFROFZ4ZiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778370086
hkPqLnxxOKJSb2Wc5rUkcdPqs3FEGscSzu5I2lLu	\N	104.28.224.67	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWjU3Z2hNcWVUMWpCMXFEcjJySWMyV0VBczBVdVhNZlpSRnh0UHJYTyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778300831
K4DaBTGuflLFQJE3FtiNiwohtJQQpO6ikFQvdag5	\N	104.28.224.67	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ2cwRGcwRHJXbnF2UG9UT0pvTjliS3pCVXBEN1JZcmtoS05PWGJxbCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778300832
NKPYCL1XBidVUoMs20Tz3niKPj3Of5sFFOuYxLZZ	\N	85.11.167.114	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiamxBOVk5WkdSRUNiTEh4cUhFUGtFcTU1cXlGREd3T3VLSFp3Ylh2OCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778310869
nxEBU766pP3W6wjiLbMgEPLTv3Y4T8EIkhQ2y1UH	\N	176.65.139.168	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMzJHb2NhYk0wSlp4RTdvVmVUQjJqUFJoNHptWW52eDVlenBqMUdaZyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778315147
31TpB8ZvGg8PB2XqbF2nQkpgE1OHiXPjFpqD12Db	\N	152.163.186.247	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.35/36 Safari/537.36	YToyOntzOjY6Il90b2tlbiI7czo0MDoiVlVHMWxGQ21xYXd4UWFIRmVkVU9NMjZFSE51NmdQSnBVSHQ4SmU4ZCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778322137
NVQYwlTPBDMEzxnlErrsuScxsQE5lCwul7d3tvVy	\N	152.163.186.247	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.6998.35/36 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiU055ZTZ4c2xNMGtjbXpSRlNuWE1qWUxrS0V2WVlKZzJWVExZaDRmNCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778322137
oS6RbC5pSoImUJCK4RDgzz3B7IEI5dgeIIIPHGHr	\N	194.233.101.69	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiRzkxSm1FMDZRUGRSaDBocHI2WDkwN1QwVEtMZ3FOZEg4REpxZmdJWSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzU6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tL3RpbWVsaW5lIjtzOjU6InJvdXRlIjtzOjg6InRpbWVsaW5lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778322503
gvADQrwcgNG5onFJFcW68N0LOFNFrXWDtcPhsatB	\N	86.145.247.248	Mozilla/5.0 (iPhone; CPU iPhone OS 26_4_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/148.0.7778.100 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQUxFWDVRZmdpU2RkeGxzcW13RmhTb1Q4b0gzNWRzdVRGNzRDTTdQdyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778281585
vzQmzPL7aqrAG6MEFOqE3FndE17dg7JOH2X5ckxJ	\N	160.153.192.232	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.51 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTVFzUU9XQ2FkdG10c0NFN3ZkWXpydUJXaEV3UzVCbkVNRmZzTDZkYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778338392
iFWEukowGvgoTg71VZVSl99HgAHL1NiznGjSVdoH	\N	45.79.181.179	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoicHVFajdTd0t2SjdhVzJndmV4TFBIMHFKZWFKQ0dYSUk1R002RERZWiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778347226
8KRfwC1ds2Op15KQ3KF2GQ6q4lS4pPib1gjIYOxe	\N	3.143.162.210	visionheight.com/scan Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/126.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiTzRQN2d0N2tud3NxVTJiWHJtSjc2SXB6RWYwbnR4ZjE3ZjJjNGcxaCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778356413
OpI41nKB7gSNJSopxwZV2c5XKWVThCbEmbEdxFuf	\N	43.167.236.228	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiU0syY3YycjJFczVJVTRSMTliYzNzTGQxYW1yMzVDMWVkVEVQMW5zMCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778370825
anp7qhZ046ZLCyklmJ5JuZh8VFXW2pYmHrNBI3FK	\N	91.230.168.180	Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:134.0) Gecko/20100101 Firefox/134.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoiQmU3SW9pMlExUGJwYVRyZ0htVlVOV2VQbUpIU3p0VXhYUDZnOXNCbCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778303289
uDdDhmm58XReK4xJOKKkwVO7EFCGkJBt8v79zgRh	\N	43.159.143.187	Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWGppRHRqYVhKa0pIeDI5ajdTeDVaTmc5MGptbk1xVnNBU0NaZmVTRyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778311254
ceLuR4H7wbxNN8u9f1ojw4VO7cMWzxYeGSavYQFX	\N	20.207.201.147	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiNndNanRzNGRIRkNaM1p4UHVVTVp6eHA1SktyeWM3NzAwY1B1OTdvWiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778311316
PUpK8l2qqvNU2OAjtpMw2YDARUP7EUp10rE1dYe5	\N	172.236.127.133	Mozilla/5.0 (Macintosh; Intel Mac OS X 13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiM2VYU3JaNUpPQ2plNno3UG9NUWxRSldkcktUNlZUcVppQzFYVEhZbSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778311323
IE0bY62liHjT1bBdPfPcKdEalTQqFTE0hCirVOqj	\N	195.187.58.216	WhatsApp/2.23.20.0	YTozOntzOjY6Il90b2tlbiI7czo0MDoicjJmWXhtdElCVktuZGl3eDZWU3pVdTVSeXVFZzlYZHl0TDg5REdsWiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778315389
c8pUpHouxWzrFg4ewxeYOzdTpdrcKSlNVhwEE9ho	\N	104.168.115.241	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiV2hlZXVIeU0xODRDSVlXR3BjSUxuMkdobU05aDRUMmt0eGZ0MGNaTiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778283028
LPurtyF1HcDfsoHZXHpAAvS38stvmxS4TghReIIY	\N	104.28.224.60	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWDdPSWRCU2E5dnhpNDI3eTlpaVNBc3czZ3FRVGhUMlFDYVFPdENMayI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778322796
ckMR0yIeTYM4zKmmy0STZvGtHOqriewM48cj1Zqa	\N	104.28.224.60	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWFp3aTBkUmRqYkZmeENHdm9WRGE1M29yOW9LbTVlOWs0ZlZ5dUl1QyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778322797
jH3bgiRz0BfYujtScwNawq8IjASxpI2trQUv0tRu	\N	45.148.10.67	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiMTZkY1o1TjkweXZMWjZqTGgyVjdsRkxyRlhoS21xWkhqQW9WdnpWOSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778339614
SuvaR2AKG5IAc5r1sFSNniMnCBau22rKP0ZYiskk	\N	95.166.13.24	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	YTo0OntzOjY6Il90b2tlbiI7czo0MDoiT3BpcVRBRkFjV3Boazg0Qng1dzZyUUpWREZEOVNidXR0Vm9scTFOeSI7czo5OiJob3VzZWhvbGQiO3M6NDoiQkNRRCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778347678
yaXk3J6yYm9Cf2vCntPSpNpBUzfh7R7Jy8L6Ncwc	\N	45.148.10.67	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiWmR4Y3RBRFk5a3FrZG5XUWRiRzdQdkt2VktERkozR2pxVDFUT3pEZCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTc4LjYyLjg3LjIxOSI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==	1778359342
Ocg1SuSvd5XSoC5gSEPE8UksNGeKEV6BFXLPMxdv	\N	82.102.18.124	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36	YTozOntzOjY6Il90b2tlbiI7czo0MDoiZkJ0S3l1dGQyUFI0SDIzOURLc1NSV0luZ2NPVVhYMm5Xa003MmxLRiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vZnJlZGR5YW5kZGF2aWQuY29tIjtzOjU6InJvdXRlIjtzOjQ6ImhvbWUiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19	1778371822
\.


--
-- Data for Name: train_affirmations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_affirmations" ("id", "created_at", "updated_at", "message") FROM stdin;
1	2026-04-05 15:57:00	2026-04-05 15:57:00	We love you all so much, thank you for celebrating with us today!!
\.


--
-- Data for Name: train_configs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_configs" ("id", "created_at", "updated_at", "key", "value") FROM stdin;
1	\N	\N	importantMessage	
\.


--
-- Data for Name: train_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_events" ("id", "created_at", "updated_at", "destination", "description", "scheduled_time", "estimated_time") FROM stdin;
1	2026-04-05 15:57:00	2026-04-05 15:57:00	The Ceremony	Please gather on the East Lawn and find your seats!	2026-09-05 13:30:00	2026-09-05 13:30:00
2	2026-04-05 15:57:00	2026-04-05 15:57:00	Drinks Reception	Enjoy a glass of bubbly and a canape (or ten!)	2026-09-05 14:15:00	2026-09-05 14:15:00
3	2026-04-05 15:57:00	2026-04-05 15:57:00	Confetti Throw	Grab a handful and get ready to throw!	2026-09-05 14:00:00	2026-09-05 14:00:00
4	2026-04-05 15:57:00	2026-04-05 15:57:00	Groomsguard Photos	Now calling: Alyssa, Ian, Mark, Jon, Alex, Quinn, Adam, Hannah	2026-09-05 14:20:00	2026-09-05 14:20:00
5	2026-04-05 15:57:00	2026-04-05 15:57:00	Foxguard Photos	Now calling: Alyssa, Mark, Jon, Hannah	2026-09-05 14:25:00	2026-09-05 14:25:00
7	2026-04-05 15:57:00	2026-04-05 15:57:00	Backstage Photos	Now calling: Ian, Libby, Millie, Quinn, Alix, James, Colin, Jon, Matt, Tanya, Pixie, Jana, Shaun, Adam, Shel, Joel, Georgia, Shreya, Danvey, David, Heather, Henry, Ezra, Nutt, Wyles, Ollie, Emily, Elliot, Sian, Briscoe, SB, Erika and Will	2026-09-05 14:35:00	2026-09-05 14:35:00
6	2026-04-05 15:57:00	2026-04-05 15:57:00	Groomsmen Photos	Now calling: Ian, Quinn, Alex, Adam	2026-09-05 14:25:00	2026-09-05 14:25:00
\.


--
-- Data for Name: train_gifs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_gifs" ("id", "created_at", "updated_at", "link") FROM stdin;
\.


--
-- Data for Name: train_jokes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_jokes" ("id", "created_at", "updated_at", "message") FROM stdin;
1	2026-04-05 15:57:00	2026-04-05 15:57:00	Why can't a steam locomotive sit down? It has a tender behind!
2	2026-04-05 15:57:00	2026-04-05 15:57:00	What do you get when you cross a railway engine with bubblegum? A chew-chew train!
3	2026-04-05 15:57:00	2026-04-05 15:57:00	How does a train avoid detection? It covers its tracks.
4	2026-04-05 15:57:00	2026-04-05 15:57:00	How do locomotives hear? Through their engineers.
5	2026-04-05 15:57:00	2026-04-05 15:57:00	What’s a train’s favourite type of shoes? Platforms.
\.


--
-- Data for Name: train_secrets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_secrets" ("id", "created_at", "updated_at", "message") FROM stdin;
1	\N	\N	SECRET: ABCDE
\.


--
-- Data for Name: train_slideshows; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."train_slideshows" ("id", "created_at", "updated_at", "link") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."users" ("id", "name", "email", "email_verified_at", "password", "remember_token", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type") FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_analytics" ("name", "type", "format", "created_at", "updated_at", "id", "deleted_at") FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_vectors" ("id", "type", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."objects" ("id", "bucket_id", "name", "owner", "created_at", "updated_at", "last_accessed_at", "metadata", "version", "owner_id", "user_metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads" ("id", "in_progress_size", "upload_signature", "bucket_id", "key", "version", "owner_id", "created_at", "user_metadata", "metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads_parts" ("id", "upload_id", "size", "part_number", "bucket_id", "key", "etag", "owner_id", "version", "created_at") FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."vector_indexes" ("id", "name", "bucket_id", "data_type", "dimension", "distance_metric", "metadata_configuration", "created_at", "updated_at") FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 1, false);


--
-- Name: accommodation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."accommodation_id_seq"', 1, false);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."failed_jobs_id_seq"', 1, false);


--
-- Name: food_choices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."food_choices_id_seq"', 1, false);


--
-- Name: guests_duplicate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."guests_duplicate_id_seq"', 1, false);


--
-- Name: guests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."guests_id_seq"', 1, false);


--
-- Name: households_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."households_id_seq"', 1, false);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."jobs_id_seq"', 4, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."migrations_id_seq"', 21, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."personal_access_tokens_id_seq"', 1, false);


--
-- Name: train_affirmations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_affirmations_id_seq"', 1, false);


--
-- Name: train_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_configs_id_seq"', 1, true);


--
-- Name: train_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_events_id_seq"', 1, false);


--
-- Name: train_gifs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_gifs_id_seq"', 1, false);


--
-- Name: train_jokes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_jokes_id_seq"', 1, false);


--
-- Name: train_secrets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_secrets_id_seq"', 1, true);


--
-- Name: train_slideshows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."train_slideshows_id_seq"', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."users_id_seq"', 1, false);


--
-- PostgreSQL database dump complete
--

-- \unrestrict gelOcidtyVkkkvLuHBKkNt6CeKdq1itIBdGLNP9gPP4wX9ISVqUG8JH8Akqh3aX

RESET ALL;
