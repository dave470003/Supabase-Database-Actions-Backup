


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";






CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";





SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "public"."accommodation" (
    "id" bigint NOT NULL,
    "is_at_venue" boolean NOT NULL,
    "is_treehouse" boolean NOT NULL,
    "name" character varying(255) NOT NULL,
    "slug" character varying(255) NOT NULL,
    "is_paid_for" boolean,
    "price" numeric(8,2),
    "suggested_donation" numeric(8,2),
    "description" "text",
    "link" character varying(255),
    "check_in" timestamp(0) without time zone,
    "check_out" timestamp(0) without time zone,
    "model" character varying
);


ALTER TABLE "public"."accommodation" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."accommodation_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."accommodation_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."accommodation_id_seq" OWNED BY "public"."accommodation"."id";



CREATE TABLE IF NOT EXISTS "public"."cache" (
    "key" character varying(255) NOT NULL,
    "value" "text" NOT NULL,
    "expiration" integer NOT NULL
);


ALTER TABLE "public"."cache" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."cache_locks" (
    "key" character varying(255) NOT NULL,
    "owner" character varying(255) NOT NULL,
    "expiration" integer NOT NULL
);


ALTER TABLE "public"."cache_locks" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."failed_jobs" (
    "id" bigint NOT NULL,
    "uuid" character varying(255) NOT NULL,
    "connection" "text" NOT NULL,
    "queue" "text" NOT NULL,
    "payload" "text" NOT NULL,
    "exception" "text" NOT NULL,
    "failed_at" timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE "public"."failed_jobs" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."failed_jobs_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."failed_jobs_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."failed_jobs_id_seq" OWNED BY "public"."failed_jobs"."id";



CREATE TABLE IF NOT EXISTS "public"."food_choices" (
    "id" bigint NOT NULL,
    "name" character varying(255) NOT NULL,
    "description" character varying(255) NOT NULL,
    "allergens" smallint NOT NULL,
    "course_number" integer NOT NULL,
    "is_child_food" boolean NOT NULL,
    "options" smallint NOT NULL,
    "cost" numeric(8,2)
);


ALTER TABLE "public"."food_choices" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."food_choices_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."food_choices_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."food_choices_id_seq" OWNED BY "public"."food_choices"."id";



CREATE TABLE IF NOT EXISTS "public"."guests" (
    "id" bigint NOT NULL,
    "reference_name" character varying,
    "name" character varying,
    "email" character varying,
    "rsvp" boolean,
    "household" bigint,
    "role" character varying,
    "requires_childcare_data" boolean,
    "requires_childrens_menu" boolean,
    "requires_childcare" boolean,
    "dietary_requirements" "text",
    "comments" "text",
    "favourite_board_game" "text",
    "invited_day_after" boolean,
    "invited_evening_before" boolean,
    "evening_only" boolean,
    "partner_invited" boolean,
    "is_child" boolean,
    "day_before_rsvp" boolean,
    "day_after_rsvp" "text",
    "course_1_id" bigint,
    "course_2_id" bigint,
    "course_3_id" bigint,
    "seat" smallint
);


ALTER TABLE "public"."guests" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."guests_duplicate" (
    "id" bigint NOT NULL,
    "reference_name" character varying,
    "name" character varying,
    "email" character varying,
    "rsvp" boolean,
    "household" bigint,
    "role" character varying,
    "requires_childcare_data" boolean,
    "requires_childrens_menu" boolean,
    "requires_childcare" boolean,
    "dietary_requirements" "text",
    "comments" "text",
    "favourite_board_game" "text",
    "invited_day_after" boolean,
    "invited_evening_before" boolean,
    "evening_only" boolean,
    "partner_invited" boolean,
    "is_child" boolean,
    "day_before_rsvp" boolean,
    "day_after_rsvp" "text",
    "course_1_id" bigint,
    "course_2_id" bigint,
    "course_3_id" bigint
);


ALTER TABLE "public"."guests_duplicate" OWNER TO "postgres";


COMMENT ON TABLE "public"."guests_duplicate" IS 'This is a duplicate of guests';



ALTER TABLE "public"."guests_duplicate" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."guests_duplicate_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



ALTER TABLE "public"."guests" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."guests_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."households" (
    "id" bigint NOT NULL,
    "name" character varying(255) NOT NULL,
    "code" character varying(255) NOT NULL,
    "rsvp_sent" boolean DEFAULT false NOT NULL,
    "accommodation_id" bigint,
    "invited_day_after" boolean DEFAULT false NOT NULL,
    "invited_evening_before" boolean DEFAULT false NOT NULL,
    "day_before_response" character varying(255),
    "day_after_response" character varying(255),
    "in_coach_house" boolean
);


ALTER TABLE "public"."households" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."households_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."households_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."households_id_seq" OWNED BY "public"."households"."id";



CREATE TABLE IF NOT EXISTS "public"."job_batches" (
    "id" character varying(255) NOT NULL,
    "name" character varying(255) NOT NULL,
    "total_jobs" integer NOT NULL,
    "pending_jobs" integer NOT NULL,
    "failed_jobs" integer NOT NULL,
    "failed_job_ids" "text" NOT NULL,
    "options" "text",
    "cancelled_at" integer,
    "created_at" integer NOT NULL,
    "finished_at" integer
);


ALTER TABLE "public"."job_batches" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."jobs" (
    "id" bigint NOT NULL,
    "queue" character varying(255) NOT NULL,
    "payload" "text" NOT NULL,
    "attempts" smallint NOT NULL,
    "reserved_at" integer,
    "available_at" integer NOT NULL,
    "created_at" integer NOT NULL
);


ALTER TABLE "public"."jobs" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."jobs_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."jobs_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."jobs_id_seq" OWNED BY "public"."jobs"."id";



CREATE TABLE IF NOT EXISTS "public"."migrations" (
    "id" integer NOT NULL,
    "migration" character varying(255) NOT NULL,
    "batch" integer NOT NULL
);


ALTER TABLE "public"."migrations" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."migrations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."migrations_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."migrations_id_seq" OWNED BY "public"."migrations"."id";



CREATE TABLE IF NOT EXISTS "public"."password_reset_tokens" (
    "email" character varying(255) NOT NULL,
    "token" character varying(255) NOT NULL,
    "created_at" timestamp(0) without time zone
);


ALTER TABLE "public"."password_reset_tokens" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."personal_access_tokens" (
    "id" bigint NOT NULL,
    "tokenable_type" character varying(255) NOT NULL,
    "tokenable_id" bigint NOT NULL,
    "name" "text" NOT NULL,
    "token" character varying(64) NOT NULL,
    "abilities" "text",
    "last_used_at" timestamp(0) without time zone,
    "expires_at" timestamp(0) without time zone,
    "created_at" timestamp(0) without time zone,
    "updated_at" timestamp(0) without time zone
);


ALTER TABLE "public"."personal_access_tokens" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."personal_access_tokens_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."personal_access_tokens_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."personal_access_tokens_id_seq" OWNED BY "public"."personal_access_tokens"."id";



CREATE TABLE IF NOT EXISTS "public"."seating" (
    "id" bigint NOT NULL,
    "table" smallint,
    "position" smallint
);


ALTER TABLE "public"."seating" OWNER TO "postgres";


ALTER TABLE "public"."seating" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."seating_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."sessions" (
    "id" character varying(255) NOT NULL,
    "user_id" bigint,
    "ip_address" character varying(45),
    "user_agent" "text",
    "payload" "text" NOT NULL,
    "last_activity" integer NOT NULL
);


ALTER TABLE "public"."sessions" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."tables" (
    "id" bigint NOT NULL,
    "name" character varying,
    "elmore_id" smallint
);


ALTER TABLE "public"."tables" OWNER TO "postgres";


ALTER TABLE "public"."tables" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."tables_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."train_affirmations" (
    "id" bigint NOT NULL,
    "created_at" timestamp(0) without time zone,
    "updated_at" timestamp(0) without time zone,
    "message" character varying(255) NOT NULL,
    "enabled" boolean DEFAULT true NOT NULL
);


ALTER TABLE "public"."train_affirmations" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."train_affirmations_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."train_affirmations_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."train_affirmations_id_seq" OWNED BY "public"."train_affirmations"."id";



CREATE TABLE IF NOT EXISTS "public"."train_comments" (
    "id" bigint NOT NULL,
    "created_at" timestamp(0) without time zone,
    "updated_at" timestamp(0) without time zone,
    "message" character varying(255) NOT NULL,
    "enabled" boolean DEFAULT true NOT NULL
);


ALTER TABLE "public"."train_comments" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."train_comments_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."train_comments_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."train_comments_id_seq" OWNED BY "public"."train_comments"."id";



CREATE TABLE IF NOT EXISTS "public"."train_configs" (
    "id" bigint NOT NULL,
    "created_at" timestamp(0) without time zone,
    "updated_at" timestamp(0) without time zone,
    "key" character varying(255) NOT NULL,
    "value" "text"
);


ALTER TABLE "public"."train_configs" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."train_configs_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."train_configs_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."train_configs_id_seq" OWNED BY "public"."train_configs"."id";



CREATE TABLE IF NOT EXISTS "public"."train_events" (
    "id" bigint NOT NULL,
    "created_at" timestamp(0) without time zone,
    "updated_at" timestamp(0) without time zone,
    "destination" character varying(255) NOT NULL,
    "description" character varying(255) NOT NULL,
    "scheduled_time" timestamp(0) without time zone NOT NULL,
    "estimated_time" timestamp(0) without time zone NOT NULL,
    "enabled" boolean DEFAULT true NOT NULL
);


ALTER TABLE "public"."train_events" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."train_events_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."train_events_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."train_events_id_seq" OWNED BY "public"."train_events"."id";



CREATE TABLE IF NOT EXISTS "public"."train_gifs" (
    "id" bigint NOT NULL,
    "created_at" timestamp(0) without time zone,
    "updated_at" timestamp(0) without time zone,
    "link" character varying(255) NOT NULL
);


ALTER TABLE "public"."train_gifs" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."train_gifs_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."train_gifs_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."train_gifs_id_seq" OWNED BY "public"."train_gifs"."id";



CREATE TABLE IF NOT EXISTS "public"."train_jokes" (
    "id" bigint NOT NULL,
    "created_at" timestamp(0) without time zone,
    "updated_at" timestamp(0) without time zone,
    "message" character varying(255) NOT NULL,
    "enabled" boolean DEFAULT true NOT NULL
);


ALTER TABLE "public"."train_jokes" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."train_jokes_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."train_jokes_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."train_jokes_id_seq" OWNED BY "public"."train_jokes"."id";



CREATE TABLE IF NOT EXISTS "public"."train_secrets" (
    "id" bigint NOT NULL,
    "created_at" timestamp(0) without time zone,
    "updated_at" timestamp(0) without time zone,
    "message" character varying(255) NOT NULL,
    "enabled" boolean DEFAULT true NOT NULL
);


ALTER TABLE "public"."train_secrets" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."train_secrets_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."train_secrets_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."train_secrets_id_seq" OWNED BY "public"."train_secrets"."id";



CREATE TABLE IF NOT EXISTS "public"."train_slideshows" (
    "id" bigint NOT NULL,
    "created_at" timestamp(0) without time zone,
    "updated_at" timestamp(0) without time zone,
    "link" character varying(255) NOT NULL
);


ALTER TABLE "public"."train_slideshows" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."train_slideshows_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."train_slideshows_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."train_slideshows_id_seq" OWNED BY "public"."train_slideshows"."id";



CREATE TABLE IF NOT EXISTS "public"."users" (
    "id" bigint NOT NULL,
    "name" character varying(255) NOT NULL,
    "email" character varying(255) NOT NULL,
    "email_verified_at" timestamp(0) without time zone,
    "password" character varying(255) NOT NULL,
    "remember_token" character varying(100),
    "created_at" timestamp(0) without time zone,
    "updated_at" timestamp(0) without time zone
);


ALTER TABLE "public"."users" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."users_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."users_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."users_id_seq" OWNED BY "public"."users"."id";



ALTER TABLE ONLY "public"."accommodation" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."accommodation_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."failed_jobs" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."failed_jobs_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."food_choices" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."food_choices_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."households" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."households_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."jobs" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."jobs_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."migrations" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."migrations_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."personal_access_tokens" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."personal_access_tokens_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."train_affirmations" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."train_affirmations_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."train_comments" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."train_comments_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."train_configs" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."train_configs_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."train_events" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."train_events_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."train_gifs" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."train_gifs_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."train_jokes" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."train_jokes_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."train_secrets" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."train_secrets_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."train_slideshows" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."train_slideshows_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."users" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."users_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."accommodation"
    ADD CONSTRAINT "accommodation_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."cache_locks"
    ADD CONSTRAINT "cache_locks_pkey" PRIMARY KEY ("key");



ALTER TABLE ONLY "public"."cache"
    ADD CONSTRAINT "cache_pkey" PRIMARY KEY ("key");



ALTER TABLE ONLY "public"."failed_jobs"
    ADD CONSTRAINT "failed_jobs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."failed_jobs"
    ADD CONSTRAINT "failed_jobs_uuid_unique" UNIQUE ("uuid");



ALTER TABLE ONLY "public"."food_choices"
    ADD CONSTRAINT "food_choices_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."guests_duplicate"
    ADD CONSTRAINT "guests_duplicate_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."guests"
    ADD CONSTRAINT "guests_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."households"
    ADD CONSTRAINT "households_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."job_batches"
    ADD CONSTRAINT "job_batches_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."jobs"
    ADD CONSTRAINT "jobs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."migrations"
    ADD CONSTRAINT "migrations_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."password_reset_tokens"
    ADD CONSTRAINT "password_reset_tokens_pkey" PRIMARY KEY ("email");



ALTER TABLE ONLY "public"."personal_access_tokens"
    ADD CONSTRAINT "personal_access_tokens_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."personal_access_tokens"
    ADD CONSTRAINT "personal_access_tokens_token_unique" UNIQUE ("token");



ALTER TABLE ONLY "public"."seating"
    ADD CONSTRAINT "seating_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."sessions"
    ADD CONSTRAINT "sessions_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."tables"
    ADD CONSTRAINT "tables_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."train_affirmations"
    ADD CONSTRAINT "train_affirmations_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."train_comments"
    ADD CONSTRAINT "train_comments_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."train_configs"
    ADD CONSTRAINT "train_configs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."train_events"
    ADD CONSTRAINT "train_events_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."train_gifs"
    ADD CONSTRAINT "train_gifs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."train_jokes"
    ADD CONSTRAINT "train_jokes_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."train_secrets"
    ADD CONSTRAINT "train_secrets_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."train_slideshows"
    ADD CONSTRAINT "train_slideshows_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_email_unique" UNIQUE ("email");



ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");



CREATE INDEX "jobs_queue_index" ON "public"."jobs" USING "btree" ("queue");



CREATE INDEX "personal_access_tokens_expires_at_index" ON "public"."personal_access_tokens" USING "btree" ("expires_at");



CREATE INDEX "personal_access_tokens_tokenable_type_tokenable_id_index" ON "public"."personal_access_tokens" USING "btree" ("tokenable_type", "tokenable_id");



CREATE INDEX "sessions_last_activity_index" ON "public"."sessions" USING "btree" ("last_activity");



CREATE INDEX "sessions_user_id_index" ON "public"."sessions" USING "btree" ("user_id");



ALTER TABLE "public"."accommodation" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."food_choices" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."guests" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."guests_duplicate" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."households" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."seating" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."tables" ENABLE ROW LEVEL SECURITY;




ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";


GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";





































































































































































GRANT ALL ON TABLE "public"."accommodation" TO "anon";
GRANT ALL ON TABLE "public"."accommodation" TO "authenticated";
GRANT ALL ON TABLE "public"."accommodation" TO "service_role";



GRANT ALL ON SEQUENCE "public"."accommodation_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."accommodation_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."accommodation_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."cache" TO "anon";
GRANT ALL ON TABLE "public"."cache" TO "authenticated";
GRANT ALL ON TABLE "public"."cache" TO "service_role";



GRANT ALL ON TABLE "public"."cache_locks" TO "anon";
GRANT ALL ON TABLE "public"."cache_locks" TO "authenticated";
GRANT ALL ON TABLE "public"."cache_locks" TO "service_role";



GRANT ALL ON TABLE "public"."failed_jobs" TO "anon";
GRANT ALL ON TABLE "public"."failed_jobs" TO "authenticated";
GRANT ALL ON TABLE "public"."failed_jobs" TO "service_role";



GRANT ALL ON SEQUENCE "public"."failed_jobs_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."failed_jobs_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."failed_jobs_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."food_choices" TO "anon";
GRANT ALL ON TABLE "public"."food_choices" TO "authenticated";
GRANT ALL ON TABLE "public"."food_choices" TO "service_role";



GRANT ALL ON SEQUENCE "public"."food_choices_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."food_choices_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."food_choices_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."guests" TO "anon";
GRANT ALL ON TABLE "public"."guests" TO "authenticated";
GRANT ALL ON TABLE "public"."guests" TO "service_role";



GRANT ALL ON TABLE "public"."guests_duplicate" TO "anon";
GRANT ALL ON TABLE "public"."guests_duplicate" TO "authenticated";
GRANT ALL ON TABLE "public"."guests_duplicate" TO "service_role";



GRANT ALL ON SEQUENCE "public"."guests_duplicate_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."guests_duplicate_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."guests_duplicate_id_seq" TO "service_role";



GRANT ALL ON SEQUENCE "public"."guests_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."guests_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."guests_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."households" TO "anon";
GRANT ALL ON TABLE "public"."households" TO "authenticated";
GRANT ALL ON TABLE "public"."households" TO "service_role";



GRANT ALL ON SEQUENCE "public"."households_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."households_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."households_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."job_batches" TO "anon";
GRANT ALL ON TABLE "public"."job_batches" TO "authenticated";
GRANT ALL ON TABLE "public"."job_batches" TO "service_role";



GRANT ALL ON TABLE "public"."jobs" TO "anon";
GRANT ALL ON TABLE "public"."jobs" TO "authenticated";
GRANT ALL ON TABLE "public"."jobs" TO "service_role";



GRANT ALL ON SEQUENCE "public"."jobs_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."jobs_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."jobs_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."migrations" TO "anon";
GRANT ALL ON TABLE "public"."migrations" TO "authenticated";
GRANT ALL ON TABLE "public"."migrations" TO "service_role";



GRANT ALL ON SEQUENCE "public"."migrations_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."migrations_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."migrations_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."password_reset_tokens" TO "anon";
GRANT ALL ON TABLE "public"."password_reset_tokens" TO "authenticated";
GRANT ALL ON TABLE "public"."password_reset_tokens" TO "service_role";



GRANT ALL ON TABLE "public"."personal_access_tokens" TO "anon";
GRANT ALL ON TABLE "public"."personal_access_tokens" TO "authenticated";
GRANT ALL ON TABLE "public"."personal_access_tokens" TO "service_role";



GRANT ALL ON SEQUENCE "public"."personal_access_tokens_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."personal_access_tokens_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."personal_access_tokens_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."seating" TO "anon";
GRANT ALL ON TABLE "public"."seating" TO "authenticated";
GRANT ALL ON TABLE "public"."seating" TO "service_role";



GRANT ALL ON SEQUENCE "public"."seating_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."seating_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."seating_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."sessions" TO "anon";
GRANT ALL ON TABLE "public"."sessions" TO "authenticated";
GRANT ALL ON TABLE "public"."sessions" TO "service_role";



GRANT ALL ON TABLE "public"."tables" TO "anon";
GRANT ALL ON TABLE "public"."tables" TO "authenticated";
GRANT ALL ON TABLE "public"."tables" TO "service_role";



GRANT ALL ON SEQUENCE "public"."tables_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."tables_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."tables_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."train_affirmations" TO "anon";
GRANT ALL ON TABLE "public"."train_affirmations" TO "authenticated";
GRANT ALL ON TABLE "public"."train_affirmations" TO "service_role";



GRANT ALL ON SEQUENCE "public"."train_affirmations_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."train_affirmations_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."train_affirmations_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."train_comments" TO "anon";
GRANT ALL ON TABLE "public"."train_comments" TO "authenticated";
GRANT ALL ON TABLE "public"."train_comments" TO "service_role";



GRANT ALL ON SEQUENCE "public"."train_comments_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."train_comments_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."train_comments_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."train_configs" TO "anon";
GRANT ALL ON TABLE "public"."train_configs" TO "authenticated";
GRANT ALL ON TABLE "public"."train_configs" TO "service_role";



GRANT ALL ON SEQUENCE "public"."train_configs_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."train_configs_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."train_configs_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."train_events" TO "anon";
GRANT ALL ON TABLE "public"."train_events" TO "authenticated";
GRANT ALL ON TABLE "public"."train_events" TO "service_role";



GRANT ALL ON SEQUENCE "public"."train_events_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."train_events_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."train_events_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."train_gifs" TO "anon";
GRANT ALL ON TABLE "public"."train_gifs" TO "authenticated";
GRANT ALL ON TABLE "public"."train_gifs" TO "service_role";



GRANT ALL ON SEQUENCE "public"."train_gifs_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."train_gifs_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."train_gifs_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."train_jokes" TO "anon";
GRANT ALL ON TABLE "public"."train_jokes" TO "authenticated";
GRANT ALL ON TABLE "public"."train_jokes" TO "service_role";



GRANT ALL ON SEQUENCE "public"."train_jokes_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."train_jokes_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."train_jokes_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."train_secrets" TO "anon";
GRANT ALL ON TABLE "public"."train_secrets" TO "authenticated";
GRANT ALL ON TABLE "public"."train_secrets" TO "service_role";



GRANT ALL ON SEQUENCE "public"."train_secrets_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."train_secrets_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."train_secrets_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."train_slideshows" TO "anon";
GRANT ALL ON TABLE "public"."train_slideshows" TO "authenticated";
GRANT ALL ON TABLE "public"."train_slideshows" TO "service_role";



GRANT ALL ON SEQUENCE "public"."train_slideshows_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."train_slideshows_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."train_slideshows_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."users" TO "anon";
GRANT ALL ON TABLE "public"."users" TO "authenticated";
GRANT ALL ON TABLE "public"."users" TO "service_role";



GRANT ALL ON SEQUENCE "public"."users_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."users_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."users_id_seq" TO "service_role";









ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";































